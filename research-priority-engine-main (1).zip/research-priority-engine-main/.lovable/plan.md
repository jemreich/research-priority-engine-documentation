# Add Data Dictionary to Audit Log Page

## Goal
Add a comprehensive Data Dictionary section to `src/pages/AuditLog.tsx` that defines every metric shown on the Dashboard and PI Profiles tables, styled to match the user's reference screenshots (bordered sub-cards, bold term + italic definition).

## Location & Layout
- **File**: `src/pages/AuditLog.tsx`
- **Placement**: New `Card` inserted at the top of the page (above Manual Overrides), with a `BookOpen` lucide icon in the title.
- **Grid**: Responsive `grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3` of small bordered sub-cards. Each sub-card: `border rounded-md p-3 bg-muted/30` with a bold term and an italic muted definition underneath.
- **Sectioning**: Group entries under subheadings using `h4` separators:
  1. Dashboard Columns
  2. PI Profile Columns
  3. Scoring Components & Tiers
  4. Reference Metrics (publication / journal / researcher)

## Definitions to Include

### Dashboard Columns
- **#** — Row index in the current sorted view.
- **ROI** — Effort-Adjusted ROI score: weighted return × effort multiplier, after tier discount.
- **Return** — Weighted Return: equal-weighted average of S1–S4 sub-scores (0–100), pre-effort.
- **Status** — Open / Closed based on `dateCompleted`.
- **Requested** — `dateOfRequest` (date the REDCap request was submitted).
- **Pubs** — Count of PubMed publications linked to this request.
- **Type** — Request type (e.g., Cohort, Chart Review).
- **Department** — Requesting PI's department.
- **PI Rank** — Faculty rank (Professor, Associate, Assistant, Instructor, Other).
- **PI** — Principal Investigator name.
- **Project Title** — Short title of the REDCap project.
- **Funding** — Primary funding source category (NIH, Foundation, Internal, etc.).
- **Tier** — Data confidence tier: T1 = full enrichment, T2 = partial (proxy used), T3 = insufficient data.

### PI Profile Columns
- **PI Name** — Researcher name (normalized).
- **Faculty Rank** — Highest faculty rank seen across that PI's requests.
- **Requests** — Total number of REDCap requests submitted by this PI.
- **Funding ($M)** — Total NIH RePORTER funding aggregated across all grants, in millions USD.
- **Grants** — Total distinct grants on file from NIH RePORTER.
- **Active** — Number of currently active (non-expired) grants.
- **Pubs** — Total publications linked across all of this PI's requests.
- **Avg RCR** — Mean Relative Citation Ratio across this PI's publications.
- **Avg Authors** — Mean number of authors per publication for this PI.
- **Department** — Most-recent department for this PI.

### Scoring Components & Tiers
- **S1 — Publication Impact** — Weighted blend of RCR, NIH Percentile, Citation Count.
- **S2 — Researcher Track Record** — h-index, total publications, total citations, faculty rank.
- **S3 — Journal Prestige** — SJR Quartile, SJR, h5-index, Cit/Doc 2yr.
- **S4 — Funding Activity** — Funding source, active grants, total funding.
- **Effort Multiplier** — `clamp((anchorHours ÷ tracHours) ^ dampening, [min, max])` — rewards efficient use of analyst time.
- **Tier 1 (T1)** — Fully enriched (publications + journal + PI metrics) — no discount.
- **Tier 2 (T2)** — Partial data, proxy estimates used — proxy discount applied (if enabled).
- **Tier 3 (T3)** — Insufficient data — insufficient-data discount applied (if enabled).
- **Niche Bonus** — Optional multiplier for low-saturation journals matching SCImago criteria (quartile + numeric thresholds).

### Reference Metrics
- **RCR (Relative Citation Ratio)** — NIH iCite field-normalized citation impact (1.0 = NIH-funded average).
- **NIH Percentile** — Percentile rank of citation rate among NIH-funded papers in the same field/year.
- **Citation Count** — Total citations from iCite.
- **h-index** — Researcher's NIH RePORTER h-index proxy (publications cited ≥ h times).
- **SJR (SCImago Journal Rank)** — Prestige-weighted citations per document (2024).
- **SJR Quartile** — Q1–Q4 ranking of the journal within its SCImago category.
- **h5-index** — Google Scholar 5-year h-index for the journal.
- **Cit/Doc 2yr** — Average citations per document over the past 2 years (SCImago).
- **Total Docs (3yr)** — Document count over the past 3 years (SCImago).

## Styling Details
- Use existing tokens (`bg-muted/30`, `text-foreground`, `text-muted-foreground`, `italic`, `font-semibold`).
- No new dependencies — all icons from `lucide-react` (already imported).
- Mobile-responsive: collapses to a single column at `< md`.

## Files Edited
- `src/pages/AuditLog.tsx` (only)

## Out of Scope
- No changes to scoring logic, types, or other pages.
- No new tests (purely presentational, static content).
