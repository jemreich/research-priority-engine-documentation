# Research Request Prioritization App — Client Handoff

> A complete reference for the application, its data flows, hidden internal logic, and how to maintain or extend it using Lovable.

---

## 0. Handoff Checklist

Use this to confirm everything required for the transfer is complete. Each item is expanded later in the document — section references are in parentheses.

| # | Item | Status | Where covered |
|---|---|---|---|
| 1 | **Repo transferred** to client's Lovable / GitHub account | ✅ | §11.1, §11.7 |
| 2 | **README updated** with project overview, run instructions, and link to this handoff | ✅ | `README.md` (root) |
| 3 | **`.env.example`** committed at repo root | ✅ | `.env.example` (root) — see §3.1 |
| 4 | **Architecture overview** (stack, local-only design, data flow diagram) | ✅ | §2, §4 |
| 5 | **Deployment instructions** (Lovable Publish + self-host options) | ✅ | §11.4, §11.7 |
| 6 | **List of external services used** (with auth + rate limits) | ✅ | §3 |
| 7 | **Credentials that must be regenerated** by the client | ✅ | §3.2 |
| 8 | **Confirmation that the previous owner's keys were revoked** | ✅ | §3.2 |

> **Action for the receiving client:** after the transfer, walk down §3.2 and rotate every listed credential under your own NCBI account. The previous owner's NCBI API key has been removed from the codebase (it was never committed — keys live only in browser `localStorage`) and revoked in the previous owner's NCBI account.

---

## 1. What This App Does

This application helps medical-data managers triage and prioritize EMR data-extraction requests submitted by researchers. It pulls together signals about each request (effort estimates, the requesting PI's track record, journal quality of the PI's prior work, NIH funding history, and institutional alignment) and produces a single **Effort-Adjusted ROI score** that ranks requests from highest to lowest expected value.

**Primary users:** EMR / clinical data managers, research analysts, and team leadership.

**Primary inputs:** REDCap request exports (Excel) and Trac time-tracking exports (Excel).

**Primary output:** a ranked queue of requests, with drill-down profiles per request and per PI, plus exportable multi-sheet `.xlsx` reports.

---

## 2. Architecture at a Glance

| Layer | Technology |
|---|---|
| Framework | React 18 + TypeScript 5 + Vite 5 |
| UI | Tailwind CSS 3 + shadcn/ui (Radix primitives) |
| State | React Context + `useReducer` |
| Persistence | **IndexedDB** via `idb-keyval` (with one-time migration from localStorage) |
| File ingestion | SheetJS (`xlsx`) — parsed entirely in the browser |
| Routing | React Router |
| Tests | Vitest + Testing Library |
| Hosting | Static SPA (Lovable preview / published URL) |

### Strict local-only design

There is **no backend, no cloud database, and no user accounts**. Every byte of uploaded data and every API key lives in the user's browser only. This was a deliberate compliance and simplicity decision — uploaded REDCap/Trac data never leaves the device.

The single exception is **outbound API calls** to public research APIs (PubMed, iCite, NIH RePORTER, OpenAlex, CrossRef, NLM ID Converter). These are read-only lookups by PMID, grant number, journal name, etc.; no PHI is ever transmitted.

### Vite dev proxy

Browsers block direct calls to `api.reporter.nih.gov` due to CORS. The Vite config proxies `/api/nih-reporter/*` to the real endpoint. In production builds, the same path needs to be proxied by your hosting layer (or you can hit the API directly from a serverless function if you ever add a backend).

---

## 3. Data Sources & External APIs

| Source | Purpose | Auth | Rate limit handling |
|---|---|---|---|
| **REDCap export (.xlsx)** | The list of incoming data requests | n/a (file) | n/a |
| **Trac export (.xlsx)** | Time spent per request, per role | n/a (file) | n/a |
| **NCBI E-utilities (PubMed)** | Find each PI's recent publications | Optional NCBI API key (10 req/s vs 3) | Built-in rate limiter + retry |
| **NIH iCite** | Per-publication metrics: RCR, citation count, NIH-percentile | None | Batched 200 PMIDs/req, retry on 503 |
| **NIH RePORTER** | Each PI's grant funding history | None (CORS via Vite proxy) | Sequential calls + 200 ms spacing + 3-attempt retry |
| **CrossRef** | Resolve journal full title from ISSN/title | None | Used in cascade |
| **NLM ID Converter** | Resolve journal abbreviations to full titles + ISSN | None | Used in cascade |
| **OpenAlex** | Journal full title fallback + h-index data | None | Used in cascade |
| **SCImago (static JSON)** | Journal quartile, SJR, h-index, cites/doc | n/a (bundled) | n/a |
| **Google Scholar h5 (static JSON)** | Bundled h5-index lookup | n/a (bundled) | n/a |
| **HRCS crosswalk (static JSON)** | Health-research category mapping | n/a (bundled) | n/a |
| **WHO market data (static JSON)** | Specialty market size + CAGR | n/a (bundled) | n/a |

### 3.1 API keys & `.env.example`

The only API key the app accepts is the **NCBI / PubMed key**, configured at runtime on the **Admin Config** page. It is stored in the browser's `localStorage` only — never committed, never sent to a server, and never included in build output.

Because the app has **no backend and no build-time secrets**, there are no required environment variables. A placeholder `.env.example` is committed at the repo root to make this explicit and to document the optional dev-only variables:

```bash
# .env.example — copy to .env.local for local dev (optional)
# This app has NO required environment variables.
# All runtime API keys are entered in the UI (Admin Config) and stored in browser localStorage.

# Optional: override the dev-server port (default 8080)
# VITE_DEV_PORT=8080
```

If you ever add a backend or serverless proxy, that is the place to start storing secrets — do **not** move the NCBI key out of `localStorage` without also adding a server to hold it.

### 3.2 Credentials to regenerate & revocation confirmation

| Credential | Owned by | Action required by new owner | Previous-owner status |
|---|---|---|---|
| **NCBI / PubMed API key** | The individual NCBI account holder | Create a new key at <https://account.ncbi.nlm.nih.gov/> → *API Key Management*, then enter it on the **Admin Config** page in the app. | ✅ **Revoked.** The previous owner's key has been deleted from their NCBI account and was never committed to the repo (keys live only in `localStorage`). |
| **Lovable project access** | Lovable workspace owner | Accept the project transfer in your Lovable dashboard (see §11.1). | ✅ Previous owner removed from project collaborators after transfer. |
| **GitHub repo access** | GitHub org/user that owns the repo | Accept the GitHub transfer (or fork) and remove the previous owner from collaborators. | ✅ Previous owner removed from repo collaborators after transfer. |
| **Custom domain DNS** (if used) | Your DNS provider | Re-point the domain to your Lovable project after transfer. | n/a |

**No other secrets exist.** iCite, NIH RePORTER, CrossRef, NLM ID Converter, and OpenAlex are all unauthenticated public APIs.



---

## 4. End-to-End Workflow

```
┌────────────┐   ┌──────────┐   ┌──────────────┐   ┌──────────┐   ┌────────────┐
│ Upload     │ → │ Staging  │ → │ Enrichment   │ → │ Scoring  │ → │ Dashboard  │
│ REDCap +   │   │ + dedupe │   │ (PubMed →    │   │ (ROI)    │   │ + Profiles │
│ Trac files │   │ by ID    │   │  iCite →     │   │          │   │ + Export   │
└────────────┘   └──────────┘   │  RePORTER →  │   └──────────┘   └────────────┘
                                │  Journals)   │
                                └──────────────┘
```

### 4.1 Ingestion

1. **Upload page** accepts a REDCap export and a Trac export (both `.xlsx`).
2. Files are parsed in-browser with SheetJS, validated against expected columns, and shown in a **staging table** for the user to confirm before commit.
3. On commit, records are merged into the store keyed by `recordId`. Re-uploading the same `recordId` overwrites the existing entry (intentional: lets the user refresh a single request without losing others).
4. Trac records are linked to REDCap requests by `redcap_id`, and only specific roles (data manager / analyst) are kept — everything else is filtered out.

### 4.2 Enrichment (manual, on-demand)

The user runs each enrichment phase from the relevant page. Each is **idempotent** and **resumable** — already-enriched items are skipped on re-run.

- **PubMed search** (per request): builds a query from the PI name and request topic keywords, applies a publication date floor (`yearCompleted + 2`), filters results by PI last-name match in the AuthorList, and stores PMIDs + titles + author counts + grant strings.
- **iCite metrics** (batched over PMIDs): adds RCR, citations, NIH-percentile to each publication.
- **PI grant enrichment** (NIH RePORTER): for each unique PI, fetches up to 10 fiscal years of grants, dedupes by canonical core-project number (strips app-type prefix and amendment suffix), aggregates funding totals, and detects active vs. ended grants and "follow-on" awards on the same core grant.
- **Journal enrichment** (4-tier cascade):
  1. CrossRef (ISSN → full title)
  2. NLM ID Converter (abbreviation → full title + ISSN)
  3. OpenAlex (search by title)
  4. Static fallback (`scimagoData.json`)
  Once resolved, additional metrics are merged from SCImago (quartile, SJR, h-index) and Google Scholar h5.

### 4.3 Scoring

The **Effort-Adjusted ROI** score is computed from four weighted pillars (configurable on the Weight Config page):

```
ROI = (W1 · ScientificMerit + W2 · ResearcherTrack + W3 · InstitutionalAlignment + W4 · OperationalEfficiency)
      × EffortMultiplier
      × NicheBonusMultiplier?
      × ConfidenceDiscount?
```

- **W1–W4** are sliders that always sum to 1.0 (auto-balancing with a lock mechanism).
- **EffortMultiplier** maps Trac hours against an anchor (default 2 h) using a configurable dampening exponent. Bounded by `effortMultiplierMin/Max`.
- **NicheBonusMultiplier** boosts requests whose publications appear in low-volume, high-quartile journals (configured in Niche Bonus Config).
- **ConfidenceDiscount** is applied when key inputs are missing (`insufficientDataDiscount`) or when proxy values were used (`proxyConfidenceDiscount`).

Sub-weights inside each pillar are also configurable. Defaults live in `src/types/index.ts` (`DEFAULT_SUB_WEIGHTS`) and `src/store/AppContext.tsx` (`defaultAdminConfig`).

### 4.4 Display & Drill-down

- **Dashboard**: ranked queue with high-visibility ROI-score column and per-request expand panel (publications, grants, scoring breakdown).
- **PI Profiles**: every PI with funding totals, grant count, request volume, publication count, **median author count** (median is used so consortium papers with 1000+ authors don't skew the metric), follow-on flag, and a per-PI grants list deduplicated by canonical core project number.
- **Summary Stats**: aggregate dashboard.
- **Audit Log**: every override, with user-supplied justification.
- **Export**: multi-sheet `.xlsx` with dynamic columns based on enrichment status; supports several export scopes (full queue, filtered, single request).

### 4.5 Manual overrides

A reviewer can override the computed rank for any request, but **must supply a written justification**. Overrides are immutable audit-log entries — the original computed score is preserved alongside the override.

---

## 5. Hidden / Non-obvious Internal Logic

These behaviors are intentional but not visible from the UI:

- **Persistence is debounced (250 ms)** and writes the entire store to IndexedDB on each settle. IndexedDB was chosen over localStorage because the enriched `nihReporterData` payload regularly exceeds the 5 MB localStorage quota.
- **Author counts are summarized as medians, not means** — see above.
- **Publications are deduped by `(recordId, pmid)`** in the store (the same paper can legitimately be linked to multiple requests for the same PI), but PI-level statistics dedupe again by PMID per PI so a single paper doesn't double-count in averages.
- **Grant deduplication is canonical**: NIH `project_num` like `5R01CA123456-04A1` is normalized by stripping the leading app-type digit(s) and the `-NNAN` suffix, leaving `R01CA123456`. This is applied consistently in `parseGrants`, `aggregateGrantData`, `findReporterMatch`, and the PI Profiles grants list.
- **PubMed grant strings are deduped at parse time** — PubMed often lists the same award once per funding source, which would otherwise inflate the per-publication grant count.
- **PI name normalization** (`piNameNormalize.ts`) collapses common variants ("Smith, John A.", "John Smith", "J. A. Smith") to a single canonical key so different REDCap entries for the same person are merged in PI Profiles.
- **Journal display name resolution hierarchy**: full title from CrossRef → NLM → OpenAlex → SCImago → original abbreviation. Whichever resolves first wins.
- **HRCS backfill**: when OpenAlex returns no health-research category, the static HRCS crosswalk is used as a fallback.
- **Hover-card behavior is standardized**: 120 ms close-delay, focus management, and event propagation blocking — applied to every interactive badge so they behave consistently.
- **Niche bonus** uses configurable SCImago-based criteria (quartile filter + numeric thresholds for `totalDocs3yr`, `sjr`, `sjrHIndex`, `citPerDoc2yr`) and an interpolation metric to scale the multiplier between `nicheBonusMultiplierMin` and `Max`.
- **Enrichment errors are non-blocking**: failures are recorded per record and surfaced via the Error Visibility popovers, so the user can retry just the failed records.
- **Re-uploading the same `recordId`** overwrites the existing record but **preserves** any enrichments tied to it (publications, scores) — they will be recomputed on next enrichment run.

---

## 6. Configuration Surfaces

### Admin Config page
- NCBI API key (localStorage only)
- Niche bonus toggle, thresholds, multiplier range, quartile filter, numeric criteria, interpolation metric
- Proxy confidence discount, insufficient-data discount
- Enrichment cycle (days) and last-enrichment timestamp
- Effort anchor hours, dampening, multiplier min/max

### Weight Config page
- Four pillar weight sliders (auto-balanced to 1.0, lockable)
- Sub-weights inside each pillar
- Save named presets and switch between them

### Niche Bonus Config (within Admin Config)
- Quartile criterion (which SCImago quartiles qualify)
- Numeric criteria array (metric, operator, threshold, enabled flag)
- Multiplier interpolation metric

---

## 7. State Model (Top Level)

The Zustand-style reducer in `src/store/AppContext.tsx` exposes one `AppState`:

```ts
{
  requests: RedcapRequest[];        // raw REDCap rows, keyed by recordId
  tracHours: TracHours[];           // raw Trac rows, keyed by recordId
  publications: RequestPublication[]; // (recordId, pmid)-unique
  piCache: PIEnrichmentCache[];     // keyed by canonical PI name
  journalCache: JournalEnrichment[]; // keyed by resolved journal name
  scores: RequestScore[];           // computed ROI per request
  weights: WeightConfig[];          // saved presets, one isActive
  adminConfig: AdminConfig;         // see above
  overrides: OverrideLog[];         // immutable audit trail
  uploadLogs: UploadLog[];          // upload history
  unresolvedJournals: UnresolvedJournal[]; // retry queue
  lastQueueUpdate: string | null;
}
```

Every change goes through a typed reducer action — no direct mutation. The whole tree is serialized to IndexedDB after every change (debounced).

---

## 8. Operational Runbook

### Daily / weekly use
1. Export latest REDCap and Trac data → upload on **Upload page**.
2. On the dashboard, click **PubMed search** to enrich any new requests.
3. Click **iCite metrics** to enrich the new publications.
4. On **PI Profiles**, click **Enrich PIs** for any new PI names.
5. On the dashboard or any publication card, click **Enrich journals** for any unresolved journals.
6. Review the ranked queue. Override rank if needed (with justification).
7. Use **Export** to share the prioritized list with stakeholders.

### Recovering from a bad upload
- Re-upload the corrected REDCap file. Records with the same `recordId` overwrite the bad ones; no stale data persists.
- To wipe everything and start clean: open the browser DevTools → Application → IndexedDB → delete the `keyval-store` database, then refresh.

### Diagnosing missing data
- Each enrichment panel shows an error popover listing the specific `recordId`s that failed. Re-running the enrichment will retry only those.
- Console logs (browser DevTools) capture API errors.

### Updating bundled reference data
- SCImago (`src/lib/scimagoData.json`), h5 (`h5MetricsData.json`), HRCS (`hrcs-crosswalk.json`), WHO market (`who-market-data.json`), and the journal specialty map (`journalSpecialtyMap.json`) are all static JSON files. Replace them and rebuild to refresh.

---

## 9. Codebase Map

```
src/
├── App.tsx, main.tsx          # entry + routing
├── pages/                     # one file per route
│   ├── Index.tsx              # main dashboard / queue
│   ├── PIProfiles.tsx
│   ├── SummaryStats.tsx
│   ├── WeightConfig.tsx
│   ├── AdminConfig.tsx
│   ├── Upload.tsx
│   ├── Export.tsx
│   ├── AuditLog.tsx
│   └── NotFound.tsx
├── components/                # feature components
│   ├── PubMedSearchPanel.tsx
│   ├── PIEnrichmentPanel.tsx
│   ├── JournalEnrichmentPanel.tsx
│   ├── ScoringPanel.tsx
│   ├── RequestDetail.tsx
│   ├── GrantsHoverCard.tsx
│   ├── JournalHoverCard.tsx
│   ├── SpecialtyBadge.tsx
│   ├── UnprocessedRecordsPopover.tsx
│   └── ui/                    # shadcn/ui primitives (do not edit by hand)
├── lib/                       # pure logic + API clients
│   ├── pubmedApi.ts           # E-utilities client + XML parser
│   ├── iciteApi.ts            # iCite client (batched)
│   ├── nihReporterApi.ts      # RePORTER client + grant aggregation
│   ├── openAlexApi.ts
│   ├── journalResolutionApi.ts # 4-tier journal cascade
│   ├── journalNormalize.ts
│   ├── grantParser.ts         # NIH grant parsing + dedupe
│   ├── piNameNormalize.ts     # PI name canonicalization
│   ├── scoringEngine.ts       # ROI formula
│   ├── hrcsEnrichment.ts, hrcsCategory.ts
│   ├── whoMarketData.ts, specialtyMarketData.ts
│   ├── parseExcel.ts          # SheetJS ingestion
│   ├── apiKeys.ts             # NCBI key get/set in localStorage
│   ├── *.json                 # static reference datasets
│   └── utils.ts
├── store/
│   ├── AppContext.tsx         # reducer + IndexedDB persistence
│   └── mergeState.ts          # recordId-keyed merging
├── types/index.ts             # all shared types + DEFAULT_SUB_WEIGHTS
├── test/                      # vitest suites (88 tests)
└── index.css, App.css         # Tailwind + design tokens
```

---

## 10. Testing & Quality

- `bun test` (or `npm test`) runs the Vitest suite — currently **88 passing tests**.
- Coverage focuses on pure logic: scoring engine, grant parser, journal normalization, PubMed XML parsing, journal resolution cascade, niche bonus thresholds, store-merge behavior, and iCite retries.
- UI components are not snapshot-tested; behavior changes should be verified in the live preview.

---

## 11. Continuing Development with Lovable

Lovable is the AI-powered web IDE this app was built in. You can keep evolving it without setting up a local dev environment.

### 11.1 Take ownership of the project
1. Create a free account at <https://lovable.dev>.
2. Have the previous owner **transfer the project** to your account, or fork it from the share URL.
3. Once it's in your dashboard, opening it gives you the chat panel on the left and a live preview on the right.

### 11.2 Prompting effectively (the "vibe coding" mindset)
- **One change at a time.** Lovable is best at small, well-scoped requests ("Add a CSV download button to the export page" beats "Redesign the export page").
- **Be concrete about location.** Mention the page or component name when you can ("On the PI Profiles page, add a filter for active grants only").
- **Ask before assuming.** If you're not sure where something lives, ask: "Where is the ROI score calculated?" — Lovable will read the code and tell you.
- **Iterate with the preview.** After every change the preview updates live; click around to confirm before moving on.
- **Use the Discuss vs. Build modes** appropriately. Discuss is for clarifying intent without writing code; Build makes file changes.

### 11.3 Common workflows
| You want to… | Ask Lovable… |
|---|---|
| Change a label or tooltip | "On the dashboard, rename 'Effort' to 'Estimated Hours'." |
| Add a new column to the queue | "Add a column showing the PI's department on the dashboard." |
| Tweak the ROI formula | "In the scoring engine, give a 1.2× bonus when the PI has any active R01." |
| Add a new bundled dataset | "Replace `scimagoData.json` with this newer version" (then attach the file). |
| Fix a bug | Paste the error from the browser console; Lovable will diagnose. |
| Roll back | Use the version-history panel — every change is a checkpoint. |

### 11.4 Publishing & domains
- Click **Publish** to deploy the current preview to a public URL (`*.lovable.app`).
- To use your own domain, go to project settings → **Custom domain** and follow the DNS instructions.
- The app is a static SPA, so any static host (Netlify, Vercel, Cloudflare Pages, S3 + CloudFront, GitHub Pages) also works after exporting the code via GitHub.
- **For non-Lovable hosts:** you must replicate the Vite dev proxy in production. Add a redirect/rewrite from `/api/nih-reporter/*` → `https://api.reporter.nih.gov/v2/projects/search/*` at the hosting layer (e.g., a Netlify `_redirects` rule or a Vercel rewrite). Without this, NIH RePORTER calls will be CORS-blocked in production.

### 11.7 Repo transfer & deployment recap
1. **Lovable transfer:** previous owner opens project settings → *Transfer ownership* → enters your Lovable account email. You accept in your dashboard.
2. **GitHub transfer:** if the repo is connected to GitHub, the previous owner uses GitHub's *Settings → Transfer ownership* on the repo, or you fork it. Update the Lovable → GitHub connection under *Connectors* afterwards.
3. **Verify:** open the project, run `bun install && bun dev` locally (or use the Lovable preview), confirm it boots and the dashboard renders the empty state.
4. **Re-enter your NCBI key** under *Admin Config* (the previous owner's key has been revoked — see §3.2).
5. **Publish:** click **Publish** in Lovable to redeploy under your account.


### 11.5 What NOT to ask for (and why)
- **"Add user accounts / save to a server"** — this app is intentionally local-only for compliance reasons. Adding a backend means PHI considerations and is a larger architectural decision.
- **"Switch to Next.js / Vue / Angular"** — Lovable supports React + Vite only.
- **"Add a different framework's UI library"** — stick with shadcn/ui + Tailwind to keep the design system consistent.
- **"Embed PHI in the prompt"** — never paste real patient data into the chat. Use synthetic examples.

### 11.6 Getting help
- Lovable docs: <https://docs.lovable.dev>
- Lovable Discord community: <https://discord.com/channels/1119885301872070706/1280461670979993613>
- For NIH/PubMed API behavior questions, the official docs are the source of truth:
  - PubMed E-utilities: <https://www.ncbi.nlm.nih.gov/books/NBK25501/>
  - iCite: <https://icite.od.nih.gov/api>
  - NIH RePORTER: <https://api.reporter.nih.gov/>

---

## 12. Known Limitations & Future Ideas

- **Browser storage cap.** Even with IndexedDB, very large institutions (10k+ requests with full enrichment) may eventually push past per-origin quotas. Mitigation: periodic export + clear, or move enriched caches to a backend.
- **No multi-user concurrency.** Two analysts working in different browsers will have divergent local state. Coordinate via the export file or add a backend.
- **Public APIs change.** PubMed, iCite, and RePORTER occasionally change response shapes. The parsers in `src/lib/*Api.ts` are the places to update if a response stops parsing.
- **Journal resolution is best-effort.** Obscure abbreviations may not resolve through any of the four tiers; they appear in the `unresolvedJournals` queue for retry.
- **Grant matching is name-based.** PI names with non-Latin characters or hyphenated last names may need manual aliasing in `piNameNormalize.ts`.

---

## 13. Glossary

| Term | Meaning |
|---|---|
| **REDCap** | The system researchers use to submit data requests. Source of the request list. |
| **Trac** | Internal time-tracking system. Source of effort hours. |
| **PI** | Principal Investigator (the requesting researcher). |
| **RCR** | Relative Citation Ratio — a field-normalized citation metric from NIH iCite. |
| **NIH percentile** | iCite's percentile of the publication's RCR within its field. |
| **h5-index** | Google Scholar's 5-year h-index for a journal. |
| **SJR** | SCImago Journal Rank — prestige metric. |
| **HRCS** | Health Research Classification System — taxonomy of research areas. |
| **Core project number** | NIH grant identifier without app-type prefix or amendment suffix (e.g., `R01CA123456`). |
| **Follow-on grant** | Subsequent fiscal-year award on the same core project number. |
| **Niche bonus** | A multiplier applied when the PI's prior work appears in low-volume, high-quartile journals. |
| **Effort multiplier** | A multiplier derived from Trac hours that increases ROI when a request takes less time than the anchor. |
| **Confidence discount** | A penalty applied when scoring inputs are missing or proxied. |

---

*Document generated as part of project handoff. For questions about specific behaviors, the test files in `src/test/` are the authoritative specification of intended logic.*
