# Research Request Prioritization App

A browser-only tool that helps medical-data managers triage and prioritize EMR data-extraction requests. It ingests REDCap and Trac exports, enriches each request with PubMed / iCite / NIH RePORTER / journal-quality data, and produces a ranked **Effort-Adjusted ROI** queue.

> **All data and API keys stay in the browser.** There is no backend, no cloud database, and no user accounts.

## Quick start

```bash
bun install      # or: npm install
bun dev          # or: npm run dev
```

Then open <http://localhost:8080>.

## Configuration

This project has **no required environment variables**. See [`.env.example`](./.env.example) for the (optional) dev overrides.

The only API key the app uses is an **NCBI / PubMed key**, entered at runtime under **Admin Config** in the UI and stored in browser `localStorage`. Get one at <https://account.ncbi.nlm.nih.gov/> → *API Key Management*.

## Tech stack

- React 18 + TypeScript 5 + Vite 5
- Tailwind CSS 3 + shadcn/ui (Radix primitives)
- React Context + `useReducer`, persisted to **IndexedDB** via `idb-keyval`
- SheetJS (`xlsx`) for in-browser Excel parsing
- Vitest + Testing Library

## Tests

```bash
bun test         # or: npm test
```

## Documentation & handoff

The full architectural reference, internal logic (ROI scoring, niche bonus, journal resolution cascade, grant deduplication), deployment instructions, external-service inventory, and credential-rotation checklist are in:

📄 **[`HANDOFF.md`](./HANDOFF.md)**

Start there for any non-trivial change or for ongoing maintenance.

## Built with Lovable

Project URL: <https://lovable.dev/projects/d6033be8-0e35-4e48-b147-cb02ecf3a6b1>

Continue editing in Lovable, in your local IDE, or via GitHub — changes sync both ways. See HANDOFF §11 for the "vibe coding" guide.
