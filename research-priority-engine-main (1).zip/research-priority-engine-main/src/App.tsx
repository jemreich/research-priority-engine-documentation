import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider } from "@/store/AppContext";
import Layout from "@/components/Layout";
import Index from "./pages/Index";
import Upload from "./pages/Upload";
import WeightConfig from "./pages/WeightConfig";
import AdminConfig from "./pages/AdminConfig";
import AuditLog from "./pages/AuditLog";
import Export from "./pages/Export";
import PIProfiles from "./pages/PIProfiles";
import SummaryStats from "./pages/SummaryStats";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AppProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Layout>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/upload" element={<Upload />} />
              <Route path="/weights" element={<WeightConfig />} />
              <Route path="/admin" element={<AdminConfig />} />
              <Route path="/audit" element={<AuditLog />} />
              <Route path="/export" element={<Export />} />
              <Route path="/pi-profiles" element={<PIProfiles />} />
              <Route path="/summary" element={<SummaryStats />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </AppProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
