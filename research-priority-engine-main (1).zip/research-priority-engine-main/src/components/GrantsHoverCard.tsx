import React, { useRef, useState } from 'react';
import { parseGrants, type ParsedGrant } from '@/lib/grantParser';
import type { NIHReporterData, ReporterProjectSummary } from '@/types';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';

interface GrantsHoverCardProps {
  grantsString: string;
  reporterData?: NIHReporterData | null;
}

function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
}

/**
 * Find matching RePORTER project by core project number.
 * Also detect follow-on grants (same base activity+IC+serial, different suffix).
 */
function findReporterMatch(
  grant: ParsedGrant,
  reporterData: NIHReporterData | null | undefined
): { match: ReporterProjectSummary | null; followOns: ReporterProjectSummary[] } {
  if (!grant.isNIH || !grant.coreProjectNumber || !reporterData?.projects) {
    return { match: null, followOns: [] };
  }

  const canonicalCore = (projectNum: string): string => {
    if (!projectNum) return '';
    const stripped = projectNum.split('-')[0];
    return stripped.replace(/^\d+/, '').toUpperCase().replace(/\s+/g, '');
  };
  const coreParts = grant.coreProjectNumber.toUpperCase().replace(/\s+/g, '');

  const allMatches = reporterData.projects.filter(p => canonicalCore(p.projectNum) === coreParts);

  if (allMatches.length === 0) return { match: null, followOns: [] };

  // Deduplicate: collapse projects sharing the same fiscal year + full projectNum,
  // keeping the record with the highest award amount (handles supplement duplicates).
  const dedupMap = new Map<string, ReporterProjectSummary>();
  for (const proj of allMatches) {
    const key = `${proj.fiscalYear}::${proj.projectNum.replace(/\s/g, '')}`;
    const existing = dedupMap.get(key);
    if (!existing) {
      dedupMap.set(key, proj);
    } else {
      const existingAmt = existing.amount ?? -1;
      const newAmt = proj.amount ?? -1;
      if (newAmt > existingAmt) dedupMap.set(key, proj);
    }
  }

  // Further collapse to one entry per fiscal year (some duplicates differ only by support year suffix)
  const byYear = new Map<number, ReporterProjectSummary>();
  for (const proj of dedupMap.values()) {
    const existing = byYear.get(proj.fiscalYear);
    if (!existing) {
      byYear.set(proj.fiscalYear, proj);
    } else {
      const existingAmt = existing.amount ?? -1;
      const newAmt = proj.amount ?? -1;
      if (newAmt > existingAmt) byYear.set(proj.fiscalYear, proj);
    }
  }

  const sorted = [...byYear.values()].sort((a, b) => b.fiscalYear - a.fiscalYear);
  return {
    match: sorted[0],
    followOns: sorted.length > 1 ? sorted.slice(1) : [],
  };
}

/** Compute cumulative funding and year range across all grants for a publication */
export function computeGrantFundingSummary(
  grantsString: string,
  reporterData: NIHReporterData | null | undefined
): { totalFunding: number; minYear: number | null; maxYear: number | null; followOnCount: number } {
  const grants = parseGrants(grantsString);
  let totalFunding = 0;
  let minYear: number | null = null;
  let maxYear: number | null = null;
  let followOnCount = 0;

  for (const grant of grants) {
    const { match, followOns } = findReporterMatch(grant, reporterData);
    const all = match ? [match, ...followOns] : [];
    followOnCount += followOns.length;
    for (const proj of all) {
      if (proj.amount != null) totalFunding += proj.amount;
      if (minYear === null || proj.fiscalYear < minYear) minYear = proj.fiscalYear;
      if (maxYear === null || proj.fiscalYear > maxYear) maxYear = proj.fiscalYear;
    }
  }

  return { totalFunding, minYear, maxYear, followOnCount };
}

/** Collect all follow-on projects across all grants in a publication */
export function collectFollowOns(
  grantsString: string,
  reporterData: NIHReporterData | null | undefined
): { grant: ParsedGrant; followOns: ReporterProjectSummary[] }[] {
  const grants = parseGrants(grantsString);
  const results: { grant: ParsedGrant; followOns: ReporterProjectSummary[] }[] = [];
  for (const grant of grants) {
    const { followOns } = findReporterMatch(grant, reporterData);
    if (followOns.length > 0) {
      results.push({ grant, followOns });
    }
  }
  return results;
}

function GrantItem({
  grant,
  index,
  reporterData,
}: {
  grant: ParsedGrant;
  index: number;
  reporterData?: NIHReporterData | null;
}) {
  const { match, followOns } = findReporterMatch(grant, reporterData);

  if (grant.isNIH) {
    return (
      <div className="space-y-0.5">
        <p className="text-xs font-medium text-foreground">
          {index + 1}. {grant.instituteName}
        </p>
        <p className="text-xs text-muted-foreground">{grant.activityCodeName}</p>
        <p className="text-xs font-mono text-foreground">{grant.coreProjectNumber}</p>
        {match && (
          <div className="mt-1 pl-2 border-l-2 border-muted space-y-0.5">
            <p className="text-[10px] text-muted-foreground">
              {formatDate(match.startDate)} → {formatDate(match.endDate)}
              {match.isActive && (
                <span className="ml-1.5 text-green-600 font-medium">● Active</span>
              )}
            </p>
            {match.amount != null && (
              <p className="text-[10px] text-muted-foreground">
                Award: ${(match.amount / 1000).toFixed(0)}K (FY{match.fiscalYear})
              </p>
            )}
            {followOns.length > 0 && (
              <p className="text-[10px] font-medium text-primary">
                +{followOns.length} follow-on {followOns.length === 1 ? 'year' : 'years'} found
              </p>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <p className="text-xs font-medium text-foreground">
        {index + 1}. {grant.raw}
      </p>
    </div>
  );
}

/** Follow-on grants hover badge */
export function FollowOnGrantsHoverCard({
  grantsString,
  reporterData,
}: GrantsHoverCardProps) {
  const followOnData = collectFollowOns(grantsString, reporterData);
  const totalFollowOns = followOnData.reduce((sum, d) => sum + d.followOns.length, 0);
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout>>(null);

  if (totalFollowOns === 0) return null;

  const show = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };
  const hide = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  return (
    <HoverCard open={open} openDelay={0} closeDelay={0}>
      <HoverCardTrigger asChild>
        <span
          role="button"
          tabIndex={-1}
          className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20 cursor-default tabular-nums"
          onMouseEnter={show}
          onMouseLeave={hide}
          onClick={(e) => e.stopPropagation()}
        >
          {totalFollowOns} Follow-on
        </span>
      </HoverCardTrigger>
      <HoverCardContent
        className="w-96 max-h-[28rem] overflow-y-auto"
        side="left"
        onMouseEnter={show}
        onMouseLeave={hide}
      >
        <div className="space-y-4">
          <p className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Follow-on Grant Details
          </p>
          {followOnData.map(({ grant, followOns }, gi) => (
            <div key={`${grant.coreProjectNumber}-${gi}`} className="space-y-2">
              <p className="text-sm font-semibold text-foreground">
                {grant.instituteName ?? grant.raw}
              </p>
              {grant.coreProjectNumber && (
                <p className="text-sm font-mono text-muted-foreground">{grant.coreProjectNumber}</p>
              )}
              {followOns.map((proj, i) => (
                <div key={`${proj.projectNum}-${i}`} className="pl-2 border-l-2 border-muted space-y-1">
                  <p className="text-sm text-muted-foreground">
                    FY{proj.fiscalYear}: {formatDate(proj.startDate)} → {formatDate(proj.endDate)}
                    {proj.isActive && (
                      <span className="ml-1.5 text-green-600 font-medium">● Active</span>
                    )}
                  </p>
                  {proj.amount != null && (
                    <p className="text-sm text-muted-foreground">
                      Award: ${(proj.amount / 1000).toFixed(0)}K
                    </p>
                  )}
                  {proj.title && (
                    <p className="text-sm text-foreground leading-snug">{proj.title}</p>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}

export default function GrantsHoverCard({ grantsString, reporterData }: GrantsHoverCardProps) {
  const grants = parseGrants(grantsString);
  const count = grants.length;
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout>>(null);

  if (count === 0) return <span className="text-muted-foreground">—</span>;

  const show = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };

  const hide = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  return (
    <HoverCard open={open} openDelay={0} closeDelay={0}>
      <HoverCardTrigger asChild>
        <span
          role="button"
          tabIndex={-1}
          className="inline-flex items-center rounded-full border border-input bg-background px-2.5 py-0.5 text-xs font-semibold text-foreground transition-colors hover:bg-accent hover:text-accent-foreground cursor-default tabular-nums"
          onMouseEnter={show}
          onMouseLeave={hide}
          onClick={(e) => e.stopPropagation()}
        >
          {count} {count === 1 ? 'Grant' : 'Grants'}
        </span>
      </HoverCardTrigger>
      <HoverCardContent
        className="w-80 max-h-96 overflow-y-auto"
        side="left"
        onMouseEnter={show}
        onMouseLeave={hide}
      >
        <div className="space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Grant Details
          </p>
          {grants.map((grant, i) => (
            <GrantItem
              key={`${grant.coreProjectNumber ?? grant.raw}-${i}`}
              grant={grant}
              index={i}
              reporterData={reporterData}
            />
          ))}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
