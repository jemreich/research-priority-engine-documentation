import { useState } from "react";
import { useAppStore } from "@/store/AppContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Loader2, CheckCircle } from "lucide-react";
import { batchEnrichJournals, type BatchEnrichInput } from "@/lib/openAlexApi";
import { resolveJournal } from "@/lib/journalResolutionApi";
import { getHRCSCategory } from "@/lib/hrcsEnrichment";
import { toast } from "sonner";

export default function JournalEnrichmentPanel() {
  const { state, dispatch } = useAppStore();
  const [running, setRunning] = useState(false);
  const [statusLabel, setStatusLabel] = useState("");
  const [progress, setProgress] = useState({ done: 0, total: 0 });

  const allJournals = [...new Set(state.publications.map((p) => p.journal).filter(Boolean))];
  const enrichedNames = new Set(state.journalCache.flatMap((j) => [j.journalName, j.originalName].filter(Boolean)));
  const unenriched = allJournals.filter((j) => !enrichedNames.has(j));
  // Cached entries that never got an HRCS category (created before HRCS enrichment existed,
  // or whose lookup failed). These need a backfill so the SpecialtyBadge hover can show
  // WHO market size / CAGR data.
  const missingHrcs = state.journalCache.filter((j) => !j.hrcsCategory);
  const totalToProcess = unenriched.length + missingHrcs.length;

  const handleEnrich = async () => {
    if (totalToProcess === 0) {
      toast.info("All journals are already enriched.");
      return;
    }

    setRunning(true);
    setProgress({ done: 0, total: Math.max(unenriched.length, 1) });

    try {
      // Step 0: Resolve abbreviations → full titles + ISSNs via the cascade.
      const resolutionInputs: BatchEnrichInput[] = [];
      if (unenriched.length > 0) {
        setStatusLabel("Resolving journal names (CrossRef → NLM → OpenAlex)...");
        setProgress({ done: 0, total: unenriched.length });

        // Build abbreviation → sample DOI map (first matching pub with a DOI).
        const sampleDoiByAbbr = new Map<string, string>();
        for (const pub of state.publications) {
          if (!pub.journal || !pub.doi) continue;
          if (!sampleDoiByAbbr.has(pub.journal)) {
            sampleDoiByAbbr.set(pub.journal, pub.doi);
          }
        }

        for (let i = 0; i < unenriched.length; i++) {
          const abbr = unenriched[i];
          try {
            const resolved = await resolveJournal({
              isoAbbreviation: abbr,
              doi: sampleDoiByAbbr.get(abbr) ?? null,
            });
            if (resolved.tier === "UNRESOLVED") {
              dispatch({ type: "ADD_UNRESOLVED_JOURNAL", payload: { abbreviation: abbr } });
            }
            resolutionInputs.push({
              abbreviation: abbr,
              resolvedFullTitle: resolved.fullTitle,
              issns: resolved.issns,
              resolutionTier: resolved.tier,
            });
          } catch (err) {
            console.warn(`Resolution failed for "${abbr}":`, err);
            dispatch({ type: "ADD_UNRESOLVED_JOURNAL", payload: { abbreviation: abbr } });
            resolutionInputs.push({ abbreviation: abbr });
          }
          setProgress({ done: i + 1, total: unenriched.length });
          // Light throttle — CrossRef + NLM together can be ~3 req/sec without API keys
          if (i < unenriched.length - 1) {
            await new Promise((r) => setTimeout(r, 200));
          }
        }
      }

      // Step 1: OpenAlex / SCImago / h5 enrichment using resolved full titles + ISSNs
      let enrichments: typeof state.journalCache = [];
      if (resolutionInputs.length > 0) {
        setStatusLabel("Enriching journals (OpenAlex + SCImago + Google Scholar)...");
        const results = await batchEnrichJournals(resolutionInputs, (done, total) => {
          setProgress({ done, total });
        });
        enrichments = Array.from(results.values());
      }

      // Step 2: HRCS category resolution — for both newly-enriched journals
      // AND cached journals missing an HRCS category (backfill).
      const needsHrcs = [...enrichments, ...missingHrcs];
      setStatusLabel(
        missingHrcs.length > 0 && unenriched.length > 0
          ? `Resolving HRCS health categories (incl. ${missingHrcs.length} backfill)...`
          : missingHrcs.length > 0
            ? `Backfilling HRCS health categories for ${missingHrcs.length} cached journals...`
            : "Resolving HRCS health categories..."
      );
      setProgress({ done: 0, total: needsHrcs.length });

      const withHRCS: typeof needsHrcs = [];
      let hrcsFailures = 0;
      for (let i = 0; i < needsHrcs.length; i++) {
        const entry = needsHrcs[i];
        try {
          const hrcsCategory = await getHRCSCategory(entry.journalName);
          withHRCS.push({
            ...entry,
            hrcsCategory,
            hrcsCategoryResolvedAt: new Date().toISOString(),
          });
        } catch {
          hrcsFailures++;
          withHRCS.push({
            ...entry,
            hrcsCategory: "Generic health relevance",
            hrcsCategoryResolvedAt: new Date().toISOString(),
          });
        }
        setProgress({ done: i + 1, total: needsHrcs.length });
        // Throttle: ~8 req/sec (each journal = up to 2 NCBI calls => stay well under 10/sec)
        if (i < needsHrcs.length - 1) {
          await new Promise((r) => setTimeout(r, 250));
        }
      }

      if (withHRCS.length > 0) {
        dispatch({ type: "ADD_JOURNAL_CACHE", payload: withHRCS });
      }

      const parts: string[] = [];
      if (enrichments.length > 0) parts.push(`Enriched ${enrichments.length} new journals`);
      if (missingHrcs.length > 0) parts.push(`backfilled HRCS for ${missingHrcs.length} cached journals`);
      const successMsg = parts.join(" · ") || "Journal enrichment complete.";
      if (hrcsFailures > 0) {
        toast.success(`${successMsg}. ${hrcsFailures} HRCS lookup(s) used fallback category.`);
      } else {
        toast.success(successMsg);
      }
    } catch (err) {
      console.error("Journal enrichment error:", err);
      toast.error("Journal enrichment failed.");
    } finally {
      setRunning(false);
      setStatusLabel("");
    }
  };

  if (state.publications.length === 0) return null;

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/30">
        <BookOpen className="h-4 w-4 text-muted-foreground shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-sm text-foreground">
            <span className="font-medium">Journal Enrichment</span>
            {" · "}
            <span className="text-muted-foreground">
              {state.journalCache.length} of {allJournals.length} journals enriched
              {unenriched.length > 0 && ` · ${unenriched.length} pending`}
              {missingHrcs.length > 0 && ` · ${missingHrcs.length} missing HRCS`}
              {state.unresolvedJournals.length > 0 && ` · ${state.unresolvedJournals.length} unresolved`}
            </span>
          </p>
          {running && (
            <>
              <Progress value={(progress.done / Math.max(progress.total, 1)) * 100} className="h-1.5 mt-1.5" />
              <p className="text-xs text-muted-foreground mt-1">
                {statusLabel || `Processing ${progress.done} of ${progress.total}...`}
              </p>
            </>
          )}
        </div>
        {totalToProcess === 0 && state.journalCache.length > 0 ? (
          <Badge variant="secondary" className="gap-1">
            <CheckCircle className="h-3 w-3" /> Done
          </Badge>
        ) : (
          <Button size="sm" onClick={handleEnrich} disabled={running || totalToProcess === 0}>
            {running ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin mr-1" />
                {progress.done}/{progress.total}
              </>
            ) : unenriched.length > 0 && missingHrcs.length > 0 ? (
              `Enrich ${unenriched.length} + Backfill ${missingHrcs.length}`
            ) : unenriched.length > 0 ? (
              `Enrich ${unenriched.length} Journals`
            ) : (
              `Backfill HRCS for ${missingHrcs.length}`
            )}
          </Button>
        )}
      </div>
    </div>
  );
}
