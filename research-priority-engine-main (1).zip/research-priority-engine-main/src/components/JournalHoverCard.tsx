import React, { useRef, useState } from "react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import type { JournalEnrichment } from "@/types";
import { BookOpen } from "lucide-react";

interface JournalHoverCardProps {
  journalEnrichment: JournalEnrichment;
}

const TIER_LABELS: Record<NonNullable<JournalEnrichment["resolutionTier"]>, string> = {
  CROSSREF_DOI: "CrossRef (DOI)",
  NLM_CATALOG: "NLM Catalog",
  OPENALEX_ISSN: "OpenAlex (ISSN)",
  OPENALEX_TEXT: "OpenAlex (text search)",
  UNRESOLVED: "Unresolved — abbreviation",
};

function MetricRow({ label, value, source }: { label: string; value: string | number | null; source: string }) {
  return (
    <div className="p-1.5 rounded bg-muted">
      <p className="text-[9px] text-muted-foreground">{label}</p>
      <p className="text-xs font-bold text-foreground">
        {value != null ? String(value) : <span className="text-muted-foreground font-normal italic">pending</span>}
      </p>
      <p className="text-[8px] text-muted-foreground">{source}</p>
    </div>
  );
}

export default function JournalHoverCard({ journalEnrichment: je }: JournalHoverCardProps) {
  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout>>(null);

  const show = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };

  const hide = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  const tierLabel = je.resolutionTier ? TIER_LABELS[je.resolutionTier] : null;

  return (
    <HoverCard open={open} openDelay={0} closeDelay={0}>
      <HoverCardTrigger asChild>
        <span
          role="button"
          tabIndex={-1}
          className="inline-flex items-center rounded-full border border-input bg-background px-2.5 py-0.5 text-xs font-semibold text-foreground transition-colors hover:bg-accent hover:text-accent-foreground cursor-default gap-1 max-w-[260px]"
          onMouseEnter={show}
          onMouseLeave={hide}
          onClick={(e) => e.stopPropagation()}
        >
          <BookOpen className="h-3 w-3 shrink-0" />
          <span className="truncate">{je.journalName}</span>
        </span>
      </HoverCardTrigger>
      <HoverCardContent className="w-72" side="top" onMouseEnter={show} onMouseLeave={hide}>
        <div className="space-y-3">
          <div>
            <p className="text-sm font-semibold text-foreground leading-snug">{je.journalName}</p>
            {je.originalName && je.originalName !== je.journalName && (
              <p className="text-[10px] text-muted-foreground mt-0.5">
                PubMed abbreviation: <span className="font-mono">{je.originalName}</span>
              </p>
            )}
            {je.issns && je.issns.length > 0 && (
              <p className="text-[10px] text-muted-foreground">
                ISSN: <span className="font-mono">{je.issns.join(", ")}</span>
              </p>
            )}
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">Google Scholar</p>
            {je.h5Index === null && je.h5Median === null ? (
              <p className="text-xs text-muted-foreground">Metrics unavailable.</p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <MetricRow label="h5-index" value={je.h5Index} source="Google Scholar" />
                <MetricRow label="h5-median" value={je.h5Median} source="Google Scholar" />
              </div>
            )}
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">SCImago (2024)</p>
            {je.sjr === null &&
            je.sjrQuartile === null &&
            je.sjrHIndex === null &&
            je.citPerDoc2yr === null &&
            je.totalDocs3yr === null ? (
              <p className="text-xs text-muted-foreground">Metrics unavailable.</p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <MetricRow label="SJR" value={je.sjr} source="SCImago" />
                <MetricRow label="SJR Quartile" value={je.sjrQuartile} source="SCImago" />
                <MetricRow label="H-index" value={je.sjrHIndex} source="SCImago" />
                <MetricRow label="Cit/Doc (2yr)" value={je.citPerDoc2yr} source="SCImago" />
                <MetricRow label="Docs (3yr)" value={je.totalDocs3yr} source="SCImago" />
              </div>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground border-t border-border pt-2">
            Source: SCImago SJR + Google Scholar h5
            {tierLabel ? ` · Resolution: ${tierLabel}` : ""}
          </p>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
