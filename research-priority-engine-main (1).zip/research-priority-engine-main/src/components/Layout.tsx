import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { LayoutDashboard, Upload, SlidersHorizontal, Download, Shield, Settings, ClipboardList, Users, BarChart3 } from 'lucide-react';
import type { ReactNode } from 'react';

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/pi-profiles', label: 'PI Profiles', icon: Users },
  { to: '/summary', label: 'Summary Stats', icon: BarChart3 },
  { to: '/weights', label: 'Weight Config', icon: SlidersHorizontal },
  { to: '/admin', label: 'Admin Config', icon: Settings },
  { to: '/audit', label: 'Audit Log', icon: ClipboardList },
  { to: '/upload', label: 'Upload Data', icon: Upload },
  { to: '/export', label: 'Export', icon: Download },
];

export default function Layout({ children }: { children: ReactNode }) {
  const location = useLocation();

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="w-64 border-r border-border bg-sidebar-background flex flex-col">
        <div className="p-6 border-b border-border">
          <h1 className="text-lg font-bold text-sidebar-foreground">Research Prioritizer</h1>
          <p className="text-xs text-muted-foreground mt-1">EMR Request ROI Scoring</p>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(item => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors',
                location.pathname === item.to
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Shield className="h-3 w-3" />
            <span>All data stays local</span>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
