import { useState, useCallback } from 'react';
import { useAppStore } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Users, Loader2, CheckCircle2, AlertTriangle } from 'lucide-react';
import { batchEnrichPIs } from '@/lib/nihReporterApi';
import UnprocessedRecordsPopover from '@/components/UnprocessedRecordsPopover';

export default function PIEnrichmentPanel() {
  const { state, dispatch } = useAppStore();
  const [enriching, setEnriching] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);

  const uniquePIs = [...new Set(state.requests.map(r => r.pi).filter(Boolean))];
  const enrichedCount = state.piCache.filter(p => p.status === 'enriched').length;
  const unenrichedCount = uniquePIs.filter(
    pi => !state.piCache.find(c => c.piName === pi && c.status === 'enriched')
  ).length;

  const handleEnrich = useCallback(async () => {
    if (uniquePIs.length === 0) return;

    setEnriching(true);
    setProgress(0);
    setTotal(uniquePIs.length);

    // Reindex: clear the entire PI cache before re-enriching so stale
    // entries (renames, removed PIs, prior errors) never accumulate.
    dispatch({ type: 'SET_PI_CACHE', payload: [] });

    try {
      const results = await batchEnrichPIs(uniquePIs, (completed, t) => {
        setProgress(completed);
        setTotal(t);
      });

      dispatch({ type: 'SET_PI_CACHE', payload: results });

      const enriched = results.filter(r => r.status === 'enriched').length;
      const errors = results.filter(r => r.status === 'error').length;
      toast.success(`PI enrichment complete: ${enriched} enriched, ${errors} errors`);
    } catch (err) {
      toast.error('PI enrichment failed: ' + (err instanceof Error ? err.message : 'Unknown error'));
    } finally {
      setEnriching(false);
    }
  }, [uniquePIs, dispatch]);

  return (
    <div className="border border-border rounded-lg p-4 space-y-3 bg-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold text-foreground">PI Grant Enrichment</h3>
          {enrichedCount > 0 && (
            <Badge variant="secondary" className="text-xs">
              {enrichedCount} PIs enriched
            </Badge>
          )}
          {unenrichedCount > 0 && (
            <Badge variant="outline" className="text-xs">
              {unenrichedCount} pending
            </Badge>
          )}
        </div>
        <Button
          size="sm"
          onClick={handleEnrich}
          disabled={enriching || uniquePIs.length === 0}
        >
          {enriching ? (
            <>
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              {progress}/{total}...
            </>
          ) : (
            <>
              <Users className="h-4 w-4 mr-1" />
              Enrich PIs ({uniquePIs.length})
            </>
          )}
        </Button>
      </div>

      {enriching && (
        <div className="space-y-1">
          <Progress value={total > 0 ? (progress / total) * 100 : 0} className="h-2" />
          <p className="text-xs text-muted-foreground">
            Fetching grant data from NIH RePORTER... {progress} of {total}
          </p>
        </div>
      )}

      {!enriching && enrichedCount > 0 && (
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1 text-green-600">
            <CheckCircle2 className="h-3 w-3" />
            {enrichedCount} PIs with grant data
          </div>
          {(() => {
            const errorPIs = state.piCache.filter(p => p.status === 'error');
            const errorRecordIds = state.requests
              .filter(r => errorPIs.some(e => e.piName === r.pi))
              .map(r => r.recordId);
            return (
              <UnprocessedRecordsPopover
                label="errors"
                recordIds={errorRecordIds}
                variant="destructive"
                icon={<AlertTriangle className="h-3 w-3" />}
              />
            );
          })()}
          {(() => {
            const noGrantIds = state.requests
              .filter(r => {
                const cached = state.piCache.find(c => c.piName === r.pi);
                return cached && cached.status === 'enriched' && (cached.grantCount === null || cached.grantCount === 0);
              })
              .map(r => r.recordId);
            return (
              <UnprocessedRecordsPopover
                label="no grants found"
                recordIds={noGrantIds}
                icon={<AlertTriangle className="h-3 w-3" />}
                variant="warning"
              />
            );
          })()}
        </div>
      )}
    </div>
  );
}
