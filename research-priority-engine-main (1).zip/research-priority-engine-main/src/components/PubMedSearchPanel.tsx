import { useState, useCallback } from "react";
import { useAppStore } from "@/store/AppContext";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Search, Loader2, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import {
  batchSearchPubMed,
  toRequestPublication,
  type PubMedQueryInput,
  type PubMedSearchResult,
} from "@/lib/pubmedApi";
import { fetchICiteMetrics } from "@/lib/iciteApi";
import crosswalk from "@/lib/hrcs-crosswalk.json";
import { getHRCSCategory } from "@/lib/hrcsEnrichment";
import { getNcbiApiKey } from "@/lib/apiKeys";
import UnprocessedRecordsPopover from "@/components/UnprocessedRecordsPopover";

export default function PubMedSearchPanel() {
  const { state, dispatch } = useAppStore();
  const [searching, setSearching] = useState(false);
  const [enriching, setEnriching] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [statusLabel, setStatusLabel] = useState("");
  const [results, setResults] = useState<PubMedSearchResult[] | null>(null);

  const hasApiKey = !!getNcbiApiKey();
  const requestCount = state.requests.length;

  const handleSearch = useCallback(async () => {
    if (requestCount === 0) return;

    const inputs: PubMedQueryInput[] = state.requests.map((r) => ({
      recordId: r.recordId,
      piName: r.pi,
      yearCompleted: r.dateCompleted ? new Date(r.dateCompleted).getFullYear() : null,
      department: r.department,
      projectTitle: r.projectTitle,
    }));

    setSearching(true);
    setProgress(0);
    setTotal(inputs.length);
    setResults(null);
    setStatusLabel(`Searching PubMed for ${inputs.length} requests...`);

    try {
      const searchResults = await batchSearchPubMed(inputs, (completed, t) => {
        setProgress(completed);
        setTotal(t);
      });

      setResults(searchResults);

      // Convert and store publications
      const allPubs = searchResults.flatMap((r) => r.publications.map((p) => toRequestPublication(p)));

      if (allPubs.length > 0) {
        dispatch({ type: "ADD_PUBLICATIONS", payload: allPubs });

        // Step 2: Enrich with iCite metrics
        const pmids = allPubs.map((p) => p.pmid);
        setEnriching(true);
        setProgress(0);
        setTotal(pmids.length);
        setStatusLabel(`Fetching citation metrics from iCite for ${pmids.length} publications...`);

        try {
          const metricsMap = await fetchICiteMetrics(pmids, (done, tot) => {
            setProgress(done);
            setTotal(tot);
          });

          // Update publications with iCite data
          const enriched = allPubs.map((pub) => {
            const m = metricsMap.get(pub.pmid);
            if (!m) return pub;
            return {
              ...pub,
              relativeCitationRatio: m.relativeCitationRatio,
              citationCount: m.citationCount,
              apt: m.apt,
              nihPercentile: m.nihPercentile,
              citationsPerYear: m.citationsPerYear,
              expectedCitationsPerYear: m.expectedCitationsPerYear,
              fieldCitationRate: m.fieldCitationRate,
              isClinical: m.isClinical,
              iciteEnrichedAt: new Date().toISOString(),
            };
          });

          dispatch({ type: "UPDATE_PUBLICATIONS", payload: enriched });
          toast.success(`iCite enrichment complete: ${metricsMap.size} of ${pmids.length} PMIDs enriched`);
        } catch (iciteErr) {
          toast.error("iCite enrichment failed: " + (iciteErr instanceof Error ? iciteErr.message : "Unknown error"));
        } finally {
          setEnriching(false);
        }
      }

      const matched = searchResults.filter((r) => r.status === "matched").length;
      const noResults = searchResults.filter((r) => r.status === "no_results").length;
      const errors = searchResults.filter((r) => r.status === "error").length;
      toast.success(`PubMed search complete: ${matched} matched, ${noResults} no results, ${errors} errors`);
    } catch (err) {
      toast.error("PubMed search failed: " + (err instanceof Error ? err.message : "Unknown error"));
    } finally {
      setSearching(false);
      setStatusLabel("");
    }
  }, [state.requests, requestCount, dispatch]);

  const matched = results?.filter((r) => r.status === "matched").length ?? 0;
  const noResults = results?.filter((r) => r.status === "no_results").length ?? 0;
  const filteredOut = results?.filter((r) => r.status === "filtered_out").length ?? 0;
  const errors = results?.filter((r) => r.status === "error").length ?? 0;
  const totalPubs = results?.reduce((sum, r) => sum + r.publications.length, 0) ?? 0;

  return (
    <div className="border border-border rounded-lg p-4 space-y-3 bg-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold text-foreground">PubMed Publication Search</h3>
          {!hasApiKey && (
            <Badge variant="outline" className="text-xs">
              No API key — slower rate limit
            </Badge>
          )}
          {state.publications.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {state.publications.length} publications stored
            </Badge>
          )}
        </div>
        <Button size="sm" onClick={handleSearch} disabled={searching || enriching || requestCount === 0}>
          {searching || enriching ? (
            <>
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              {enriching ? `iCite ${progress}/${total}...` : `PubMed ${progress}/${total}...`}
            </>
          ) : (
            <>
              <Search className="h-4 w-4 mr-1" />
              Search PubMed ({requestCount})
            </>
          )}
        </Button>
      </div>

      {(searching || enriching) && (
        <div className="space-y-1">
          <Progress value={total > 0 ? (progress / total) * 100 : 0} className="h-2" />
          <p className="text-xs text-muted-foreground">{statusLabel || `Processing ${progress} of ${total}...`}</p>
        </div>
      )}

      {results && !searching && (
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1 text-green-600">
            <CheckCircle2 className="h-3 w-3" />
            {matched} matched ({totalPubs} pubs)
          </div>
          <UnprocessedRecordsPopover
            label="no results"
            recordIds={results?.filter((r) => r.status === "no_results").map((r) => r.recordId) ?? []}
            icon={<XCircle className="h-3 w-3" />}
          />
          <UnprocessedRecordsPopover
            label="filtered out"
            recordIds={results?.filter((r) => r.status === "filtered_out").map((r) => r.recordId) ?? []}
            variant="warning"
            icon={<AlertTriangle className="h-3 w-3" />}
          />
          <UnprocessedRecordsPopover
            label="errors"
            recordIds={results?.filter((r) => r.status === "error").map((r) => r.recordId) ?? []}
            variant="destructive"
            icon={<AlertTriangle className="h-3 w-3" />}
          />
        </div>
      )}
    </div>
  );
}
