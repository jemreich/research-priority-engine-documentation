import { useState } from 'react';
import type { RedcapRequest, RequestScore } from '@/types';
import { useAppStore } from '@/store/AppContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import doiJournalMap from '@/lib/doiJournalMap.json';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, ArrowUpDown, BookOpen, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import GrantsHoverCard, { FollowOnGrantsHoverCard, computeGrantFundingSummary } from '@/components/GrantsHoverCard';
import JournalHoverCard from '@/components/JournalHoverCard';
import SpecialtyBadge from '@/components/SpecialtyBadge';
import { countGrants } from '@/lib/grantParser';
import { resolveHRCSCategory } from '@/lib/hrcsCategory';
import { canonicalPIName } from '@/lib/piNameNormalize';

interface RequestDetailProps {
  request: RedcapRequest | null;
  open: boolean;
  onClose: () => void;
}

export default function RequestDetail({ request, open, onClose }: RequestDetailProps) {
  const { state, dispatch } = useAppStore();
  const [overrideRank, setOverrideRank] = useState('');
  const [overrideReason, setOverrideReason] = useState('');

  if (!request) return null;

  const score = state.scores.find(s => s.recordId === request.recordId);
  const tracHours = state.tracHours.filter(t => t.recordId === request.recordId);
  const summedTracHours = tracHours.reduce((sum, t) => sum + t.totalHours, 0);
  const totalHours = summedTracHours > 0 ? summedTracHours : (request.tracTime && request.tracTime > 0 ? request.tracTime : 2);
  const publications = state.publications.filter(p => p.recordId === request.recordId);
  const requestPiKey = canonicalPIName(request.pi);
  const piData =
    state.piCache.find(p => p.piName === request.pi) ??
    state.piCache.find(p => canonicalPIName(p.piName) === requestPiKey);
  const getJournal = (name: string) => {
    if (!name) return undefined;
    const direct = state.journalCache.find(j => j.journalName === name || j.originalName === name);
    if (direct) return direct;
    // Fall back to ISSN match (resolution pipeline stores ISSNs on enriched entries)
    return state.journalCache.find(j => (j.issns ?? []).includes(name));
  };
  const isOpen = !request.dateCompleted;

  const handleOverride = () => {
    const rank = parseInt(overrideRank);
    if (!rank || rank < 1 || !overrideReason.trim()) {
      toast.error('Enter a valid rank and reason');
      return;
    }
    dispatch({
      type: 'ADD_OVERRIDE',
      payload: {
        id: crypto.randomUUID(),
        recordId: request.recordId,
        piName: request.pi,
        previousRank: score?.rank ?? null,
        newRank: rank,
        reason: overrideReason.trim(),
        user: 'Data Manager',
        timestamp: new Date().toISOString(),
      },
    });
    toast.success(`Rank overridden to #${rank}`);
    setOverrideRank('');
    setOverrideReason('');
  };

  const ScoringTierBadge = () => {
    if (!score || score.scoringTier === null) {
      return <Badge variant="destructive">Tier 3 — Insufficient Data</Badge>;
    }
    if (score.scoringTier === 2) {
      return <Badge variant="secondary">Tier 2 — Proxy Scored</Badge>;
    }
    return <Badge>Tier 1 — Full Enrichment</Badge>;
  };

  return (
    <Sheet open={open} onOpenChange={v => !v && onClose()}>
      <SheetContent className="w-[500px] sm:w-[600px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <span className="font-mono text-muted-foreground">#{request.recordId}</span>
            {isOpen ? <Badge>Open</Badge> : <Badge variant="secondary">Closed</Badge>}
          </SheetTitle>
          <SheetDescription className="text-left">{request.projectTitle || 'No title'}</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Principal Investigator */}
          <section className="space-y-2">
            <h3 className="text-sm font-semibold text-foreground">Principal Investigator</h3>
            <div className="p-3 rounded-md bg-muted space-y-3">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div><span className="text-muted-foreground">Name:</span> {request.pi}</div>
                <div><span className="text-muted-foreground">Rank:</span> {request.facultyRank || '—'}</div>
                <div><span className="text-muted-foreground">Dept:</span> {request.department}</div>
                <div><span className="text-muted-foreground">Email:</span> {request.piEmail || '—'}</div>
              </div>
              {piData && piData.status === 'enriched' && (
                <>
                  <Separator />
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">NIH RePORTER Profile</p>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center p-2 rounded bg-background">
                        <p className="text-[10px] text-muted-foreground">Grants</p>
                        <p className="text-sm font-bold text-foreground">{piData.grantCount ?? '—'}</p>
                      </div>
                      <div className="text-center p-2 rounded bg-background">
                        <p className="text-[10px] text-muted-foreground">Active</p>
                        <p className="text-sm font-bold text-foreground">{piData.activeGrants ?? '—'}</p>
                      </div>
                      <div className="text-center p-2 rounded bg-background">
                        <p className="text-[10px] text-muted-foreground">Total Funding</p>
                        <p className="text-sm font-bold text-foreground">
                          {piData.totalGrantFunding != null
                            ? `$${(piData.totalGrantFunding / 1_000_000).toFixed(1)}M`
                            : '—'}
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </section>

          <Separator />

          {/* Request Details */}
          <section className="space-y-2">
            <h3 className="text-sm font-semibold text-foreground">Request Details</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-muted-foreground">Requested:</span> {request.dateOfRequest}</div>
              <div><span className="text-muted-foreground">Completed:</span> {request.dateCompleted || 'Open'}</div>
              <div><span className="text-muted-foreground">Type:</span> {request.requestType || '—'}</div>
              <div><span className="text-muted-foreground">Funding:</span> {request.fundingSource || '—'}</div>
              <div><span className="text-muted-foreground">IRB:</span> {request.irbNumber || '—'}</div>
              <div><span className="text-muted-foreground">Deadline:</span> {request.dataDeadline || '—'}</div>
            </div>
            {request.initiative && (
              <div className="text-sm mt-2">
                <span className="text-muted-foreground">Initiative:</span>
                <p className="mt-1 text-foreground">{request.initiative}</p>
              </div>
            )}
          </section>

          <Separator />

          {/* Scoring */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              Score Breakdown
              <ScoringTierBadge />
            </h3>
            {score && score.status === 'scored' ? (
              <div className="space-y-2 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-xs text-muted-foreground">Weighted Return</p>
                    <p className="text-lg font-bold text-foreground">{score.weightedReturnScore?.toFixed(1) ?? '—'}</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-xs text-muted-foreground">Effort-Adjusted ROI</p>
                    <p className="text-lg font-bold text-foreground">{score.effortAdjustedROIScore?.toFixed(1) ?? '—'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div><span className="text-muted-foreground">Publication Impact:</span> {score.publicationImpactScore?.toFixed(1) ?? 'N/A'}</div>
                  <div><span className="text-muted-foreground">Journal Prestige:</span> {score.journalPrestigeScore?.toFixed(1) ?? 'N/A'}</div>
                  <div><span className="text-muted-foreground">Funding Activity:</span> {score.fundingActivityScore?.toFixed(1) ?? 'N/A'}</div>
                  <div><span className="text-muted-foreground">Research Output:</span> {score.researchOutputScore?.toFixed(1) ?? 'N/A'}</div>
                </div>
                <div className="text-xs text-muted-foreground">
                  Effort multiplier: {score.effortMultiplier?.toFixed(2) ?? '—'} (anchor {state.adminConfig.effortAnchorHours ?? 2}h, exp {(state.adminConfig.effortDampening ?? 0.5).toFixed(2)}) | Hours: {totalHours ?? '—'}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
                <AlertTriangle className="h-4 w-4" />
                Scoring pending — enrichment data not yet available.
              </div>
            )}
          </section>

          <Separator />

          {/* Publications */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Publications ({publications.length})
            </h3>
            {publications.length > 0 ? (
              <div className="space-y-2">
                {publications.map(pub => (
                  <div key={pub.pmid} className="p-3 rounded-md bg-muted text-sm space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-muted-foreground">PMID: {pub.pmid}</span>
                      {pub.authorCount != null && (
                        <span className="text-xs text-muted-foreground">· {pub.authorCount} author{pub.authorCount === 1 ? '' : 's'}</span>
                      )}
                    </div>
                    {pub.title && <div className="font-medium text-foreground leading-snug">{pub.title}</div>}
                    {/* Cumulative funding summary */}
                    {pub.grants && (() => {
                      const summary = computeGrantFundingSummary(pub.grants, piData?.nihReporterData);
                      if (summary.totalFunding > 0) {
                        const yearRange = summary.minYear && summary.maxYear
                          ? summary.minYear === summary.maxYear
                            ? `FY${summary.minYear}`
                            : `FY${summary.minYear}–${summary.maxYear}`
                          : '';
                        return (
                          <p className="text-[11px] text-muted-foreground">
                            Cumulative funding: ${(summary.totalFunding / 1_000_000).toFixed(2)}M{yearRange ? ` (${yearRange})` : ''}
                          </p>
                        );
                      }
                      return null;
                    })()}
                    {/* Badges row: Journal, Specialty, Grants, Follow-on */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-1">
                      {(() => {
                        const je = getJournal(pub.journal);
                        const fullJournalName = pub.doi
                          ? (doiJournalMap as Record<string, string>)[pub.doi.toLowerCase()] ?? je?.journalName ?? pub.journal
                          : je?.journalName ?? pub.journal;
                        const enrichmentWithFullName = je ? { ...je, journalName: fullJournalName } : null;
                        const specialty = enrichmentWithFullName?.specialty || 'Internal Medicine';
                        const hrcsCategory = resolveHRCSCategory(
                          enrichmentWithFullName?.hrcsCategory ?? null,
                          specialty,
                        );
                        return (
                          <>
                            {enrichmentWithFullName ? (
                              <JournalHoverCard journalEnrichment={enrichmentWithFullName} />
                            ) : (
                              <Badge variant="outline" className="cursor-default gap-1 text-xs max-w-[260px] truncate">
                                <BookOpen className="h-3 w-3 shrink-0" />
                                <span className="truncate">{fullJournalName}</span>
                              </Badge>
                            )}
                            <SpecialtyBadge
                              specialty={specialty}
                              hrcsCategory={hrcsCategory}
                            />
                          </>
                        );
                      })()}
                      {pub.grants && (
                        <>
                          <GrantsHoverCard grantsString={pub.grants} reporterData={piData?.nihReporterData} />
                          <FollowOnGrantsHoverCard grantsString={pub.grants} reporterData={piData?.nihReporterData} />
                        </>
                      )}
                    </div>
                    {/* Year and publication link */}
                    <div className="flex items-center gap-2 mt-1">
                      {pub.yearPublished && <span className="text-xs text-muted-foreground">{pub.yearPublished}</span>}
                      {pub.doi ? (
                        <a
                          href={`https://doi.org/${pub.doi}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-primary hover:underline flex items-center gap-1"
                          onClick={e => e.stopPropagation()}
                        >
                          View Publication <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <a
                          href={`https://pubmed.ncbi.nlm.nih.gov/${pub.pmid}/`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-primary hover:underline flex items-center gap-1"
                          onClick={e => e.stopPropagation()}
                        >
                          View Publication <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                    {/* iCite Metrics */}
                    {pub.iciteEnrichedAt && (
                      <div className="mt-2 pt-2 border-t border-border">
                        <div className="grid grid-cols-3 gap-2">
                          <div className="text-center p-1.5 rounded bg-background">
                            <p className="text-[10px] text-muted-foreground">RCR</p>
                            <p className="text-sm font-bold text-foreground">
                              {pub.relativeCitationRatio?.toFixed(2) ?? '—'}
                            </p>
                          </div>
                          <div className="text-center p-1.5 rounded bg-background">
                            <p className="text-[10px] text-muted-foreground">Citations</p>
                            <p className="text-sm font-bold text-foreground">
                              {pub.citationCount ?? '—'}
                            </p>
                          </div>
                          <div className="text-center p-1.5 rounded bg-background">
                            <p className="text-[10px] text-muted-foreground">APT</p>
                            <p className="text-sm font-bold text-foreground">
                              {pub.apt?.toFixed(2) ?? '—'}
                            </p>
                          </div>
                        </div>
                        {pub.nihPercentile != null && (
                          <p className="text-[10px] text-muted-foreground mt-1 text-center">
                            NIH Percentile: {pub.nihPercentile.toFixed(1)}%
                            {pub.isClinical !== null && ` · ${pub.isClinical ? 'Clinical' : 'Non-clinical'}`}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No publications found yet. Run PubMed search from the dashboard.</p>
            )}
          </section>

          <Separator />

          {/* Manual Override */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4" />
              Manual Rank Override
            </h3>
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="w-24">
                  <Label className="text-xs">New Rank</Label>
                  <Input
                    type="number"
                    min={1}
                    placeholder="#"
                    value={overrideRank}
                    onChange={e => setOverrideRank(e.target.value)}
                  />
                </div>
                <div className="flex-1">
                  <Label className="text-xs">Reason (required)</Label>
                  <Textarea
                    placeholder="Explain the override rationale..."
                    value={overrideReason}
                    onChange={e => setOverrideReason(e.target.value)}
                    rows={2}
                  />
                </div>
              </div>
              <Button size="sm" onClick={handleOverride} disabled={!overrideRank || !overrideReason.trim()}>
                Apply Override
              </Button>
            </div>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
