import { useState, useMemo } from 'react';
import { useAppStore } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calculator, RefreshCw, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { scoreAllRequests } from '@/lib/scoringEngine';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import UnprocessedRecordsPopover from '@/components/UnprocessedRecordsPopover';
import type { WeightConfig, AdminConfig } from '@/types';

// ─── Dynamic formula display ──────────────────────────────
// Renders the ROI formula using the user's active Weight Config so the
// displayed coefficients always match what the scoring engine uses.

type SubMetric = { label: string; weight: number };

function fmtW(w: number): string {
  // Show up to 2 decimals, strip trailing zeros (e.g. 0.40 → 0.4, 0.25 → 0.25)
  return (Math.round(w * 100) / 100).toString();
}

/** Render a weighted sum like (0.4·RCR + 0.4·NIH%ile + 0.2·log Citations) */
function WeightedSum({ parts }: { parts: SubMetric[] }) {
  const active = parts.filter(p => p.weight > 0);
  if (active.length === 0) return <span className="text-muted-foreground">—</span>;
  return (
    <span className="font-mono">
      {active.map((p, i) => (
        <span key={p.label}>
          {i > 0 && <span className="text-muted-foreground"> + </span>}
          <span className="text-primary">{fmtW(p.weight)}</span>
          <span className="text-muted-foreground">·</span>
          <span>{p.label}</span>
        </span>
      ))}
    </span>
  );
}

function FormulaDisplay({ weights, adminConfig }: { weights: WeightConfig; adminConfig: AdminConfig }) {
  // Each category's sub-metrics in display order
  const s1: SubMetric[] = [
    { label: 'RCR', weight: weights.s1_rcr },
    { label: 'NIH%ile', weight: weights.s1_nihPercentile },
    { label: 'Citations', weight: weights.s1_citationCount },
  ];
  const s2: SubMetric[] = [
    { label: 'SJR-Quartile', weight: weights.s3_sjrQuartile },
    { label: 'SJR', weight: weights.s3_sjr },
    { label: 'h5-Index', weight: weights.s3_h5Index },
    { label: 'Cit/Doc', weight: weights.s3_citPerDoc2yr },
  ];
  const s3: SubMetric[] = [
    { label: 'FundingSource', weight: weights.s4_fundingSource },
    { label: 'ActiveGrants', weight: weights.s4_activeGrants },
    { label: 'TotalFunding', weight: weights.s4_totalFunding },
  ];
  const s4: SubMetric[] = [
    { label: 'h-Index', weight: weights.s2_hIndex },
    { label: 'TotalPubs', weight: weights.s2_totalPublications },
    { label: 'TotalCites', weight: weights.s2_totalCitations },
    { label: 'FacultyRank', weight: weights.s2_facultyRank },
  ];

  // Flat ordered list of every sub-metric for the big expanded sum
  const allMetrics: SubMetric[] = [...s1, ...s2, ...s3, ...s4];

  const dampening = adminConfig.effortDampening ?? 0.5;
  const anchor = adminConfig.effortAnchorHours ?? 2;
  const isSqrt = Math.abs(dampening - 0.5) < 0.001;
  const nicheOn = adminConfig.nicheBonusEnabled !== false;
  const tierDiscountOn = adminConfig.proxyEnabled !== false;
  const proxyDiscount = adminConfig.proxyConfidenceDiscount ?? 1;
  const insufficientDiscount = adminConfig.insufficientDataDiscount ?? 0.5;

  return (
    <div className="rounded-md border border-border bg-muted/40 p-3 text-xs space-y-3">
      <div className="flex items-baseline justify-between gap-2">
        <div className="font-medium text-foreground">How ROI is calculated</div>
        <div className="text-[10px] text-muted-foreground">
          Preset: <span className="font-mono">{weights.presetName}</span>
        </div>
      </div>

      {/* Top-level formula — fully expanded weighted sum of every sub-metric */}
      <div className="font-mono text-foreground leading-relaxed">
        ROI = (
        <WeightedSum parts={allMetrics} />
        )
        {nicheOn && (
          <> · <span className="text-foreground">Niche</span></>
        )}
        {' '}·{' '}
        <span className="text-foreground">
          {isSqrt ? (
            <>√(<span className="italic">{anchor}h</span> ÷ TRAC<sub>h</sub>)</>
          ) : (
            <>(<span className="italic">{anchor}h</span> ÷ TRAC<sub>h</sub>)<sup>{fmtW(dampening)}</sup></>
          )}
        </span>
        {tierDiscountOn && (
          <>
            {' '}·{' '}
            <span className="text-foreground">
              [T1: 1, T2: <span className="text-primary">{fmtW(proxyDiscount)}</span>, T3: <span className="text-primary">{fmtW(insufficientDiscount)}</span>]
            </span>
          </>
        )}
      </div>

      {/* Reference: per-category breakdown of the same sum */}
      <div className="space-y-1.5 pl-1 border-t border-border pt-2">
        <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Grouped by category (same sum)</div>
        <div>
          <span className="font-mono text-foreground">S₁ Publication Impact</span> ={' '}
          <WeightedSum parts={s1} />
        </div>
        <div>
          <span className="font-mono text-foreground">S₂ Journal Prestige</span> ={' '}
          <WeightedSum parts={s2} />
        </div>
        <div>
          <span className="font-mono text-foreground">S₃ Funding Activity</span> ={' '}
          <WeightedSum parts={s3} />
        </div>
        <div>
          <span className="font-mono text-foreground">S₄ Research Output</span> ={' '}
          <WeightedSum parts={s4} />
        </div>
      </div>

      <ul className="text-muted-foreground space-y-0.5 pl-1 text-[11px] border-t border-border pt-2">
        <li>Each sub-metric is normalized to 0–100 before being multiplied by its weight. Missing sub-metrics simply contribute 0.</li>
        <li>Edit coefficients on the <span className="font-medium text-foreground">Weight Config</span> page — this formula updates live.</li>
        {nicheOn && (
          <li><span className="font-mono text-foreground">Niche</span> = bonus multiplier for low-volume / high-impact specialty journals (Admin Config).</li>
        )}
        {tierDiscountOn ? (
          <li>
            Tier discount applied to weighted return:{' '}
            <span className="font-mono text-foreground">T1=1.0</span> (full data),{' '}
            <span className="font-mono text-foreground">T2={fmtW(proxyDiscount)}</span> (partial),{' '}
            <span className="font-mono text-foreground">T3={fmtW(insufficientDiscount)}</span> (insufficient). Configure on Admin Config.
          </li>
        ) : (
          <li>
            Tier discount is <span className="font-medium text-foreground">disabled</span> — all tiers contribute at 1.0× (toggle on Admin Config).
          </li>
        )}
      </ul>
    </div>
  );
}
export default function ScoringPanel() {
  const { state, dispatch } = useAppStore();
  const [isScoring, setIsScoring] = useState(false);

  const activeWeights = useMemo(
    () => state.weights.find(w => w.isActive) ?? state.weights[0],
    [state.weights],
  );

  const stats = useMemo(() => {
    const total = state.scores.length;
    const scored = state.scores.filter(s => s.status === 'scored').length;
    const insufficient = state.scores.filter(s => s.status === 'insufficient').length;
    const t1 = state.scores.filter(s => s.scoringTier === 1).length;
    const t2 = state.scores.filter(s => s.scoringTier === 2).length;
    const t3 = state.scores.filter(s => s.scoringTier === 3).length;
    return { total, scored, insufficient, t1, t2, t3 };
  }, [state.scores]);

  const canScore = state.requests.length > 0;

  const handleScore = () => {
    setIsScoring(true);
    // Use setTimeout to let UI update
    setTimeout(() => {
      const results = scoreAllRequests({
        requests: state.requests,
        publications: state.publications,
        piCache: state.piCache,
        journalCache: state.journalCache,
        tracHours: state.tracHours,
        weights: activeWeights,
        adminConfig: state.adminConfig,
      });
      dispatch({ type: 'SET_SCORES', payload: results });
      setIsScoring(false);
    }, 100);
  };

  if (state.requests.length === 0) return null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            ROI Scoring Engine
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-3.5 w-3.5 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent className="max-w-sm">
                  <p className="text-xs">
                    Scores combine Publication Impact, Journal Prestige, Funding Activity,
                    and Research Output using the configured weights. Effort-adjusted ROI
                    factors in TRAC hours. T1 = full data, T2 = partial (discounted),
                    T3 = insufficient data.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </CardTitle>
          <Button onClick={handleScore} disabled={!canScore || isScoring} size="sm">
            {isScoring ? (
              <><RefreshCw className="h-4 w-4 mr-1 animate-spin" /> Scoring...</>
            ) : state.scores.length > 0 ? (
              <><RefreshCw className="h-4 w-4 mr-1" /> Re-Score All</>
            ) : (
              <><Calculator className="h-4 w-4 mr-1" /> Score Requests</>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Formula display — dynamic, reflects active Weight Config */}
        <FormulaDisplay weights={activeWeights} adminConfig={state.adminConfig} />

        {stats.total > 0 && (
          <div className="space-y-2">
            <Progress value={(stats.scored / stats.total) * 100} className="h-2" />
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-500" />
                <span>{stats.scored} scored</span>
              </div>
              {stats.insufficient > 0 && (
                <UnprocessedRecordsPopover
                  label="insufficient"
                  recordIds={state.scores.filter(s => s.status === 'insufficient').map(s => s.recordId)}
                  variant="warning"
                  icon={<AlertTriangle className="h-3 w-3" />}
                />
              )}
              <div className="flex items-center gap-2 ml-auto">
                <Badge variant="default" className="text-[10px] px-1.5">T1: {stats.t1}</Badge>
                <Badge variant="secondary" className="text-[10px] px-1.5">T2: {stats.t2}</Badge>
                <Badge variant="destructive" className="text-[10px] px-1.5">T3: {stats.t3}</Badge>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
