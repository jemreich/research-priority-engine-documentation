import React, { useRef, useState } from 'react';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { TrendingUp } from 'lucide-react';
import { getWHOMarketData } from '@/lib/whoMarketData';
import { getMarketData } from '@/lib/specialtyMarketData';

interface SpecialtyBadgeProps {
  specialty: string;
  /** HRCS category — used to look up WHO/HRCS market data */
  hrcsCategory?: string | null;
}

export default function SpecialtyBadge({ specialty, hrcsCategory }: SpecialtyBadgeProps) {
  const who = hrcsCategory ? getWHOMarketData(hrcsCategory) : null;
  const usFallback = getMarketData(specialty);

  // Prefer WHO/HRCS data when present and complete; otherwise fall back to US specialty estimate.
  const useWHO = who?.marketSizeUSD_B != null;
  const marketSizeB = useWHO ? who!.marketSizeUSD_B : (usFallback?.marketCapBillions ?? null);
  const marketCAGR = useWHO ? who!.cagrPercent : (usFallback?.cagrPercent ?? null);
  const globalFundingM = who?.globalFundingUSD_M ?? null;
  const sourceLabel = useWHO ? 'WHO/HRCS Est.' : 'US Specialty Est.';
  const isGlobal = useWHO; // only WHO data is global

  const [open, setOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout>>(null);

  const show = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };

  const hide = () => {
    closeTimer.current = setTimeout(() => setOpen(false), 120);
  };

  return (
    <HoverCard open={open} openDelay={0} closeDelay={0}>
      <HoverCardTrigger asChild>
        <span
          role="button"
          tabIndex={-1}
          className="inline-flex items-center rounded-full border border-input bg-background px-2.5 py-0.5 text-xs font-semibold text-foreground transition-colors hover:bg-accent hover:text-accent-foreground cursor-default gap-1"
          onMouseEnter={show}
          onMouseLeave={hide}
          onClick={e => e.stopPropagation()}
        >
          <TrendingUp className="h-3 w-3 shrink-0" />
          {specialty}
        </span>
      </HoverCardTrigger>
      <HoverCardContent
        className="w-64"
        side="top"
        onMouseEnter={show}
        onMouseLeave={hide}
      >
        <div className="space-y-3">
          <p className="text-sm font-semibold text-foreground">{specialty}</p>
          {hrcsCategory && (
            <p className="text-[10px] text-muted-foreground">
              HRCS: <span className="font-medium text-foreground">{hrcsCategory}</span>
            </p>
          )}
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">Therapeutic Area Market</p>
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2 rounded bg-muted text-center">
              <p className="text-[9px] text-muted-foreground">
                {isGlobal ? 'Global Market Size' : 'US Market Size'}
              </p>
              <p className="text-sm font-bold text-foreground">
                {marketSizeB != null ? `$${marketSizeB}B` : '—'}
              </p>
              <p className="text-[8px] text-muted-foreground">{sourceLabel}</p>
            </div>
            <div className="p-2 rounded bg-muted text-center">
              <p className="text-[9px] text-muted-foreground">Growth (CAGR)</p>
              <p className="text-sm font-bold text-foreground">
                {marketCAGR != null ? `${marketCAGR}%` : '—'}
              </p>
              <p className="text-[8px] text-muted-foreground">{sourceLabel}</p>
            </div>
          </div>
          {globalFundingM != null && (
            <p className="text-[9px] text-muted-foreground text-center">
              Global R&amp;D funding: <span className="font-semibold text-foreground">${globalFundingM.toLocaleString()}M</span>
            </p>
          )}
          {marketSizeB == null && (
            <p className="text-[9px] text-muted-foreground italic text-center">No market data available for this specialty.</p>
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
