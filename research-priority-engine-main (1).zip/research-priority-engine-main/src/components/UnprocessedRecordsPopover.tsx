import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Props {
  label: string;
  recordIds: string[];
  variant?: 'muted' | 'destructive' | 'warning';
  icon?: React.ReactNode;
}

export default function UnprocessedRecordsPopover({ label, recordIds, variant = 'muted', icon }: Props) {
  if (recordIds.length === 0) return null;

  const colorClass =
    variant === 'destructive' ? 'text-destructive' :
    variant === 'warning' ? 'text-yellow-600' :
    'text-muted-foreground';

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className={`flex items-center gap-1 text-xs ${colorClass} hover:underline cursor-pointer`}>
          {icon}
          {recordIds.length} {label}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-3" align="start">
        <p className="text-xs font-semibold text-foreground mb-2">
          {label} — {recordIds.length} record{recordIds.length !== 1 ? 's' : ''}
        </p>
        <ScrollArea className="h-40 overflow-auto">
          <div className="space-y-1">
            {recordIds.map(id => (
              <div key={id} className="text-xs font-mono text-muted-foreground">
                #{id}
              </div>
            ))}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
