const API_KEYS_STORAGE = 'research-prioritization-api-keys';

export interface StoredApiKeys {
  ncbiApiKey?: string;
  clarivateApiKey?: string;
}

export function getApiKeys(): StoredApiKeys {
  try {
    const stored = localStorage.getItem(API_KEYS_STORAGE);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
}

export function saveApiKeys(keys: StoredApiKeys): void {
  localStorage.setItem(API_KEYS_STORAGE, JSON.stringify(keys));
}

export function getNcbiApiKey(): string | undefined {
  return getApiKeys().ncbiApiKey;
}

export function setNcbiApiKey(key: string): void {
  const keys = getApiKeys();
  keys.ncbiApiKey = key;
  saveApiKeys(keys);
}

export function clearNcbiApiKey(): void {
  const keys = getApiKeys();
  delete keys.ncbiApiKey;
  saveApiKeys(keys);
}

export function getClarivateApiKey(): string | undefined {
  return getApiKeys().clarivateApiKey;
}

export function setClarivateApiKey(key: string): void {
  const keys = getApiKeys();
  keys.clarivateApiKey = key;
  saveApiKeys(keys);
}

export function clearClarivateApiKey(): void {
  const keys = getApiKeys();
  delete keys.clarivateApiKey;
  saveApiKeys(keys);
}
