import { getClarivateApiKey } from '@/lib/apiKeys';
import type { JournalEnrichment } from '@/types';

const BASE_URL = 'https://api.clarivate.com/apis/wos-journals/v1';
const RATE_LIMIT_MS = 200; // 5 req/sec

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

interface ClarivateJournalHit {
  id: string;
  name: string;
  metrics?: {
    impactMetrics?: {
      jifQuartile?: string;
    };
    eigenfactorMetrics?: {
      normalizedEigenfactor?: number;
    };
    sourceMetrics?: {
      jci?: number;
    };
  };
}

interface ClarivateSearchResponse {
  hits?: ClarivateJournalHit[];
  metadata?: { total?: number };
}

export interface ClarivateMetrics {
  jifQuartile: string | null;
  normalizedEigenfactor: number | null;
  jci: number | null;
}

async function fetchWithAuth(url: string): Promise<Response> {
  const apiKey = getClarivateApiKey();
  if (!apiKey) throw new Error('Clarivate API key not configured');

  const res = await fetch(url, {
    headers: {
      'X-ApiKey': apiKey,
      'Accept': 'application/json',
    },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Clarivate API ${res.status}: ${text.slice(0, 200)}`);
  }
  return res;
}

/**
 * Search for a journal by name and extract JCR metrics.
 * Falls back to ISSN-based search if name yields no results.
 */
async function lookupJournal(journalName: string, issn?: string): Promise<ClarivateMetrics | null> {
  // Try name search first
  const nameQuery = encodeURIComponent(journalName);
  const url = `${BASE_URL}/journals?q=${nameQuery}&jcrYear=2023`;

  try {
    const res = await fetchWithAuth(url);
    const data: ClarivateSearchResponse = await res.json();

    if (data.hits && data.hits.length > 0) {
      return extractMetrics(data.hits[0]);
    }

    // Fallback: try ISSN if available
    if (issn) {
      const issnUrl = `${BASE_URL}/journals?issn=${encodeURIComponent(issn)}&jcrYear=2023`;
      const issnRes = await fetchWithAuth(issnUrl);
      const issnData: ClarivateSearchResponse = await issnRes.json();
      if (issnData.hits && issnData.hits.length > 0) {
        return extractMetrics(issnData.hits[0]);
      }
    }

    return null;
  } catch (err) {
    console.warn(`Clarivate lookup failed for "${journalName}":`, err);
    return null;
  }
}

function extractMetrics(hit: ClarivateJournalHit): ClarivateMetrics {
  const m = hit.metrics;
  return {
    jifQuartile: m?.impactMetrics?.jifQuartile ?? null,
    normalizedEigenfactor: m?.eigenfactorMetrics?.normalizedEigenfactor ?? null,
    jci: m?.sourceMetrics?.jci ?? null,
  };
}

/**
 * Batch-enrich journals with Clarivate JCR metrics.
 * Rate-limited to 5 requests/sec.
 */
export async function batchEnrichClarivate(
  journals: JournalEnrichment[],
  onProgress?: (done: number, total: number) => void,
): Promise<Map<string, ClarivateMetrics>> {
  const results = new Map<string, ClarivateMetrics>();
  const total = journals.length;

  for (let i = 0; i < total; i++) {
    const j = journals[i];
    const metrics = await lookupJournal(j.journalName);
    if (metrics) {
      results.set(j.journalName, metrics);
    }
    onProgress?.(i + 1, total);

    if (i < total - 1) {
      await delay(RATE_LIMIT_MS);
    }
  }

  return results;
}
