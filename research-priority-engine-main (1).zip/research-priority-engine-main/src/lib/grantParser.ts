/**
 * NIH Grant Number Parser
 *
 * NIH grant format: [AppType] ActivityCode ICCode SerialNumber [-SupportYear] [Suffix]
 * Example: 5 R01 CA 654321-01 A1
 * Core project number = ActivityCode + ICCode + SerialNumber (e.g. R01 CA654321)
 *
 * We match patterns like: R01CA654321, R01 CA 654321, 5R01CA654321-01A1, P30 CA012197, etc.
 */

/** NIH Institute/Center codes → full names */
const IC_CODES: Record<string, string> = {
  TW: "John E. Fogarty International Center",
  TR: "National Center for Advancing Translational Sciences",
  AT: "National Center for Complementary and Integrative Health",
  CA: "National Cancer Institute",
  EY: "National Eye Institute",
  HG: "National Human Genome Research Institute",
  HL: "National Heart, Lung, and Blood Institute",
  AG: "National Institute on Aging",
  AA: "National Institute on Alcohol Abuse and Alcoholism",
  AI: "National Institute of Allergy and Infectious Diseases",
  AR: "National Institute of Arthritis and Musculoskeletal and Skin Diseases",
  EB: "National Institute of Biomedical Imaging and Bioengineering",
  HD: "Eunice Kennedy Shriver National Institute of Child Health and Human Development",
  DA: "National Institute on Drug Abuse",
  DC: "National Institute on Deafness and Other Communication Disorders",
  DE: "National Institute of Dental and Craniofacial Research",
  DK: "National Institute of Diabetes and Digestive and Kidney Diseases",
  ES: "National Institute of Environmental Health Sciences",
  GM: "National Institute of General Medical Sciences",
  MH: "National Institute of Mental Health",
  MD: "National Institute on Minority Health and Health Disparities",
  NS: "National Institute of Neurological Disorders and Stroke",
  NR: "National Institute of Nursing Research",
  LM: "National Library of Medicine",
  OD: "Office of the Director",
  RR: "National Center for Research Resources",
  CL: "National Clinical Center",
};

/**
 * NIH activity codes → category + full name.
 * Sourced from the official NIH Activity Codes list (ActivityCodes.csv).
 */
import ACTIVITY_CODES from './activityCodes';

/**
 * Regex to match NIH grant numbers.
 * Captures: activityCode, icCode, serialNumber
 * Handles optional leading app-type digit, spaces, dashes, and suffixes.
 */
const NIH_GRANT_RE = /\b(\d\s*)?([A-Z][A-Z0-9]{1,3})\s*([A-Z]{2})\s*(\d{5,7})(?:\s*[-/]\s*\d{1,2})?(?:\s*[A-Z]\d*)*\b/g;

export interface ParsedGrant {
  isNIH: boolean;
  raw: string;
  /** Only for NIH grants */
  instituteName?: string;
  activityCodeName?: string;
  activityCodeCategory?: string;
  coreProjectNumber?: string; // e.g. "P30 CA012197"
}

/**
 * Parse a single grant string token.
 */
function tryParseNIH(grantStr: string): ParsedGrant | null {
  // Reset regex
  NIH_GRANT_RE.lastIndex = 0;
  const trimmed = grantStr.trim();

  // Try matching
  const m = NIH_GRANT_RE.exec(trimmed);
  if (!m) return null;

  const activityCode = m[2];
  const icCode = m[3];
  const serial = m[4];

  // Validate: IC code must be known
  if (!IC_CODES[icCode]) return null;

  const activityInfo = ACTIVITY_CODES[activityCode];

  // Format: "Category - Name" when both present; just "Name" when category is empty;
  // fallback to raw activity code if unknown.
  let activityCodeName: string;
  if (activityInfo) {
    activityCodeName = activityInfo.category
      ? `${activityInfo.category} - ${activityInfo.name}`
      : activityInfo.name;
  } else {
    activityCodeName = activityCode;
  }

  return {
    isNIH: true,
    raw: trimmed,
    instituteName: IC_CODES[icCode],
    activityCodeName,
    activityCodeCategory: activityInfo?.category || undefined,
    coreProjectNumber: `${activityCode} ${icCode}${serial}`,
  };
}

/**
 * Parse a grants string (semicolon or comma-separated list of grant IDs from PubMed).
 * Returns array of parsed grants.
 */
export function parseGrants(grantsString: string): ParsedGrant[] {
  if (!grantsString || !grantsString.trim()) return [];

  // PubMed grants separated by semicolons, commas, or line breaks
  const tokens = grantsString
    .split(/[;\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  // Dedupe: PubMed often lists the same award multiple times (one per
  // funding agency/source). For NIH grants, key by the canonical
  // coreProjectNumber (activity + IC + serial — ignores app-type prefix
  // and amendment suffix). For non-NIH, key by lowercased raw string.
  const seen = new Set<string>();
  const out: ParsedGrant[] = [];
  for (const token of tokens) {
    const nih = tryParseNIH(token);
    const parsed: ParsedGrant = nih ?? { isNIH: false, raw: token };
    const key = parsed.isNIH
      ? `nih::${parsed.coreProjectNumber!.toUpperCase().replace(/\s+/g, '')}`
      : `raw::${token.toLowerCase().replace(/\s+/g, ' ')}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(parsed);
  }
  return out;
}

/**
 * Count distinct grants from a grants string.
 */
export function countGrants(grantsString: string): number {
  return parseGrants(grantsString).length;
}
