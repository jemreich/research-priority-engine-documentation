import crosswalk from "@/lib/hrcs-crosswalk.json";

export const FALLBACK_HRCS_CATEGORY = "Generic health relevance";
export const UNCATEGORIZED_HRCS_CATEGORY = "Disputed aetiology and other";

export function normalizeHRCSLabel(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

const crosswalkEntries = Object.entries(crosswalk as Record<string, string>);

const canonicalHRCSCategoryMap = new Map<string, string>([
  ...Array.from(new Set(crosswalkEntries.map(([, category]) => category))).map((category) => [normalizeHRCSLabel(category), category] as const),
  [normalizeHRCSLabel(FALLBACK_HRCS_CATEGORY), FALLBACK_HRCS_CATEGORY],
  [normalizeHRCSLabel(UNCATEGORIZED_HRCS_CATEGORY), UNCATEGORIZED_HRCS_CATEGORY],
]);

const normalizedCrosswalk = new Map<string, string>(
  crosswalkEntries.map(([heading, category]) => [normalizeHRCSLabel(heading), category]),
);

const specialtyToHRCSCategory = new Map<string, string>([
  ["oncology cancer", "Cancer and neoplasms"],
  ["cardiology", "Cardiovascular"],
  ["neurology", "Neurological"],
  ["neurological surgery", "Neurological"],
  ["infectious disease", "Infection"],
  ["endocrinology", "Metabolic and endocrine"],
  ["pulmonology", "Respiratory"],
  ["gastroenterology", "Oral and gastrointestinal"],
  ["rheumatology", "Inflammatory and immune system"],
  ["allergy and immunology", "Inflammatory and immune system"],
  ["hematology", "Blood"],
  ["nephrology", "Renal and urogenital"],
  ["urology", "Renal and urogenital"],
  ["dermatology", "Skin"],
  ["vision", "Eye"],
  ["otolaryngology", "Ear"],
  ["orthopaedic surgery", "Musculoskeletal"],
  ["obstetrics and gynecology", "Reproductive health and childbirth"],
  ["psychiatry", "Mental health"],
  ["psychology behavioral", "Mental health"],
  ["internal medicine", FALLBACK_HRCS_CATEGORY],
  ["preventive medicine", FALLBACK_HRCS_CATEGORY],
  ["radiology", FALLBACK_HRCS_CATEGORY],
  ["medical education", FALLBACK_HRCS_CATEGORY],
  ["research methods", FALLBACK_HRCS_CATEGORY],
  ["health policy quality", FALLBACK_HRCS_CATEGORY],
  ["health technology", FALLBACK_HRCS_CATEGORY],
  ["nursing", FALLBACK_HRCS_CATEGORY],
]);

export function inferHRCSCategoryFromBroadHeadings(headings: string[] | null | undefined): string | null {
  if (!headings?.length) return null;

  for (const heading of headings) {
    const match = normalizedCrosswalk.get(normalizeHRCSLabel(heading));
    if (match) return match;
  }

  return null;
}

export function inferHRCSCategoryFromSpecialty(specialty?: string | null): string | null {
  if (!specialty) return null;
  return specialtyToHRCSCategory.get(normalizeHRCSLabel(specialty)) ?? null;
}

export function resolveHRCSCategory(hrcsCategory?: string | null, specialty?: string | null): string | null {
  const normalizedExisting = hrcsCategory ? normalizeHRCSLabel(hrcsCategory) : null;
  const canonicalExisting = normalizedExisting ? canonicalHRCSCategoryMap.get(normalizedExisting) ?? hrcsCategory ?? null : null;

  if (
    canonicalExisting &&
    canonicalExisting !== FALLBACK_HRCS_CATEGORY &&
    canonicalExisting !== UNCATEGORIZED_HRCS_CATEGORY
  ) {
    return canonicalExisting;
  }

  return inferHRCSCategoryFromSpecialty(specialty) ?? canonicalExisting;
}