import { getNcbiApiKey } from "@/lib/apiKeys";
import {
  FALLBACK_HRCS_CATEGORY,
  UNCATEGORIZED_HRCS_CATEGORY,
  inferHRCSCategoryFromBroadHeadings,
} from "@/lib/hrcsCategory";

async function fetchWithRetry(url: string, retries = 2): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url);
      if (res.status === 429) {
        // rate-limited — back off and retry
        await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
        continue;
      }
      return res;
    } catch (err) {
      lastErr = err;
      // network / fetch failure — back off and retry
      await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
    }
  }
  throw lastErr ?? new Error("fetch failed");
}

export async function getHRCSCategory(journalName: string): Promise<string> {
  const apiKey = getNcbiApiKey();

  try {
    const params = new URLSearchParams({
      db: "nlmcatalog",
      term: `${journalName}[journal]`,
      retmode: "json",
      retmax: "1",
      ...(apiKey && { api_key: apiKey }),
    });

    const res = await fetchWithRetry(
      `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?${params}`,
    );
    const data = await res.json();
    const uid = data.esearchresult?.idlist?.[0];

      if (!uid) return FALLBACK_HRCS_CATEGORY;

    const summaryRes = await fetchWithRetry(
      `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=nlmcatalog&id=${uid}&retmode=json${apiKey ? `&api_key=${apiKey}` : ""}`,
    );
      const summary = await summaryRes.json();
      const broadHeadings: string[] = summary.result?.[uid]?.broadheading ?? [];
      const meshHeadings: string[] = summary.result?.[uid]?.meshheadinglist ?? [];
      const matchedCategory = inferHRCSCategoryFromBroadHeadings([...broadHeadings, ...meshHeadings]);

      if (matchedCategory) return matchedCategory;

      return broadHeadings.length > 0 || meshHeadings.length > 0
        ? UNCATEGORIZED_HRCS_CATEGORY
        : FALLBACK_HRCS_CATEGORY;
  } catch (err) {
    console.warn(`HRCS lookup failed for "${journalName}":`, err);
      return FALLBACK_HRCS_CATEGORY;
  }
}
