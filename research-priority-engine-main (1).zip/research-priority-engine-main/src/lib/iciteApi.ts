/**
 * iCite API client – fetches citation metrics (RCR, APT, citation count, etc.)
 * from the NIH Office of Portfolio Analysis.
 * Endpoint: https://icite.od.nih.gov/api/pubs?pmids=...
 * Free, no API key required. Max 1000 PMIDs per request.
 */

const ICITE_BASE = 'https://icite.od.nih.gov/api/pubs';
const BATCH_SIZE = 1000; // API max per request
const MAX_RETRIES = 3;
const RETRY_DELAYS = [1000, 2000, 4000];

export interface ICiteRecord {
  pmid: number;
  year: number | null;
  title: string | null;
  relative_citation_ratio: number | null;
  nih_percentile: number | null;
  citation_count: number | null;
  citations_per_year: number | null;
  expected_citations_per_year: number | null;
  field_citation_rate: number | null;
  apt: number | null;
  is_clinical: string | null; // "Yes" | "No"
  provisional: string | null;
  doi: string | null;
  journal: string | null;
}

export interface ICiteMetrics {
  pmid: string;
  relativeCitationRatio: number | null;
  nihPercentile: number | null;
  citationCount: number | null;
  citationsPerYear: number | null;
  expectedCitationsPerYear: number | null;
  fieldCitationRate: number | null;
  apt: number | null;
  isClinical: boolean | null;
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchWithRetry(url: string, retries = MAX_RETRIES): Promise<Response> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const response = await fetch(url);
    if (response.ok) return response;

    if ([429, 500, 503].includes(response.status) && attempt < retries) {
      await delay(RETRY_DELAYS[attempt] || 4000);
      continue;
    }
    throw new Error(`iCite HTTP ${response.status}: ${response.statusText}`);
  }
  throw new Error('iCite max retries exceeded');
}

/**
 * Map raw iCite API record to our clean metrics shape
 */
export function mapICiteRecord(record: ICiteRecord): ICiteMetrics {
  return {
    pmid: String(record.pmid),
    relativeCitationRatio: record.relative_citation_ratio ?? null,
    nihPercentile: record.nih_percentile ?? null,
    citationCount: record.citation_count ?? null,
    citationsPerYear: record.citations_per_year ?? null,
    expectedCitationsPerYear: record.expected_citations_per_year ?? null,
    fieldCitationRate: record.field_citation_rate ?? null,
    apt: record.apt ?? null,
    isClinical: record.is_clinical === 'Yes' ? true : record.is_clinical === 'No' ? false : null,
  };
}

/**
 * Fetch iCite metrics for a batch of PMIDs (up to 1000)
 */
async function fetchICiteBatch(pmids: string[]): Promise<ICiteMetrics[]> {
  if (pmids.length === 0) return [];

  const url = `${ICITE_BASE}?pmids=${pmids.join(',')}&format=json`;
  const response = await fetchWithRetry(url);
  const data = await response.json();

  // API returns { data: [...] } for multiple PMIDs
  const records: ICiteRecord[] = Array.isArray(data) ? data : (data?.data ?? []);

  return records
    .filter((r: ICiteRecord) => r && r.pmid != null)
    .map(mapICiteRecord);
}

/**
 * Fetch iCite metrics for any number of PMIDs, automatically batching
 * into groups of 1000.
 */
export async function fetchICiteMetrics(
  pmids: string[],
  onProgress?: (completed: number, total: number) => void,
): Promise<Map<string, ICiteMetrics>> {
  const unique = [...new Set(pmids)];
  const result = new Map<string, ICiteMetrics>();
  const totalBatches = Math.ceil(unique.length / BATCH_SIZE);

  for (let i = 0; i < totalBatches; i++) {
    const batch = unique.slice(i * BATCH_SIZE, (i + 1) * BATCH_SIZE);
    const metrics = await fetchICiteBatch(batch);

    for (const m of metrics) {
      result.set(m.pmid, m);
    }

    onProgress?.(Math.min((i + 1) * BATCH_SIZE, unique.length), unique.length);

    // Small delay between batches to be polite
    if (i < totalBatches - 1) {
      await delay(200);
    }
  }

  return result;
}
