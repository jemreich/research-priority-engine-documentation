/**
 * Journal name normalization helpers.
 *
 * Used to build forgiving lookup keys when matching journal names across
 * disparate sources (PubMed ISO abbreviations, CrossRef titles, OpenAlex,
 * SCImago, Google Scholar). Lowercases, strips diacritics, drops punctuation,
 * and collapses whitespace. Also normalizes ISSNs to a consistent
 * `XXXX-XXXX` form (uppercase, no extra characters).
 */

/** Normalize a journal display name into a stable lookup key. */
export function normalizeJournalKey(name: string | null | undefined): string {
  if (!name) return '';
  return name
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '') // strip diacritics
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ') // drop punctuation
    .trim()
    .replace(/\s+/g, ' ');
}

/** Normalize an ISSN to `XXXX-XXXX` form (uppercase, hyphenated). */
export function normalizeIssn(issn: string | null | undefined): string {
  if (!issn) return '';
  const cleaned = issn.replace(/[^0-9xX]/g, '').toUpperCase();
  if (cleaned.length !== 8) return '';
  return `${cleaned.slice(0, 4)}-${cleaned.slice(4)}`;
}

/**
 * Build a normalized index from a record keyed by raw journal names.
 * Returns a Map keyed by normalized keys to the original record values.
 * Later collisions overwrite earlier ones — last write wins.
 */
export function buildNormalizedIndex<T>(record: Record<string, T>): Map<string, T> {
  const index = new Map<string, T>();
  for (const [name, value] of Object.entries(record)) {
    const key = normalizeJournalKey(name);
    if (key) index.set(key, value);
  }
  return index;
}
