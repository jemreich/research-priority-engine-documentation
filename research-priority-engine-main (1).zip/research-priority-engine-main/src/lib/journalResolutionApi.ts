/**
 * Journal Name Resolution Pipeline
 *
 * Expand PubMed ISO abbreviations (e.g. "Nat Commun") into full titles
 * ("Nature Communications") plus ISSN(s), so downstream enrichment (OpenAlex,
 * SCImago, Google Scholar h5) can match on canonical names instead of
 * abbreviations.
 *
 * Cascade:
 *   1. CrossRef DOI lookup           (highest confidence)
 *   2. NLM Catalog ISO Abbreviation  (NCBI E-utilities)
 *   3. OpenAlex /sources/issn/{issn} (fast canonical when ISSN known)
 *   4. OpenAlex text search          (fuzzy fallback)
 *   else → UNRESOLVED
 *
 * Each unique abbreviation is resolved at most once per session via an
 * in-memory cache.
 */

import { getNcbiApiKey } from './apiKeys';
import { normalizeIssn } from './journalNormalize';

export type ResolutionTier =
  | 'CROSSREF_DOI'
  | 'NLM_CATALOG'
  | 'OPENALEX_ISSN'
  | 'OPENALEX_TEXT'
  | 'UNRESOLVED';

export interface ResolvedJournal {
  fullTitle: string;
  issns: string[];
  tier: ResolutionTier;
  originalAbbreviation: string;
}

export interface ResolveJournalInput {
  isoAbbreviation: string;
  /** A representative DOI from a publication in this journal (optional). */
  doi?: string | null;
}

const MAILTO = 'research-prioritizer@example.com';
const CROSSREF_BASE = 'https://api.crossref.org/works';
const NLM_ESEARCH = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi';
const NLM_EFETCH = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi';
const OPENALEX_BASE = 'https://api.openalex.org';

const sessionCache = new Map<string, ResolvedJournal>();

/** Clear the in-session resolution cache (useful for tests). */
export function clearResolutionCache(): void {
  sessionCache.clear();
}

async function fetchWithRetry(url: string, retries = 2): Promise<Response> {
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url);
      if (res.status === 429 || res.status === 503) {
        await new Promise((r) => setTimeout(r, 800 * (i + 1)));
        continue;
      }
      return res;
    } catch (err) {
      if (i === retries) throw err;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw new Error('Max retries exceeded');
}

/* ------------------------------------------------------------------ */
/* Tier 1 — CrossRef DOI                                              */
/* ------------------------------------------------------------------ */

interface CrossRefHit {
  fullTitle: string;
  issns: string[];
}

async function tryCrossRef(doi: string): Promise<CrossRefHit | null> {
  const cleanDoi = doi.replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
  if (!cleanDoi) return null;
  try {
    const url = `${CROSSREF_BASE}/${encodeURIComponent(cleanDoi)}?mailto=${MAILTO}`;
    const res = await fetchWithRetry(url);
    if (!res.ok) return null;
    const data = await res.json();
    const msg = data?.message;
    const containerTitles: string[] = msg?.['container-title'] ?? [];
    const fullTitle = containerTitles[0]?.trim();
    if (!fullTitle) return null;
    const rawIssns: string[] = msg?.ISSN ?? [];
    const issns = rawIssns.map(normalizeIssn).filter(Boolean);
    return { fullTitle, issns };
  } catch (err) {
    console.warn('CrossRef lookup failed for DOI', doi, err);
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Tier 2 — NLM Catalog                                               */
/* ------------------------------------------------------------------ */

async function tryNLMCatalog(isoAbbreviation: string): Promise<CrossRefHit | null> {
  const apiKey = getNcbiApiKey();
  const term = `${isoAbbreviation}[ISO Abbreviation]`;
  const esearchParams = new URLSearchParams({
    db: 'nlmcatalog',
    term,
    retmax: '1',
    retmode: 'json',
    ...(apiKey ? { api_key: apiKey } : {}),
  });

  try {
    const esearchRes = await fetchWithRetry(`${NLM_ESEARCH}?${esearchParams}`);
    if (!esearchRes.ok) return null;
    const esearchData = await esearchRes.json();
    const ids: string[] = esearchData?.esearchresult?.idlist ?? [];
    if (ids.length === 0) return null;

    const efetchParams = new URLSearchParams({
      db: 'nlmcatalog',
      id: ids[0],
      retmode: 'xml',
      ...(apiKey ? { api_key: apiKey } : {}),
    });
    const efetchRes = await fetchWithRetry(`${NLM_EFETCH}?${efetchParams}`);
    if (!efetchRes.ok) return null;
    const xml = await efetchRes.text();
    return parseNLMCatalogXml(xml);
  } catch (err) {
    console.warn('NLM Catalog lookup failed for', isoAbbreviation, err);
    return null;
  }
}

/** Exposed for testing. */
export function parseNLMCatalogXml(xml: string): CrossRefHit | null {
  const titleMatch = xml.match(/<TitleMain>[\s\S]*?<Title>([^<]+)<\/Title>[\s\S]*?<\/TitleMain>/);
  const fullTitle = titleMatch?.[1]?.trim().replace(/\.$/, '');
  if (!fullTitle) return null;
  const issnMatches = [...xml.matchAll(/<ISSN[^>]*>([^<]+)<\/ISSN>/g)];
  const issns = issnMatches.map((m) => normalizeIssn(m[1])).filter(Boolean);
  return { fullTitle, issns: Array.from(new Set(issns)) };
}

/* ------------------------------------------------------------------ */
/* Tier 3/4 — OpenAlex                                                */
/* ------------------------------------------------------------------ */

interface OpenAlexSourceLite {
  display_name: string;
  issn_l: string | null;
  issn: string[] | null;
}

async function tryOpenAlexByISSN(issn: string): Promise<CrossRefHit | null> {
  try {
    const url = `${OPENALEX_BASE}/sources/issn:${encodeURIComponent(issn)}?mailto=${MAILTO}`;
    const res = await fetchWithRetry(url);
    if (!res.ok) return null;
    const data: OpenAlexSourceLite = await res.json();
    if (!data?.display_name) return null;
    const issns = [data.issn_l, ...(data.issn ?? [])].map(normalizeIssn).filter(Boolean);
    return { fullTitle: data.display_name, issns: Array.from(new Set(issns)) };
  } catch (err) {
    console.warn('OpenAlex ISSN lookup failed for', issn, err);
    return null;
  }
}

async function tryOpenAlexText(name: string): Promise<CrossRefHit | null> {
  const cleaned = name.replace(/[^\w\s]/g, ' ').trim();
  if (!cleaned) return null;
  try {
    const url = `${OPENALEX_BASE}/sources?search=${encodeURIComponent(cleaned)}&per_page=1&mailto=${MAILTO}`;
    const res = await fetchWithRetry(url);
    if (!res.ok) return null;
    const data = await res.json();
    const hit: OpenAlexSourceLite | undefined = data?.results?.[0];
    if (!hit?.display_name) return null;
    const issns = [hit.issn_l, ...(hit.issn ?? [])].map(normalizeIssn).filter(Boolean);
    return { fullTitle: hit.display_name, issns: Array.from(new Set(issns)) };
  } catch (err) {
    console.warn('OpenAlex text search failed for', name, err);
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Public API                                                         */
/* ------------------------------------------------------------------ */

/**
 * Resolve an ISO abbreviation to a full journal title + ISSNs via the
 * 4-tier cascade. Cached per-session by `isoAbbreviation`.
 */
export async function resolveJournal(input: ResolveJournalInput): Promise<ResolvedJournal> {
  const key = input.isoAbbreviation.trim();
  if (!key) {
    return { fullTitle: '', issns: [], tier: 'UNRESOLVED', originalAbbreviation: '' };
  }
  const cached = sessionCache.get(key);
  if (cached) return cached;

  // Tier 1: CrossRef via DOI
  if (input.doi) {
    const hit = await tryCrossRef(input.doi);
    if (hit) {
      const result: ResolvedJournal = {
        fullTitle: hit.fullTitle,
        issns: hit.issns,
        tier: 'CROSSREF_DOI',
        originalAbbreviation: key,
      };
      sessionCache.set(key, result);
      return result;
    }
  }

  // Tier 2: NLM Catalog
  const nlm = await tryNLMCatalog(key);
  if (nlm) {
    const result: ResolvedJournal = {
      fullTitle: nlm.fullTitle,
      issns: nlm.issns,
      tier: 'NLM_CATALOG',
      originalAbbreviation: key,
    };
    sessionCache.set(key, result);
    return result;
  }

  // Tier 3: OpenAlex by ISSN (we only get here if NLM failed; nothing to try)
  // Tier 4: OpenAlex text search
  const text = await tryOpenAlexText(key);
  if (text) {
    const result: ResolvedJournal = {
      fullTitle: text.fullTitle,
      issns: text.issns,
      tier: text.issns.length > 0 ? 'OPENALEX_TEXT' : 'OPENALEX_TEXT',
      originalAbbreviation: key,
    };
    sessionCache.set(key, result);
    return result;
  }

  const unresolved: ResolvedJournal = {
    fullTitle: key,
    issns: [],
    tier: 'UNRESOLVED',
    originalAbbreviation: key,
  };
  sessionCache.set(key, unresolved);
  return unresolved;
}

/** Look up an OpenAlex source directly by an ISSN (Tier 3). Public for enrichment use. */
export async function lookupOpenAlexByISSN(issn: string): Promise<CrossRefHit | null> {
  const norm = normalizeIssn(issn);
  if (!norm) return null;
  return tryOpenAlexByISSN(norm);
}
