import type { PIEnrichmentCache } from '@/types';

const REPORTER_BASE_URL = '/api/nih-reporter';

const MAX_RETRIES = 3;
const RETRY_DELAYS = [1000, 2000, 4000];

interface ReporterProject {
  project_num: string;
  fiscal_year: number;
  award_amount: number | null;
  project_start_date: string | null;
  project_end_date: string | null;
  activity_code: string | null;
  full_study_section: { srg_code: string } | null;
  organization: { org_name: string } | null;
  agency_ic_fundings: { abbreviation: string; total_cost: number }[] | null;
  is_active: boolean;
  project_title: string;
}

interface ReporterResponse {
  meta: { total: number; offset: number; limit: number };
  results: ReporterProject[] | null;
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * POST to NIH RePORTER via Vite dev proxy with retries.
 */
async function fetchReporter(body: object): Promise<Response> {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(REPORTER_BASE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (response.ok) return response;
      if ([429, 500, 503].includes(response.status) && attempt < MAX_RETRIES) {
        await delay(RETRY_DELAYS[attempt] || 4000);
        continue;
      }
      throw new Error(`HTTP ${response.status}`);
    } catch (e) {
      if (attempt < MAX_RETRIES) {
        await delay(RETRY_DELAYS[attempt] || 4000);
        continue;
      }
      throw e;
    }
  }
  throw new Error('NIH RePORTER API unreachable. Try again later.');
}

/**
 * Extract PI last name from "Last, First" format
 */
function extractPINames(piName: string): { lastName: string; firstName: string } {
  const parts = piName.split(',').map(s => s.trim());
  return {
    lastName: parts[0] || piName,
    firstName: parts[1] || '',
  };
}

/**
 * Search NIH RePORTER for a PI's grants.
 * Uses PI name search, limited to recent fiscal years.
 */
export async function searchReporterForPI(piName: string): Promise<{
  projects: ReporterProject[];
  totalCount: number;
}> {
  const { firstName, lastName } = extractPINames(piName);

  const piSearch: Record<string, string> = { any_name: lastName };
  if (firstName) {
    piSearch.first_name = firstName;
    piSearch.last_name = lastName;
    delete piSearch.any_name;
  }

  const currentYear = new Date().getFullYear();
  const fiscalYears = Array.from({ length: 10 }, (_, i) => currentYear - i);

  const body = {
    criteria: {
      pi_names: [piSearch],
      fiscal_years: fiscalYears,
    },
    offset: 0,
    limit: 100,
    sort_field: 'fiscal_year',
    sort_order: 'desc',
  };

  const response = await fetchReporter(body);
  const data: ReporterResponse = await response.json();

  return {
    projects: data.results || [],
    totalCount: data.meta?.total || 0,
  };
}

/**
 * Aggregate grant data into PIEnrichmentCache fields
 */
export function aggregateGrantData(
  piName: string,
  projects: ReporterProject[]
): PIEnrichmentCache {
  if (projects.length === 0) {
    return {
      piName,
      hIndex: null,
      totalCitations: null,
      totalPublications: null,
      grantCount: 0,
      totalGrantFunding: 0,
      activeGrants: 0,
      nihReporterData: null,
      enrichedAt: new Date().toISOString(),
      status: 'enriched',
    };
  }

  // Deduplicate by canonical core project number.
  // NIH project_num format: "<appType><activity><IC><serial>-<suffix>".
  // The leading app-type digit (1,2,3,5,7,9) and "-NNAN" suffix change
  // each fiscal year but identify the same award, so we strip both.
  const canonicalCore = (projectNum: string): string => {
    if (!projectNum) return '';
    const stripped = projectNum.split('-')[0];
    return stripped.replace(/^\d+/, '').toUpperCase().replace(/\s+/g, '');
  };
  const uniqueProjects = new Map<string, ReporterProject>();
  for (const p of projects) {
    const core = canonicalCore(p.project_num);
    if (!core) continue;
    if (!uniqueProjects.has(core) || (p.fiscal_year > (uniqueProjects.get(core)!.fiscal_year || 0))) {
      uniqueProjects.set(core, p);
    }
  }

  const dedupedList = Array.from(uniqueProjects.values());
  const activeGrants = dedupedList.filter(p => p.is_active).length;
  const totalFunding = projects.reduce((sum, p) => sum + (p.award_amount || 0), 0);

  return {
    piName,
    hIndex: null, // populated separately via publication data
    totalCitations: null,
    totalPublications: null,
    grantCount: dedupedList.length,
    totalGrantFunding: totalFunding,
    activeGrants,
    nihReporterData: {
      totalProjectsFound: projects.length,
      uniqueGrants: dedupedList.length,
      projects: dedupedList.map(p => ({
        projectNum: p.project_num,
        title: p.project_title,
        fiscalYear: p.fiscal_year,
        amount: p.award_amount,
        isActive: p.is_active,
        activityCode: p.activity_code,
        startDate: p.project_start_date,
        endDate: p.project_end_date,
      })),
    },
    enrichedAt: new Date().toISOString(),
    status: 'enriched',
  };
}

/**
 * Enrich a single PI — search + aggregate
 */
export async function enrichPI(piName: string): Promise<PIEnrichmentCache> {
  try {
    const { projects } = await searchReporterForPI(piName);
    return aggregateGrantData(piName, projects);
  } catch (error) {
    return {
      piName,
      hIndex: null,
      totalCitations: null,
      totalPublications: null,
      grantCount: null,
      totalGrantFunding: null,
      activeGrants: null,
      nihReporterData: null,
      enrichedAt: new Date().toISOString(),
      status: 'error',
    };
  }
}

/**
 * Batch enrich multiple PIs with rate limiting
 */
export async function batchEnrichPIs(
  piNames: string[],
  onProgress?: (completed: number, total: number) => void
): Promise<PIEnrichmentCache[]> {
  const unique = [...new Set(piNames)];
  const results: PIEnrichmentCache[] = [];

  for (let i = 0; i < unique.length; i++) {
    const result = await enrichPI(unique[i]);
    results.push(result);
    onProgress?.(i + 1, unique.length);

    if (i < unique.length - 1) {
      await delay(200); // respect rate limits
    }
  }

  return results;
}
