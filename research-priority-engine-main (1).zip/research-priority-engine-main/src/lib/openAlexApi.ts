/**
 * OpenAlex API client for journal-level metrics.
 *
 * Uses the resolved full title + ISSNs from the journal resolution pipeline
 * to look up SCImago and h5 metrics with much higher hit rates than the
 * previous abbreviation-based lookup.
 */

import type { JournalEnrichment, JournalResolutionTier } from '@/types';
import { mapJournalToSpecialty, getMarketData } from '@/lib/specialtyMarketData';
import { lookupOpenAlexByISSN } from '@/lib/journalResolutionApi';
import { normalizeJournalKey, normalizeIssn, buildNormalizedIndex } from '@/lib/journalNormalize';
import h5MetricsData from '@/lib/h5MetricsData.json';
import scimagoData from '@/lib/scimagoData.json';

type ScimagoEntry = {
  sjr: number | null;
  sjrQuartile: string | null;
  hIndex: number | null;
  totalDocs3yr: number | null;
  citPerDoc2yr: number | null;
};
type H5Entry = { h5Index: number; h5Median: number };

const h5Lookup = h5MetricsData as Record<string, H5Entry>;
const scimagoLookup = scimagoData as Record<string, ScimagoEntry>;

// Pre-built normalized indexes (one-time module load cost).
const h5NormalizedIndex = buildNormalizedIndex<H5Entry>(h5Lookup);
const scimagoNormalizedIndex = buildNormalizedIndex<ScimagoEntry>(scimagoLookup);

const OPENALEX_BASE = 'https://api.openalex.org';
const MAILTO = 'mailto=research-prioritizer@example.com';

interface OpenAlexSource {
  id: string;
  display_name: string;
  issn_l: string | null;
  issn: string[] | null;
  host_organization_name: string | null;
  type: string;
  summary_stats: {
    '2yr_mean_citedness': number;
    h_index: number;
    i10_index: number;
  };
  cited_by_count: number;
  works_count: number;
  x_concepts: Array<{
    id: string;
    display_name: string;
    level: number;
    score: number;
  }>;
}

async function fetchWithRetry(url: string, retries = 2): Promise<Response> {
  for (let i = 0; i <= retries; i++) {
    const res = await fetch(url);
    if (res.status === 429) {
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
      continue;
    }
    return res;
  }
  throw new Error('OpenAlex rate limit exceeded');
}

async function searchSource(journalName: string): Promise<OpenAlexSource | null> {
  const cleaned = journalName.replace(/[^\w\s]/g, ' ').trim();
  if (!cleaned) return null;

  const url = `${OPENALEX_BASE}/sources?search=${encodeURIComponent(cleaned)}&per_page=1&${MAILTO}`;
  const res = await fetchWithRetry(url);
  if (!res.ok) return null;

  const data = await res.json();
  if (!data.results || data.results.length === 0) return null;
  return data.results[0] as OpenAlexSource;
}

async function fetchSourceByISSN(issn: string): Promise<OpenAlexSource | null> {
  try {
    const url = `${OPENALEX_BASE}/sources/issn:${encodeURIComponent(issn)}?${MAILTO}`;
    const res = await fetchWithRetry(url);
    if (!res.ok) return null;
    return (await res.json()) as OpenAlexSource;
  } catch {
    return null;
  }
}

/** Try multiple candidate names + ISSNs against the SCImago lookup. */
function lookupScimago(candidates: string[], issns: string[]): ScimagoEntry | null {
  for (const c of candidates) {
    if (!c) continue;
    if (scimagoLookup[c]) return scimagoLookup[c];
    const k = normalizeJournalKey(c);
    const hit = scimagoNormalizedIndex.get(k);
    if (hit) return hit;
  }
  // ISSNs aren't keys in our static SCImago JSON yet, but we expose the API
  // for future indexes that might include them. Loop is cheap for empty data.
  for (const issn of issns) {
    if (scimagoLookup[issn]) return scimagoLookup[issn];
  }
  return null;
}

/** Try multiple candidate names against the Google Scholar h5 lookup. */
function lookupH5(candidates: string[]): H5Entry | null {
  for (const c of candidates) {
    if (!c) continue;
    if (h5Lookup[c]) return h5Lookup[c];
    const k = normalizeJournalKey(c);
    const hit = h5NormalizedIndex.get(k);
    if (hit) return hit;
  }
  return null;
}

export interface EnrichJournalOptions {
  /** Full title resolved by `journalResolutionApi.resolveJournal`. */
  resolvedFullTitle?: string;
  /** ISSNs known from the resolution pipeline. */
  issns?: string[];
  /** Tier label to record in `JournalEnrichment.resolutionTier`. */
  resolutionTier?: JournalResolutionTier;
}

/**
 * Enrich a journal with OpenAlex + SCImago + h5 metrics.
 * When called from the resolution pipeline, `opts.resolvedFullTitle` and
 * `opts.issns` are passed in to drive ISSN-first OpenAlex lookups and
 * full-title-based metric matching.
 */
export async function enrichJournal(
  originalJournalName: string,
  opts: EnrichJournalOptions = {},
): Promise<JournalEnrichment | null> {
  try {
    const issns = (opts.issns ?? []).map(normalizeIssn).filter(Boolean);
    let source: OpenAlexSource | null = null;

    // Tier 3: ISSN-first OpenAlex lookup (much more precise than text search).
    for (const issn of issns) {
      source = await fetchSourceByISSN(issn);
      if (source) break;
    }
    // Tier 4 fallback: text search using resolved title (or original abbreviation).
    if (!source) {
      const searchName = opts.resolvedFullTitle || originalJournalName;
      source = await searchSource(searchName);
    }

    // Concepts (for downstream specialty classification fallback).
    const concepts = (source?.x_concepts || [])
      .filter(c => c.level <= 1 && c.score > 0.3)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(c => c.display_name);

    // Candidate names for static metric lookups, in priority order.
    const candidateNames = [
      opts.resolvedFullTitle,
      source?.display_name,
      originalJournalName,
    ].filter((n): n is string => !!n);

    // Map to specialty using all candidate names + concepts.
    let specialty: string | null = null;
    for (const c of candidateNames) {
      specialty = mapJournalToSpecialty(c, concepts);
      if (specialty) break;
    }

    const marketData = specialty ? getMarketData(specialty) : null;

    const resolvedName = opts.resolvedFullTitle || source?.display_name || originalJournalName;
    const h5 = lookupH5(candidateNames);
    const scimago = lookupScimago(candidateNames, issns);

    // Merge ISSNs from OpenAlex into the known list.
    const sourceIssns = source
      ? [source.issn_l, ...(source.issn ?? [])].map(normalizeIssn).filter(Boolean)
      : [];
    const mergedIssns = Array.from(new Set([...issns, ...sourceIssns]));

    return {
      journalName: resolvedName,
      originalName: originalJournalName,
      openAlexId: source?.id ?? '',
      concepts,
      specialty: specialty ?? null,
      hrcsCategory: null,
      hrcsCategoryResolvedAt: null,
      marketCapBillions: marketData?.marketCapBillions ?? null,
      marketCAGR: marketData?.cagrPercent ?? null,
      h5Index: h5?.h5Index ?? null,
      h5Median: h5?.h5Median ?? null,
      sjr: scimago?.sjr ?? null,
      sjrQuartile: scimago?.sjrQuartile ?? null,
      sjrHIndex: scimago?.hIndex ?? null,
      totalDocs3yr: scimago?.totalDocs3yr ?? null,
      citPerDoc2yr: scimago?.citPerDoc2yr ?? null,
      issns: mergedIssns,
      resolutionTier: opts.resolutionTier,
      enrichedAt: new Date().toISOString(),
    };
  } catch (err) {
    console.error(`OpenAlex enrichment failed for "${originalJournalName}":`, err);
    return null;
  }
}

/** Direct ISSN→OpenAlex lookup re-export for convenience. */
export { lookupOpenAlexByISSN };

export interface BatchEnrichInput {
  abbreviation: string;
  resolvedFullTitle?: string;
  issns?: string[];
  resolutionTier?: JournalResolutionTier;
}

/**
 * Batch-enrich multiple journals with rate limiting.
 * Accepts either plain abbreviation strings (legacy) or BatchEnrichInput
 * objects carrying resolution metadata.
 */
export async function batchEnrichJournals(
  inputs: Array<string | BatchEnrichInput>,
  onProgress?: (done: number, total: number) => void,
): Promise<Map<string, JournalEnrichment>> {
  const normalized: BatchEnrichInput[] = inputs
    .map((i) => (typeof i === 'string' ? { abbreviation: i } : i))
    .filter((i) => !!i.abbreviation);
  // De-duplicate by abbreviation, keeping the entry with the most info.
  const byAbbr = new Map<string, BatchEnrichInput>();
  for (const i of normalized) {
    const existing = byAbbr.get(i.abbreviation);
    if (!existing || (i.resolvedFullTitle && !existing.resolvedFullTitle)) {
      byAbbr.set(i.abbreviation, i);
    }
  }
  const unique = [...byAbbr.values()];
  const results = new Map<string, JournalEnrichment>();

  for (let i = 0; i < unique.length; i++) {
    const inp = unique[i];
    const enrichment = await enrichJournal(inp.abbreviation, {
      resolvedFullTitle: inp.resolvedFullTitle,
      issns: inp.issns,
      resolutionTier: inp.resolutionTier,
    });
    if (enrichment) {
      results.set(inp.abbreviation, enrichment);
    }
    onProgress?.(i + 1, unique.length);

    // Respect OpenAlex rate limit: ~10 req/sec for polite pool
    if (i < unique.length - 1) {
      await new Promise(r => setTimeout(r, 120));
    }
  }

  return results;
}
