import * as XLSX from 'xlsx';
import type { RedcapRequest, TracHours } from '@/types';

function safeString(val: unknown): string {
  if (val === null || val === undefined) return '';
  return String(val).trim();
}

function safeNumber(val: unknown): number | null {
  if (val === null || val === undefined || val === '') return null;
  const n = Number(val);
  return isNaN(n) ? null : n;
}

function excelDateToString(val: unknown): string {
  if (!val) return '';
  if (typeof val === 'number') {
    const date = XLSX.SSF.parse_date_code(val);
    if (date) {
      return `${date.m}/${date.d}/${String(date.y).slice(-2)}`;
    }
  }
  return safeString(val);
}

// Column mapping based on the sample dive_sample.xlsx
const REDCAP_COLUMN_MAP: Record<string, keyof RedcapRequest> = {
  'Record ID': 'recordId',
  'Date of Request': 'dateOfRequest',
  'Date Completed': 'dateCompleted',
  'Individual Requesting Service': 'requestor',
  'Principal Investigator (PI)': 'pi',
  'Department': 'department',
  'Email': 'requestorEmail',
  'Position': 'piPosition',
  'Faculty Rank': 'facultyRank',
  'IRB Number': 'irbNumber',
  'IRB Short Title': 'irbShortTitle',
  'Request Type': 'requestType',
  'trac_time': 'tracTime',
};

const REDCAP_REQUIRED_COLUMNS = ['Record ID', 'Date of Request', 'Principal Investigator'];
const TRAC_REQUIRED_COLUMNS_NEW = ['redcap_id'];
const TRAC_REQUIRED_COLUMNS_OLD = ['redcap_ticket_number', 'hours'];

function validateColumns(headers: string[], expected: string[], label: string): string[] {
  const lowerHeaders = headers.map(h => h.toLowerCase());
  const missing = expected.filter(col => !lowerHeaders.some(h => h.includes(col.toLowerCase())));
  if (missing.length === expected.length) {
    return [`This file does not appear to be a ${label} export. None of the expected columns were found (${expected.join(', ')}). Please check that you selected the correct file.`];
  }
  if (missing.length > 0) {
    return [`Warning: Some expected ${label} columns are missing: ${missing.join(', ')}. Data may be incomplete.`];
  }
  return [];
}

export function parseRedcapExcel(file: File): Promise<{ requests: RedcapRequest[]; errors: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

        if (rows.length === 0) {
          resolve({ requests: [], errors: ['File contains no data rows.'] });
          return;
        }

        const headers = Object.keys(rows[0]);
        const colErrors = validateColumns(headers, REDCAP_REQUIRED_COLUMNS, 'REDCap');
        if (colErrors.length > 0 && colErrors[0].startsWith('This file does not appear')) {
          resolve({ requests: [], errors: colErrors });
          return;
        }

        const errors: string[] = [...colErrors];
        const requests: RedcapRequest[] = [];

        rows.forEach((row, idx) => {
          const recordId = safeString(row['Record ID']);
          if (!recordId) {
            errors.push(`Row ${idx + 2}: Missing Record ID, skipped`);
            return;
          }

          // Find columns by partial match for long headers
          const cols = Object.keys(row);
          const findCol = (partial: string) => cols.find(c => c.toLowerCase().includes(partial.toLowerCase())) || '';

          requests.push({
            recordId,
            dateOfRequest: excelDateToString(row['Date of Request'] ?? row[findCol('Date of Request')]),
            dateCompleted: excelDateToString(row['Date Completed'] ?? row[findCol('Date Completed')]),
            requestor: safeString(row['Individual Requesting Service'] ?? row[findCol('Individual Requesting')]),
            pi: safeString(row['Principal Investigator (PI)'] ?? row[findCol('Principal Investigator')]),
            department: safeString(row['Department'] ?? ''),
            projectTitle: safeString(row[findCol('Study/Project Title')] ?? ''),
            requestorEmail: safeString(row['Email'] ?? ''),
            piDepartment: safeString(row[findCol('Department')] ?? ''),
            piPosition: safeString(row['Position'] ?? row[findCol('Position')]),
            piEmail: (() => {
              const emailCols = cols.filter(c => c.toLowerCase() === 'email');
              return safeString(emailCols.length > 1 ? row[emailCols[1]] : row[emailCols[0]] ?? '');
            })(),
            facultyRank: safeString(row['Faculty Rank'] ?? row[findCol('Faculty Rank')]),
            fundingSource: safeString(row[findCol('Funding Source')] ?? ''),
            fundingMechanism: safeString(row[findCol('Funding Mechanism')] ?? ''),
            otherFunding: safeString(row[findCol("Other' federal")] ?? ''),
            institutionalPilot: safeString(row[findCol('institutional pilot')] ?? ''),
            pilotSource: safeString(row[findCol('primary funding source of the pilot')] ?? ''),
            otherPilotSource: safeString(row[findCol('another funding source')] ?? ''),
            irbNumber: safeString(row['IRB Number'] ?? row[findCol('IRB Number')]),
            irbShortTitle: safeString(row['IRB Short Title'] ?? row[findCol('IRB Short Title')]),
            qiProject: safeString(row[findCol('Quality Improvement')] ?? ''),
            dataDeadline: excelDateToString(row[findCol('data deadline')] ?? ''),
            initiative: safeString(row[findCol('initiative')] ?? ''),
            recruitmentRelated: safeString(row[findCol('recruitment or feasibility')] ?? ''),
            inclusionCriteria: safeString(row[findCol('Inclusion Criteria')] ?? ''),
            exclusionCriteria: safeString(row[findCol('Exclusion Criteria')] ?? ''),
            dataElements: safeString(row[findCol('data elements')] ?? ''),
            requestType: safeString(row['Request Type'] ?? row[findCol('Request Type')]),
            tracTime: safeNumber(row['trac_time'] ?? row[findCol('trac_time')]),
          });
        });

        resolve({ requests, errors });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Parse a complex hours field that may contain:
 * - Plain numbers: "5" → 5
 * - Ranges: "14-15" → 15 (take max)
 * - Text descriptions: "20 prog hrs and 5 dc hrs" → 25
 * - Numbers with parenthetical notes: "40 (8 addtl hrs/yr)" → 40
 * - Serial dates (>40000): revert to default of 2
 */
function parseHoursField(val: unknown): number | null {
  if (val === null || val === undefined || val === '') return null;
  const raw = String(val).trim();
  if (!raw) return null;

  const n = Number(raw);
  if (!isNaN(n)) {
    return n > 40000 ? 2 : n;
  }

  // Remove parenthetical notes: "40 (8 addtl hrs/yr)" → "40"
  const withoutParens = raw.replace(/\([^)]*\)/g, '').trim();

  // Check if it's a simple range like "14-15"
  const rangeMatch = withoutParens.match(/^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)$/);
  if (rangeMatch) {
    return Math.max(Number(rangeMatch[1]), Number(rangeMatch[2]));
  }

  // Text with multiple numbers: "20 prog hrs and 5 dc hrs", "32 for programmer, 4 for coordinator", "40 prog 10 PM"
  const numbers = withoutParens.match(/(\d+(?:\.\d+)?)/g);
  if (numbers && numbers.length > 0) {
    const parsed = numbers.map(Number).filter(x => !isNaN(x) && x <= 40000);
    if (parsed.length > 0) return parsed.reduce((a, b) => a + b, 0);
  }

  return null;
}

export function parseTracExcel(file: File): Promise<{ hours: TracHours[]; errors: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

        if (rows.length === 0) {
          resolve({ hours: [], errors: ['File contains no data rows.'] });
          return;
        }

        const cols = Object.keys(rows[0]);
        const hasRedcapId = cols.some(c => c.toLowerCase() === 'redcap_id');
        const hasTicketNumber = cols.some(c => c.toLowerCase() === 'redcap_ticket_number');

        if (!hasRedcapId && !hasTicketNumber) {
          const colErrors = validateColumns(cols, [...TRAC_REQUIRED_COLUMNS_NEW, ...TRAC_REQUIRED_COLUMNS_OLD], 'Trac');
          resolve({ hours: [], errors: [`This file does not appear to be a Trac export. Expected columns "redcap_id" or "redcap_ticket_number" were not found. Please check that you selected the correct file.`] });
          return;
        }

        const errors: string[] = [];
        const hoursMap = new Map<string, number>();

        rows.forEach((row, idx) => {
          let recordId: string;

          if (hasRedcapId) {
            // New trac format: sum hours_unknown_source + pm_hours + programmer_hours
            const findCol = (partial: string) => cols.find(c => c.toLowerCase().includes(partial.toLowerCase())) || '';
            recordId = safeString(row['redcap_id'] ?? row[findCol('redcap_id')]);
            if (!recordId) {
              errors.push(`Row ${idx + 2}: Missing redcap_id, skipped`);
              return;
            }

            const hoursUnknown = parseHoursField(row[findCol('hours_unknown_source')]);
            const pmHours = parseHoursField(row[findCol('pm_hours')]);
            const progHours = parseHoursField(row[findCol('programmer_hours')]);

            // Filter out billed columns. Default to 2 hours if all sources are null OR sum to 0.
            let total: number;
            if (hoursUnknown === null && pmHours === null && progHours === null) {
              total = 2; // default when all null
            } else {
              total = (hoursUnknown ?? 0) + (pmHours ?? 0) + (progHours ?? 0);
              if (total <= 0) total = 2; // default when explicitly zero/blank
            }

            hoursMap.set(recordId, (hoursMap.get(recordId) ?? 0) + total);
          } else if (hasTicketNumber) {
            // Old trac format: redcap_ticket_number + hours
            recordId = safeString(row['redcap_ticket_number']);
            if (!recordId) {
              errors.push(`Row ${idx + 2}: Missing redcap_ticket_number, skipped`);
              return;
            }

            let hrs = parseHoursField(row['hours']);
            if (hrs === null || hrs <= 0) hrs = 2;

            hoursMap.set(recordId, (hoursMap.get(recordId) ?? 0) + hrs);
          } else {
            if (idx === 0) errors.push('Unrecognized trac format: expected redcap_id or redcap_ticket_number column');
            return;
          }
        });

        const hours: TracHours[] = Array.from(hoursMap.entries()).map(([recordId, totalHours]) => ({
          recordId,
          totalHours: totalHours > 0 ? totalHours : 2,
          source: hasRedcapId ? 'trac' as const : 'old_trac' as const,
        }));

        resolve({ hours, errors });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

export function exportToExcel(requests: RedcapRequest[], filename = 'research_requests_export.xlsx') {
  const exportData = requests.map(r => ({
    'Record ID': r.recordId,
    'PI': r.pi,
    'Department': r.department,
    'Project Title': r.projectTitle,
    'Faculty Rank': r.facultyRank,
    'Funding Source': r.fundingSource,
    'Request Type': r.requestType,
    'Date of Request': r.dateOfRequest,
    'Date Completed': r.dateCompleted,
    'IRB Number': r.irbNumber,
    'Trac Time': r.tracTime,
  }));

  const ws = XLSX.utils.json_to_sheet(exportData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Requests');
  XLSX.writeFile(wb, filename);
}
