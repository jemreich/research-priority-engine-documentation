/**
 * Normalize PI names to merge common nickname variants.
 * e.g. "Steve Feldman" and "Steven Feldman" → "Steven Feldman"
 */

const NICKNAME_MAP: Record<string, string> = {
  steve: 'steven',
  mike: 'michael',
  bill: 'william',
  will: 'william',
  bob: 'robert',
  bobby: 'robert',
  rob: 'robert',
  dick: 'richard',
  rick: 'richard',
  rich: 'richard',
  jim: 'james',
  jimmy: 'james',
  joe: 'joseph',
  joey: 'joseph',
  tom: 'thomas',
  tommy: 'thomas',
  dan: 'daniel',
  danny: 'daniel',
  dave: 'david',
  ed: 'edward',
  ted: 'edward',
  tony: 'anthony',
  chris: 'christopher',
  matt: 'matthew',
  pat: 'patricia',
  patty: 'patricia',
  patti: 'patricia',
  beth: 'elizabeth',
  liz: 'elizabeth',
  sue: 'susan',
  kate: 'katherine',
  kathy: 'katherine',
  cathy: 'catherine',
  jeff: 'jeffrey',
  greg: 'gregory',
  larry: 'lawrence',
  jerry: 'gerald',
  charlie: 'charles',
  chuck: 'charles',
  nick: 'nicholas',
  alex: 'alexander',
  al: 'albert',
  ben: 'benjamin',
  sam: 'samuel',
  andy: 'andrew',
  drew: 'andrew',
  ken: 'kenneth',
  ron: 'ronald',
  don: 'donald',
  jon: 'jonathan',
  wes: 'wesley',
  ray: 'raymond',
  phil: 'philip',
  frank: 'francis',
  fred: 'frederick',
  jack: 'john',
  jen: 'jennifer',
  jenny: 'jennifer',
  meg: 'margaret',
  peggy: 'margaret',
  margie: 'margaret',
};

/**
 * Canonicalize a first name using nickname mapping.
 */
function canonicalFirst(first: string): string {
  const lower = first.toLowerCase();
  return NICKNAME_MAP[lower] ?? lower;
}

/**
 * Build a canonical key for a PI name.
 * "Steve Feldman" → "steven feldman"
 */
export function canonicalPIName(name: string): string {
  const trimmed = name.trim();
  if (!trimmed) return '';

  // Handle "Last, First" format
  if (trimmed.includes(',')) {
    const [last, ...firstParts] = trimmed.split(',').map(s => s.trim());
    const firstRaw = firstParts.join(' ').trim();
    const first = canonicalFirst(firstRaw.split(/\s+/)[0] || '');
    const restFirst = firstRaw.split(/\s+/).slice(1).map(p => p.toLowerCase()).join(' ');
    const fullFirst = `${first} ${restFirst}`.trim();
    return `${last.toLowerCase()} ${fullFirst}`.trim();
  }

  // Handle "First Last" format
  const parts = trimmed.split(/\s+/);
  const first = canonicalFirst(parts[0]);
  const rest = parts.slice(1).map(p => p.toLowerCase()).join(' ');
  return `${first} ${rest}`.trim();
}

/**
 * Given a list of raw PI names, return a Map from raw name → canonical display name.
 * The canonical display name picks the longest variant as the "official" name.
 */
export function buildPINameMap(names: string[]): Map<string, string> {
  // Group by canonical key
  const groups = new Map<string, string[]>();
  for (const name of names) {
    const key = canonicalPIName(name);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(name);
  }

  // For each group, pick the longest name as canonical display
  const result = new Map<string, string>();
  for (const [, variants] of groups) {
    const display = variants.reduce((a, b) => a.length >= b.length ? a : b);
    for (const v of variants) {
      result.set(v, display);
    }
  }
  return result;
}
