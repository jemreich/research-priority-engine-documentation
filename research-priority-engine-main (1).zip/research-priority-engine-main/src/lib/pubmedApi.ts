import { getNcbiApiKey } from './apiKeys';
import { RESEARCH_STOPWORDS } from './stopwords';
import type { RequestPublication } from '@/types';

const ESEARCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi';
const EFETCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi';
const INSTITUTIONAL_AFFILIATION = 'Wake Forest';
const MAX_RETRIES = 3;
const RETRY_DELAYS = [1000, 2000, 4000]; // exponential backoff

export interface PubMedQueryInput {
  recordId: string;
  piName: string; // "Last, First" format
  yearCompleted: number | null;
  department?: string;
  projectTitle?: string;
}

export interface PubMedResult {
  recordId: string;
  pmid: string;
  title: string;
  doi: string | null;
  journal: string;
  yearPublished: number | null;
  grants: string;
  authorCount: number | null;
}

export interface PubMedSearchResult {
  recordId: string;
  status: 'matched' | 'no_results' | 'filtered_out' | 'error';
  publications: PubMedResult[];
  queryString: string;
  pmidsReturned: number;
  pmidsAfterFilter: number;
  errorMessage?: string;
  responseTimeMs: number;
}

/**
 * Extract PI last name from "Last, First" format
 */
export function extractLastName(piName: string): string {
  const parts = piName.split(',');
  return parts[0].trim();
}

/**
 * Extract keywords from project title per PRD:
 * Remove stopwords, select two longest remaining words.
 * Returns empty array if fewer than 1 keyword remains.
 */
export function extractKeywords(projectTitle: string | undefined): string[] {
  if (!projectTitle) return [];

  const words = projectTitle
    .replace(/[^a-zA-Z\s]/g, '') // remove non-alpha
    .split(/\s+/)
    .map(w => w.toLowerCase())
    .filter(w => w.length > 2 && !RESEARCH_STOPWORDS.has(w));

  // Sort by length descending, take top 2
  const sorted = [...words].sort((a, b) => b.length - a.length);
  return sorted.slice(0, 2);
}

/**
 * Build PubMed query string per PRD spec:
 * LastName[Author] AND Wake Forest[Affiliation] AND (keyword1) AND (keyword2) AND MinYear:3000[dp]
 */
export function buildQuery(input: PubMedQueryInput): string {
  const lastName = extractLastName(input.piName);
  const parts: string[] = [
    `${lastName}[Author]`,
    `${INSTITUTIONAL_AFFILIATION}[Affiliation]`,
  ];

  const keywords = extractKeywords(input.projectTitle);
  keywords.forEach(kw => parts.push(`(${kw})`));

  if (input.yearCompleted) {
    const minYear = input.yearCompleted + 2;
    parts.push(`${minYear}:3000[dp]`);
  }

  return parts.join(' AND ');
}

/**
 * Delay helper
 */
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Fetch with retry and exponential backoff for 429/500/503
 */
async function fetchWithRetry(url: string, retries = MAX_RETRIES): Promise<Response> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const response = await fetch(url);
    if (response.ok) return response;

    if ([429, 500, 503].includes(response.status) && attempt < retries) {
      await delay(RETRY_DELAYS[attempt] || 4000);
      continue;
    }
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }
  throw new Error('Max retries exceeded');
}

/**
 * Run esearch to get PMIDs
 */
async function esearch(query: string): Promise<string[]> {
  const apiKey = getNcbiApiKey();
  const params = new URLSearchParams({
    db: 'pubmed',
    term: query,
    retmax: '100',
    retmode: 'json',
    ...(apiKey ? { api_key: apiKey } : {}),
  });

  const response = await fetchWithRetry(`${ESEARCH_URL}?${params}`);
  const data = await response.json();
  return data?.esearchresult?.idlist || [];
}

/**
 * Parse year from PubMed XML PubDate element.
 * Handles structured <Year> and fallback MedlineDate format.
 */
export function parseYearFromPubDate(pubDateXml: string): number | null {
  // Try structured <Year>
  const yearMatch = pubDateXml.match(/<Year>(\d{4})<\/Year>/);
  if (yearMatch) return parseInt(yearMatch[1], 10);

  // Fallback: MedlineDate like "Winter 2019" or "2019 Jan-Feb"
  const medlineDateMatch = pubDateXml.match(/<MedlineDate>([^<]+)<\/MedlineDate>/);
  if (medlineDateMatch) {
    const fourDigit = medlineDateMatch[1].match(/(\d{4})/);
    if (fourDigit) return parseInt(fourDigit[1], 10);
  }

  return null;
}

/**
 * Parse PubMed XML article into structured result
 */
export function parseArticleXml(articleXml: string, recordId: string): PubMedResult | null {
  // Extract PMID
  const pmidMatch = articleXml.match(/<PMID[^>]*>(\d+)<\/PMID>/);
  if (!pmidMatch) return null;

  // Extract DOI
  const doiMatch = articleXml.match(/<ArticleId IdType="doi">([^<]+)<\/ArticleId>/);
  const doi = doiMatch ? doiMatch[1] : null;

  // Extract Journal (ISOAbbreviation preferred, Title fallback)
  const isoMatch = articleXml.match(/<ISOAbbreviation>([^<]+)<\/ISOAbbreviation>/);
  const titleMatch = articleXml.match(/<Title>([^<]+)<\/Title>/);
  const journal = isoMatch ? isoMatch[1] : (titleMatch ? titleMatch[1] : 'Unknown');

  // Extract article title
  const articleTitleMatch = articleXml.match(/<ArticleTitle>([^<]+)<\/ArticleTitle>/);
  const articleTitle = articleTitleMatch ? articleTitleMatch[1] : '';

  // Extract year from PubDate
  const pubDateMatch = articleXml.match(/<PubDate>([\s\S]*?)<\/PubDate>/);
  const yearPublished = pubDateMatch ? parseYearFromPubDate(pubDateMatch[1]) : null;

  // Extract author count from AuthorList (count <Author> elements, excluding CollectiveName-only entries)
  const authorListMatch = articleXml.match(/<AuthorList[^>]*>([\s\S]*?)<\/AuthorList>/);
  let authorCount: number | null = null;
  if (authorListMatch) {
    const authorMatches = authorListMatch[1].match(/<Author[\s>][\s\S]*?<\/Author>/g) || [];
    authorCount = authorMatches.length > 0 ? authorMatches.length : null;
  }

  // Extract grants — store grant IDs separated by semicolons
  const grantMatches = articleXml.match(/<Grant>([\s\S]*?)<\/Grant>/g) || [];
  const grants = grantMatches.map(g => {
    const grantId = g.match(/<GrantID>([^<]+)<\/GrantID>/)?.[1]?.trim() || '';
    const agency = g.match(/<Agency>([^<]+)<\/Agency>/)?.[1]?.trim() || '';
    const country = g.match(/<Country>([^<]+)<\/Country>/)?.[1]?.trim() || '';
    // For NIH grants, just return the grant ID (e.g. "P30 CA012197")
    // For international grants, return "grantId / agency" so we preserve the full name
    if (country === 'United States' && grantId) {
      return grantId;
    }
    return [grantId, agency].filter(Boolean).join(' / ') || null;
  }).filter(Boolean).join('; ');

  return {
    recordId,
    pmid: pmidMatch[1],
    title: articleTitle,
    doi,
    journal,
    yearPublished,
    grants,
    authorCount,
  };
}

/**
 * Run efetch in batch mode for PMIDs, return raw XML
 */
async function efetch(pmids: string[]): Promise<string> {
  const apiKey = getNcbiApiKey();
  const params = new URLSearchParams({
    db: 'pubmed',
    id: pmids.join(','),
    retmode: 'xml',
    ...(apiKey ? { api_key: apiKey } : {}),
  });

  const response = await fetchWithRetry(`${EFETCH_URL}?${params}`);
  return response.text();
}

/**
 * Filter articles per PRD:
 * 1. Publication year >= yearCompleted + 2
 * 2. PI last name appears in AuthorList (case-insensitive)
 */
export function filterArticles(
  articles: PubMedResult[],
  piLastName: string,
  yearCompleted: number | null
): PubMedResult[] {
  return articles.filter(article => {
    // Year filter
    if (yearCompleted && article.yearPublished) {
      if (article.yearPublished < yearCompleted + 2) return false;
    }
    // Author filter is applied during XML parsing via AuthorList check
    return true;
  });
}

/**
 * Check if PI last name appears in the article's author list XML
 */
export function authorMatchesInXml(articleXml: string, piLastName: string): boolean {
  const authorListMatch = articleXml.match(/<AuthorList[^>]*>([\s\S]*?)<\/AuthorList>/);
  if (!authorListMatch) return false;

  const lastNames = [...authorListMatch[1].matchAll(/<LastName>([^<]+)<\/LastName>/g)]
    .map(m => m[1].toLowerCase());

  return lastNames.includes(piLastName.toLowerCase());
}

/**
 * Main entry: search PubMed for a single request
 */
export async function searchPubMedForRequest(input: PubMedQueryInput): Promise<PubMedSearchResult> {
  const startTime = Date.now();
  const query = buildQuery(input);
  const piLastName = extractLastName(input.piName);

  try {
    // Step 1: esearch
    const pmids = await esearch(query);

    if (pmids.length === 0) {
      return {
        recordId: input.recordId,
        status: 'no_results',
        publications: [],
        queryString: query,
        pmidsReturned: 0,
        pmidsAfterFilter: 0,
        responseTimeMs: Date.now() - startTime,
      };
    }

    // Enforce rate limit delay (0.1s between calls)
    await delay(100);

    // Step 2: efetch
    const xml = await efetch(pmids);

    // Step 3: Parse articles
    const articleXmls = xml.match(/<PubmedArticle>([\s\S]*?)<\/PubmedArticle>/g) || [];
    const seenPmids = new Set<string>(); // within-request dedup

    const parsed: PubMedResult[] = [];
    for (const artXml of articleXmls) {
      // Author filter
      if (!authorMatchesInXml(artXml, piLastName)) continue;

      const result = parseArticleXml(artXml, input.recordId);
      if (!result) continue;

      // Within-request deduplication
      if (seenPmids.has(result.pmid)) continue;
      seenPmids.add(result.pmid);

      parsed.push(result);
    }

    // Step 4: Year filter
    const filtered = filterArticles(parsed, piLastName, input.yearCompleted);

    if (filtered.length === 0) {
      return {
        recordId: input.recordId,
        status: 'filtered_out',
        publications: [],
        queryString: query,
        pmidsReturned: pmids.length,
        pmidsAfterFilter: 0,
        responseTimeMs: Date.now() - startTime,
      };
    }

    return {
      recordId: input.recordId,
      status: 'matched',
      publications: filtered,
      queryString: query,
      pmidsReturned: pmids.length,
      pmidsAfterFilter: filtered.length,
      responseTimeMs: Date.now() - startTime,
    };
  } catch (error) {
    return {
      recordId: input.recordId,
      status: 'error',
      publications: [],
      queryString: query,
      pmidsReturned: 0,
      pmidsAfterFilter: 0,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      responseTimeMs: Date.now() - startTime,
    };
  }
}

/**
 * Convert PubMedResult to RequestPublication for storage
 */
export function toRequestPublication(result: PubMedResult): RequestPublication {
  return {
    recordId: result.recordId,
    pmid: result.pmid,
    title: result.title,
    doi: result.doi || '',
    journal: result.journal,
    yearPublished: result.yearPublished,
    grants: result.grants,
    relativeCitationRatio: null,
    citationCount: null,
    apt: null,
    nihPercentile: null,
    citationsPerYear: null,
    expectedCitationsPerYear: null,
    fieldCitationRate: null,
    isClinical: null,
    iciteEnrichedAt: null,
    authorCount: result.authorCount,
  };
}

/**
 * Batch search: run PubMed search for multiple requests with rate limiting
 */
export async function batchSearchPubMed(
  inputs: PubMedQueryInput[],
  onProgress?: (completed: number, total: number) => void
): Promise<PubMedSearchResult[]> {
  const apiKey = getNcbiApiKey();
  const delayMs = apiKey ? 100 : 334; // 10/sec with key, 3/sec without
  const results: PubMedSearchResult[] = [];

  for (let i = 0; i < inputs.length; i++) {
    const result = await searchPubMedForRequest(inputs[i]);
    results.push(result);
    onProgress?.(i + 1, inputs.length);

    if (i < inputs.length - 1) {
      await delay(delayMs);
    }
  }

  return results;
}
