/**
 * ROI Scoring Engine — Step 5
 *
 * Computes four category subscores, a weighted composite return score,
 * and an effort-adjusted ROI score for each request.
 *
 * Tier classification:
 *   T1 (Full)         – has ≥1 publication with iCite data AND PI enrichment
 *   T2 (Proxy)        – has PI enrichment OR publications but not both complete
 *   T3 (Insufficient) – no publications and no PI enrichment
 *
 * Niche bonus: applied when a request's specialty has market cap < threshold
 *              AND CAGR > threshold (admin-configurable).
 */

import type {
  RedcapRequest,
  RequestPublication,
  PIEnrichmentCache,
  JournalEnrichment,
  TracHours,
  WeightConfig,
  AdminConfig,
  RequestScore,
} from '@/types';
// Note: market-based niche detection has been replaced with SCImago metric-based criteria.

// ─── Helpers ──────────────────────────────────────────────

/** Clamp a value to [0, 100] */
function clamp(v: number): number {
  return Math.max(0, Math.min(100, v));
}

/** Safe median */
function median(arr: number[]): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

// ─── Subscore calculators ─────────────────────────────────

/**
 * S1 — Publication Impact Score (0–100)
 * Based on iCite metrics for the request's publications:
 *   - Relative Citation Ratio (RCR): median across pubs, scaled 0-100 (RCR 2.0 = 100)
 *   - NIH Percentile: median, already 0–100
 *   - Citation count: log-scaled
 * Blended 40/40/20.
 */
// ─── Sub-metric raw-score calculators (each returns 0–100, no weights applied) ─

/** S1 sub-metrics — Publication Impact (iCite-derived). */
function calcS1RawScores(pubs: RequestPublication[]): {
  rcr: number | null;
  nihPercentile: number | null;
  citationCount: number | null;
} {
  const enrichedPubs = pubs.filter(p => p.iciteEnrichedAt);
  if (enrichedPubs.length === 0) return { rcr: null, nihPercentile: null, citationCount: null };

  const rcrs = enrichedPubs.map(p => p.relativeCitationRatio).filter((v): v is number => v != null);
  const percentiles = enrichedPubs.map(p => p.nihPercentile).filter((v): v is number => v != null);
  const citations = enrichedPubs.map(p => p.citationCount).filter((v): v is number => v != null);

  return {
    rcr: rcrs.length > 0 ? clamp((median(rcrs) / 2.0) * 100) : null,
    nihPercentile: percentiles.length > 0 ? clamp(median(percentiles)) : null,
    citationCount: citations.length > 0 ? clamp((Math.log10(median(citations) + 1) / 2) * 100) : null,
  };
}

/** S2 sub-metrics — Journal Prestige (median across the request's publications). */
function calcS2RawScores(
  pubs: RequestPublication[],
  journalCache: JournalEnrichment[],
): {
  sjrQuartile: number | null;
  sjr: number | null;
  h5Index: number | null;
  citPerDoc2yr: number | null;
} {
  if (pubs.length === 0) return { sjrQuartile: null, sjr: null, h5Index: null, citPerDoc2yr: null };

  const qMap: Record<string, number> = { Q1: 100, Q2: 75, Q3: 50, Q4: 25 };
  const qs: number[] = [];
  const sjrs: number[] = [];
  const h5s: number[] = [];
  const cds: number[] = [];

  for (const pub of pubs) {
    const je = journalCache.find(
      j => j.journalName === pub.journal || j.originalName === pub.journal,
    );
    if (!je) continue;
    if (je.sjrQuartile && qMap[je.sjrQuartile] != null) qs.push(qMap[je.sjrQuartile]);
    if (je.sjr != null) sjrs.push(clamp((je.sjr / 5.0) * 100));
    if (je.h5Index != null) h5s.push(clamp((je.h5Index / 100) * 100));
    if (je.citPerDoc2yr != null) cds.push(clamp((je.citPerDoc2yr / 10) * 100));
  }

  return {
    sjrQuartile: qs.length > 0 ? median(qs) : null,
    sjr: sjrs.length > 0 ? median(sjrs) : null,
    h5Index: h5s.length > 0 ? median(h5s) : null,
    citPerDoc2yr: cds.length > 0 ? median(cds) : null,
  };
}

/** S3 sub-metrics — Funding Activity (request + PI grant portfolio). */
function calcS3RawScores(
  request: RedcapRequest,
  piData: PIEnrichmentCache | undefined,
): {
  fundingSource: number | null;
  activeGrants: number | null;
  totalFunding: number | null;
} {
  let fundingSource: number | null = null;
  if (request.fundingSource) {
    const src = request.fundingSource.toLowerCase();
    if (src.includes('nih') || src.includes('federal')) fundingSource = 100;
    else if (src.includes('industry') || src.includes('foundation')) fundingSource = 67;
    else if (src.includes('internal') || src.includes('pilot')) fundingSource = 33;
    else fundingSource = 50;
  }

  let activeGrants: number | null = null;
  let totalFunding: number | null = null;
  if (piData && piData.status === 'enriched') {
    activeGrants = clamp(((piData.activeGrants ?? 0) / 3) * 100);
    totalFunding = clamp(((piData.totalGrantFunding ?? 0) / 5_000_000) * 100);
  }

  return { fundingSource, activeGrants, totalFunding };
}

/** S4 sub-metrics — Research Output (PI scholarly profile + faculty rank). */
function calcS4RawScores(
  piData: PIEnrichmentCache | undefined,
  request: RedcapRequest,
): {
  hIndex: number | null;
  totalPublications: number | null;
  totalCitations: number | null;
  facultyRank: number | null;
} {
  if (!piData || piData.status !== 'enriched') {
    return { hIndex: null, totalPublications: null, totalCitations: null, facultyRank: null };
  }
  return {
    hIndex: clamp(((piData.hIndex ?? 0) / 40) * 100),
    totalPublications: clamp(((piData.totalPublications ?? 0) / 200) * 100),
    totalCitations: clamp((Math.log10((piData.totalCitations ?? 0) + 1) / 4) * 100),
    facultyRank: scoreFacultyRank(request.facultyRank),
  };
}

// ─── Category subscore helpers (sum of weighted sub-metrics within a group) ──
// Used for per-category display in the dashboard. The composite ROI uses
// the full expanded weighted sum across all sub-metrics — see scoreAllRequests.

function sumWeighted(parts: Array<{ score: number | null; w: number }>): number | null {
  const present = parts.filter(p => p.score != null) as Array<{ score: number; w: number }>;
  if (present.length === 0) return null;
  return present.reduce((s, p) => s + p.score * p.w, 0);
}

/**
 * Maps a free-text faculty rank string to a 0–100 score.
 * Higher ranks (e.g. Professor, Endowed Chair) score highest;
 * non-faculty staff (research assistants, students) score lowest.
 * Returns null when the rank is empty/unrecognized so it can be excluded
 * from the weighted average without distorting it.
 */
export function scoreFacultyRank(rank: string | null | undefined): number | null {
  if (!rank) return null;
  const r = rank.toLowerCase().trim();
  if (!r || r === '—' || r === 'n/a' || r === 'unknown') return null;

  // Tiered mapping — order matters; check most specific first.
  // Endowed / named chairs and full professors → top tier
  if (/(endowed|named chair|distinguished)/.test(r)) return 100;
  if (/(emeritus|emerita)/.test(r)) return 85;
  if (/(^|\s)(full\s+)?professor(\b|$)/.test(r) && !/assistant|associate|adjunct|clinical|research/.test(r)) return 95;
  if (/associate\s+professor/.test(r)) return 80;
  if (/assistant\s+professor/.test(r)) return 65;
  if (/(adjunct|visiting)\s+professor/.test(r)) return 55;
  if (/(clinical|research)\s+professor/.test(r)) return 70;
  if (/(instructor|lecturer)/.test(r)) return 45;
  // Postdoc / fellows
  if (/(post[-\s]?doc|postdoctoral|fellow)/.test(r)) return 35;
  // Residents / clinical trainees
  if (/(resident|trainee)/.test(r)) return 25;
  // Non-faculty research staff
  if (/(research\s+(scientist|associate|coordinator)|staff\s+scientist|program\s+(manager|coordinator))/.test(r)) return 30;
  if (/(research\s+assistant|graduate\s+student|grad\s+student|phd\s+student|student)/.test(r)) return 15;
  if (/(non[-\s]?faculty)/.test(r)) return 20;

  // Fallback: presence of "professor" anywhere
  if (/professor/.test(r)) return 75;
  // Faculty (untyped)
  if (/faculty/.test(r)) return 60;

  // Unknown rank present but unmapped — give a neutral mid score
  return 50;
}

// ─── Tier classification ──────────────────────────────────

function classifyTier(
  pubs: RequestPublication[],
  piData: PIEnrichmentCache | undefined,
): 1 | 2 | 3 {
  const hasEnrichedPubs = pubs.some(p => p.iciteEnrichedAt);
  const hasPIData = piData?.status === 'enriched';

  if (hasEnrichedPubs && hasPIData) return 1;
  if (hasEnrichedPubs || hasPIData) return 2;
  return 3;
}

// ─── Niche bonus (SCImago-based) ───────────────────────────

import type { NicheNumericMetric, SJRQuartile } from '@/types';

function getJournalMetric(je: JournalEnrichment, m: NicheNumericMetric): number | null {
  switch (m) {
    case 'sjr': return je.sjr;
    case 'sjrHIndex': return je.sjrHIndex;
    case 'totalDocs3yr': return je.totalDocs3yr;
    case 'citPerDoc2yr': return je.citPerDoc2yr;
  }
}

/** Reasonable upper bound per metric, used to scale interpolation t ∈ [0,1]. */
function metricMaxScale(m: NicheNumericMetric): number {
  switch (m) {
    case 'sjr': return 10;
    case 'sjrHIndex': return 500;
    case 'totalDocs3yr': return 2000;
    case 'citPerDoc2yr': return 20;
  }
}

function journalMatchesNiche(je: JournalEnrichment, config: AdminConfig): boolean {
  // Quartile gate
  if (config.nicheQuartileCriterion?.enabled) {
    const q = je.sjrQuartile as SJRQuartile | null;
    if (!q || !config.nicheQuartileCriterion.allowedQuartiles.includes(q)) return false;
  }
  // Numeric gates
  for (const c of config.nicheNumericCriteria ?? []) {
    if (!c.enabled) continue;
    const v = getJournalMetric(je, c.metric);
    if (v == null) return false;
    if (c.operator === 'lte' && !(v <= c.threshold)) return false;
    if (c.operator === 'gte' && !(v >= c.threshold)) return false;
  }
  // Require at least one enabled criterion
  const anyEnabled =
    !!config.nicheQuartileCriterion?.enabled ||
    (config.nicheNumericCriteria ?? []).some(c => c.enabled);
  return anyEnabled;
}

function calcNicheMultiplier(
  pubs: RequestPublication[],
  journalCache: JournalEnrichment[],
  config: AdminConfig,
): number {
  if (config.nicheBonusEnabled === false) return 1.0;

  for (const pub of pubs) {
    const je = journalCache.find(
      j => j.journalName === pub.journal || j.originalName === pub.journal,
    );
    if (!je) continue;
    if (!journalMatchesNiche(je, config)) continue;

    // Interpolate using the chosen driver metric.
    // Interpretation: lower driver value = more "niche" → closer to Max.
    // Find the active criterion (if any) for the driver metric to derive a scale.
    const driver = config.nicheInterpolationMetric;
    const driverCrit = (config.nicheNumericCriteria ?? []).find(
      c => c.enabled && c.metric === driver,
    );
    const driverValue = getJournalMetric(je, driver);
    let t = 0.5;
    if (driverValue != null) {
      const scale = driverCrit && driverCrit.operator === 'lte'
        ? driverCrit.threshold
        : metricMaxScale(driver);
      // For "lte" criteria (lower is more niche): t = 1 - v/scale
      // For "gte" criteria (higher is more niche): t = v/scale
      if (driverCrit?.operator === 'gte') {
        t = Math.min(1, Math.max(0, driverValue / scale));
      } else {
        t = Math.min(1, Math.max(0, 1 - driverValue / scale));
      }
    }
    return config.nicheBonusMultiplierMin + t * (config.nicheBonusMultiplierMax - config.nicheBonusMultiplierMin);
  }
  return 1.0;
}

// ─── Main scoring function ────────────────────────────────

export interface ScoringInput {
  requests: RedcapRequest[];
  publications: RequestPublication[];
  piCache: PIEnrichmentCache[];
  journalCache: JournalEnrichment[];
  tracHours: TracHours[];
  weights: WeightConfig;
  adminConfig: AdminConfig;
}

export function scoreAllRequests(input: ScoringInput): RequestScore[] {
  const {
    requests,
    publications,
    piCache,
    journalCache,
    tracHours,
    weights,
    adminConfig,
  } = input;

  const now = new Date().toISOString();
  const scored: RequestScore[] = [];

  for (const req of requests) {
    const reqPubs = publications.filter(p => p.recordId === req.recordId);
    const piData = piCache.find(p => {
      const piLower = req.pi.toLowerCase();
      const cacheLower = p.piName.toLowerCase();
      return cacheLower === piLower || cacheLower.includes(piLower) || piLower.includes(cacheLower);
    });
    const trac = tracHours.find(t => t.recordId === req.recordId);

    const tier = classifyTier(reqPubs, piData);

    // Compute raw 0–100 sub-metric scores for each category
    const r1 = calcS1RawScores(reqPubs);
    const r2 = calcS2RawScores(reqPubs, journalCache);
    const r3 = calcS3RawScores(req, piData);
    const r4 = calcS4RawScores(piData, req);

    // Per-category subscores = weighted sum of that category's sub-metrics.
    // Returns null if no sub-metrics in that category have data.
    const s1 = sumWeighted([
      { score: r1.rcr, w: weights.s1_rcr },
      { score: r1.nihPercentile, w: weights.s1_nihPercentile },
      { score: r1.citationCount, w: weights.s1_citationCount },
    ]);
    const s2 = sumWeighted([
      { score: r2.sjrQuartile, w: weights.s3_sjrQuartile },
      { score: r2.sjr, w: weights.s3_sjr },
      { score: r2.h5Index, w: weights.s3_h5Index },
      { score: r2.citPerDoc2yr, w: weights.s3_citPerDoc2yr },
    ]);
    const s3 = sumWeighted([
      { score: r3.fundingSource, w: weights.s4_fundingSource },
      { score: r3.activeGrants, w: weights.s4_activeGrants },
      { score: r3.totalFunding, w: weights.s4_totalFunding },
    ]);
    const s4 = sumWeighted([
      { score: r4.hIndex, w: weights.s2_hIndex },
      { score: r4.totalPublications, w: weights.s2_totalPublications },
      { score: r4.totalCitations, w: weights.s2_totalCitations },
      { score: r4.facultyRank, w: weights.s2_facultyRank },
    ]);

    const availableScores = [s1, s2, s3, s4].filter(s => s != null) as number[];
    if (availableScores.length === 0) {
      scored.push({
        recordId: req.recordId,
        publicationImpactScore: null,
        journalPrestigeScore: null,
        fundingActivityScore: null,
        researchOutputScore: null,
        weightedReturnScore: null,
        effortAdjustedROIScore: null,
        effortMultiplier: null,
        scoringTier: 3,
        rank: null,
        scoredAt: now,
        status: 'insufficient',
      });
      continue;
    }

    // Composite weighted return: straight SUM of all per-category subscores.
    // Each S_i is itself a weighted sum of its sub-metrics, so this collapses
    // to (Σ wᵢ·metricᵢ) across every sub-metric the user has configured.
    // No averaging, no renormalization — weights are absolute coefficients.
    let weightedReturn = availableScores.reduce((sum, v) => sum + v, 0);

    // Niche bonus (1.0 when disabled)
    const nicheMultiplier = calcNicheMultiplier(reqPubs, journalCache, adminConfig);
    weightedReturn *= nicheMultiplier;

    // Tier-based confidence discount (only when enabled):
    //   T2 (proxy data) → multiplied by proxyConfidenceDiscount
    //   T3 (insufficient data) → multiplied by insufficientDataDiscount
    //   T1 (full data)  → no discount (1.0)
    // When proxyEnabled === false, no tier discount is applied.
    if (adminConfig.proxyEnabled !== false) {
      if (tier === 2) {
        weightedReturn *= adminConfig.proxyConfidenceDiscount;
      } else if (tier === 3) {
        weightedReturn *= adminConfig.insufficientDataDiscount ?? 0.5;
      }
    }

    // Effort multiplier: hours worked → efficiency factor.
    // Anchored at adminConfig.effortAnchorHours (default 2h = neutral 1.0x),
    // dampened by effortDampening exponent (default 0.5 → square-root softens extremes),
    // clamped to [effortMultiplierMin, effortMultiplierMax].
    // Default to anchor hours when no Trac record exists or hours are zero/blank.
    const anchor = adminConfig.effortAnchorHours ?? 2;
    const dampening = adminConfig.effortDampening ?? 0.5;
    const minMult = adminConfig.effortMultiplierMin ?? 0.25;
    const maxMult = adminConfig.effortMultiplierMax ?? 3.0;
    const rawHours = trac?.totalHours ?? null;
    const hours = rawHours != null && rawHours > 0 ? rawHours : anchor;
    const ratio = anchor / hours;
    const raw = Math.pow(ratio, dampening);
    const effortMultiplier = Math.min(maxMult, Math.max(minMult, raw));
    const effortAdjustedROI = weightedReturn * effortMultiplier;

    scored.push({
      recordId: req.recordId,
      publicationImpactScore: s1 != null ? Math.round(s1 * 10) / 10 : null,
      journalPrestigeScore: s2 != null ? Math.round(s2 * 10) / 10 : null,
      fundingActivityScore: s3 != null ? Math.round(s3 * 10) / 10 : null,
      researchOutputScore: s4 != null ? Math.round(s4 * 10) / 10 : null,
      weightedReturnScore: Math.round(weightedReturn * 10) / 10,
      effortAdjustedROIScore: Math.round(effortAdjustedROI * 10) / 10,
      effortMultiplier: Math.round(effortMultiplier * 100) / 100,
      scoringTier: tier,
      rank: null, // assigned after sorting
      scoredAt: now,
      status: 'scored',
    });
  }

  // Assign ranks by effortAdjustedROIScore descending
  const scorable = scored
    .filter(s => s.status === 'scored')
    .sort((a, b) => (b.effortAdjustedROIScore ?? 0) - (a.effortAdjustedROIScore ?? 0));

  scorable.forEach((s, i) => {
    s.rank = i + 1;
  });

  // Insufficient get no rank (already null)
  return scored;
}
