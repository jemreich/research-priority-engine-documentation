/**
 * Specialty classification and therapeutic area market data.
 * Uses user-supplied triangular distribution mode estimates (2024, USD Billions).
 * CAGR midpoints derived from range estimates.
 */

import journalSpecialtyMap from '@/lib/journalSpecialtyMap.json';
import { normalizeJournalKey } from '@/lib/journalNormalize';

export type MedicalSpecialty =
  | 'Allergy and Immunology'
  | 'Anesthesiology'
  | 'Basic Sciences'
  | 'Biomedical Engineering'
  | 'Cardiology'
  | 'Colon and Rectal Surgery'
  | 'Dentistry'
  | 'Dermatology'
  | 'Emergency Medicine'
  | 'Endocrinology'
  | 'Environmental/Toxicology'
  | 'Family Medicine'
  | 'Forensic Pathology'
  | 'Gastroenterology'
  | 'General Surgery'
  | 'Genetics and Genomics'
  | 'Geriatrics'
  | 'Health Policy/Quality'
  | 'Health Technology'
  | 'Hematology'
  | 'Hospice and Palliative Medicine'
  | 'Hospital Medicine'
  | 'Infectious Disease'
  | 'Internal Medicine'
  | 'Medical Education'
  | 'Nephrology'
  | 'Neurological Surgery'
  | 'Neurology'
  | 'Nursing'
  | 'Nutrition'
  | 'Obstetrics and Gynecology'
  | 'Oncology/Cancer'
  | 'Orthopaedic Surgery'
  | 'Otolaryngology'
  | 'Pathology'
  | 'Pediatrics'
  | 'Pharmacy'
  | 'Physical Medicine and Rehabilitation'
  | 'Plastic Surgery'
  | 'Preventive Medicine'
  | 'Psychiatry'
  | 'Psychology/Behavioral'
  | 'Pulmonology'
  | 'Radiology'
  | 'Research Methods'
  | 'Rheumatology'
  | 'Sexual Health/Gender Medicine'
  | 'Sleep Medicine'
  | 'Thoracic Surgery'
  | 'Transplantation'
  | 'Urology'
  | 'Vascular Surgery'
  | 'Veterinary'
  | 'Vision'
  | 'Unclassified'
  | 'Other';

interface MarketData {
  marketCapBillions: number; // Mode / Most Likely estimate
  cagrPercent: number;       // Midpoint of CAGR range
}

/**
 * Triangular distribution Mode estimates (Most Likely US Market, $B).
 * Source: User-supplied Medical_Specialty_Market_Sizing.xlsx (Feb 2025).
 */
const MARKET_DATA: Partial<Record<MedicalSpecialty, MarketData>> = {
  'Allergy and Immunology':       { marketCapBillions: 19,  cagrPercent: 8.0 },
  'Anesthesiology':               { marketCapBillions: 47,  cagrPercent: 6.0 },
  'Basic Sciences':               { marketCapBillions: 12,  cagrPercent: 7.0 },
  'Biomedical Engineering':       { marketCapBillions: 55,  cagrPercent: 9.5 },
  'Cardiology':                   { marketCapBillions: 165, cagrPercent: 7.5 },
  'Colon and Rectal Surgery':     { marketCapBillions: 9,   cagrPercent: 6.0 },
  'Dentistry':                    { marketCapBillions: 165, cagrPercent: 6.0 },
  'Dermatology':                  { marketCapBillions: 28,  cagrPercent: 8.0 },
  'Emergency Medicine':           { marketCapBillions: 90,  cagrPercent: 5.0 },
  'Endocrinology':                { marketCapBillions: 25,  cagrPercent: 7.0 },
  'Environmental/Toxicology':     { marketCapBillions: 8,   cagrPercent: 6.0 },
  'Gastroenterology':             { marketCapBillions: 50,  cagrPercent: 6.0 },
  'General Surgery':              { marketCapBillions: 70,  cagrPercent: 5.0 },
  'Genetics and Genomics':        { marketCapBillions: 18,  cagrPercent: 11.5 },
  'Geriatrics':                   { marketCapBillions: 370, cagrPercent: 7.0 },
  'Health Policy/Quality':        { marketCapBillions: 6,   cagrPercent: 7.0 },
  'Health Technology':            { marketCapBillions: 45,  cagrPercent: 13.5 },
  'Infectious Disease':           { marketCapBillions: 65,  cagrPercent: 6.5 },
  'Internal Medicine':            { marketCapBillions: 200, cagrPercent: 5.0 },
  'Nephrology':                   { marketCapBillions: 90,  cagrPercent: 5.0 },
  'Neurology':                    { marketCapBillions: 35,  cagrPercent: 8.5 },
  'Obstetrics and Gynecology':    { marketCapBillions: 65,  cagrPercent: 5.0 },
  'Oncology/Cancer':              { marketCapBillions: 150, cagrPercent: 11.0 },
  'Orthopaedic Surgery':          { marketCapBillions: 90,  cagrPercent: 6.0 },
  'Otolaryngology':               { marketCapBillions: 22,  cagrPercent: 6.5 },
  'Pathology':                    { marketCapBillions: 35,  cagrPercent: 6.0 },
  'Pediatrics':                   { marketCapBillions: 120, cagrPercent: 5.0 },
  'Pharmacy':                     { marketCapBillions: 350, cagrPercent: 7.0 },
  'Plastic Surgery':              { marketCapBillions: 18,  cagrPercent: 8.0 },
  'Preventive Medicine':          { marketCapBillions: 55,  cagrPercent: 6.0 },
  'Psychiatry':                   { marketCapBillions: 90,  cagrPercent: 6.0 },
  'Psychology/Behavioral':        { marketCapBillions: 70,  cagrPercent: 6.0 },
  'Pulmonology':                  { marketCapBillions: 28,  cagrPercent: 8.0 },
  'Radiology':                    { marketCapBillions: 140, cagrPercent: 7.0 },
  'Urology':                      { marketCapBillions: 77,  cagrPercent: 6.0 },
  'Vascular Surgery':             { marketCapBillions: 22,  cagrPercent: 6.0 },
  'Vision':                       { marketCapBillions: 55,  cagrPercent: 6.0 },
};

/** Static journal name → specialty from the curated Journal_List_Classified.xlsx (2,300+ journals). */
const JOURNAL_SPECIALTY_MAP = journalSpecialtyMap as Record<string, string>;

/** Normalized lookup index built once at module load. */
const NORMALIZED_SPECIALTY_INDEX: Map<string, string> = (() => {
  const idx = new Map<string, string>();
  for (const [name, val] of Object.entries(JOURNAL_SPECIALTY_MAP)) {
    const k = normalizeJournalKey(name);
    if (k) idx.set(k, val);
  }
  return idx;
})();

/**
 * Map a journal name to a medical specialty.
 * Priority: 1) static curated map, 2) keyword matching, 3) OpenAlex concepts.
 */
export function mapJournalToSpecialty(
  journalName: string,
  concepts: string[] = [],
): MedicalSpecialty | null {
  // 1. Static curated lookup (case-insensitive + normalized)
  const staticMatch = lookupJournalSpecialty(journalName);
  if (staticMatch) return staticMatch as MedicalSpecialty;

  // 2. Keyword matching against journal name + concepts
  const searchText = [journalName, ...concepts].join(' ').toLowerCase();
  let bestMatch: MedicalSpecialty | null = null;
  let bestCount = 0;

  for (const [keywords, specialty] of SPECIALTY_KEYWORDS) {
    const matchCount = keywords.filter(kw => searchText.includes(kw)).length;
    if (matchCount > bestCount) {
      bestCount = matchCount;
      bestMatch = specialty;
    }
  }

  return bestMatch ?? 'Internal Medicine';
}

/**
 * Look up a journal name in the static curated map.
 * Tries exact match → normalized key match.
 */
export function lookupJournalSpecialty(journalName: string): string | null {
  if (!journalName) return null;
  if (JOURNAL_SPECIALTY_MAP[journalName]) return JOURNAL_SPECIALTY_MAP[journalName];
  const norm = normalizeJournalKey(journalName);
  if (norm && NORMALIZED_SPECIALTY_INDEX.has(norm)) {
    return NORMALIZED_SPECIALTY_INDEX.get(norm) ?? null;
  }
  return null;
}

/**
 * Get market data for a specialty.
 */
export function getMarketData(specialty: MedicalSpecialty | string): MarketData | null {
  return (MARKET_DATA as Record<string, MarketData>)[specialty] ?? null;
}

/**
 * Get all available specialties with market data.
 */
export function getAllSpecialties(): MedicalSpecialty[] {
  return Object.keys(MARKET_DATA) as MedicalSpecialty[];
}

/**
 * Keyword fallback for journals not in the curated list.
 */
const SPECIALTY_KEYWORDS: Array<[string[], MedicalSpecialty]> = [
  [['cancer', 'oncol', 'tumor', 'neoplasm', 'carcinoma', 'leukemia', 'lymphoma', 'melanoma', 'sarcoma'], 'Oncology/Cancer'],
  [['cardio', 'heart', 'vascular', 'atheroscler', 'coronary', 'arrhythm', 'hypertens'], 'Cardiology'],
  [['neuro', 'brain', 'alzheimer', 'parkinson', 'epilep', 'stroke', 'cerebr', 'dementia'], 'Neurology'],
  [['immuno', 'allerg', 'autoimmun', 'cytokine', 'antibod'], 'Allergy and Immunology'],
  [['infect', 'virol', 'bacteriol', 'antimicrob', 'parasit', 'hiv', 'hepatitis', 'tuberculosis', 'malaria'], 'Infectious Disease'],
  [['endocrin', 'diabet', 'thyroid', 'insulin', 'metabol', 'obesity', 'hormone'], 'Endocrinology'],
  [['pulmon', 'respirat', 'lung', 'asthma', 'copd', 'bronch', 'thorac'], 'Pulmonology'],
  [['gastro', 'hepat', 'digest', 'intestin', 'colon', 'liver', 'pancrea'], 'Gastroenterology'],
  [['nephro', 'kidney', 'renal', 'dialys', 'uremia'], 'Nephrology'],
  [['dermat', 'skin', 'cutane', 'psoria', 'eczema'], 'Dermatology'],
  [['ophthal', 'eye', 'vision', 'retina', 'glaucoma', 'ocular'], 'Vision'],
  [['psychia', 'mental health', 'schizophren', 'bipolar'], 'Psychiatry'],
  [['rheuma', 'arthrit', 'lupus', 'fibromyalg', 'gout'], 'Rheumatology'],
  [['hematol', 'blood', 'thromb', 'coagul', 'anemia', 'platelet', 'hemophilia'], 'Hematology'],
  [['urolog', 'bladder', 'prostat', 'urinar'], 'Urology'],
  [['orthop', 'bone', 'musculoskel', 'fracture', 'joint', 'spine', 'osteopor'], 'Orthopaedic Surgery'],
  [['pediatr', 'child', 'neonat', 'infant', 'adolesc'], 'Pediatrics'],
  [['obstet', 'gynecol', 'pregnan', 'maternal', 'fetal', 'reproduct'], 'Obstetrics and Gynecology'],
  [['radiol', 'imaging', 'mri', 'ct scan', 'ultrasound', 'x-ray', 'tomograph'], 'Radiology'],
  [['surg', 'operative', 'transplant', 'anesthes'], 'General Surgery'],
  [['general pract', 'family med', 'primary care', 'internal med'], 'Internal Medicine'],
  [['epidemiol', 'public health', 'global health', 'preventive', 'population'], 'Preventive Medicine'],
  [['genet', 'genom', 'dna', 'chromosom', 'heredit', 'gene therap'], 'Genetics and Genomics'],
  [['pathol', 'histolog', 'cytolog', 'biopsy', 'forensic'], 'Pathology'],
  [['pharm', 'drug', 'medicin'], 'Pharmacy'],
  [['geriatr', 'aging', 'elder', 'gerontol'], 'Geriatrics'],
  [['emergency', 'trauma', 'acute care'], 'Emergency Medicine'],
  [['psychol', 'behavio', 'cognit', 'counsel'], 'Psychology/Behavioral'],
  [['nurs', 'midwi'], 'Nursing'],
  [['otolaryngol', 'ear nose', 'ent', 'hearing', 'audiol'], 'Otolaryngology'],
];
