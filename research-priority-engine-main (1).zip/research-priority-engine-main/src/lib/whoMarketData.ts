import marketData from "@/lib/who-market-data.json";

export interface WHOMarketData {
  globalFundingUSD_M: number | null;
  marketSizeUSD_B: number | null;
  cagrPercent: number | null;
  whoReportCategory: string | null;
  notes: string;
}

/**
 * Look up WHO/HRCS market data for a given HRCS category.
 * Returns null if the category is unrecognised.
 */
export function getWHOMarketData(hrcsCategory: string): WHOMarketData | null {
  return (marketData as Record<string, WHOMarketData>)[hrcsCategory] ?? null;
}

/**
 * Convenience: given a journal cache entry's hrcsCategory, return
 * whether it qualifies as a "niche" market by the admin config thresholds.
 */
export function isNicheMarket(
  hrcsCategory: string,
  marketCapThresholdB: number,
  cagrThreshold: number
): boolean {
  const data = getWHOMarketData(hrcsCategory);
  if (!data || data.marketSizeUSD_B === null || data.cagrPercent === null) return false;
  return data.marketSizeUSD_B < marketCapThresholdB && data.cagrPercent > cagrThreshold;
}
