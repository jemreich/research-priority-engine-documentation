import { useState, useEffect } from "react";
import { useAppStore } from "@/store/AppContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Save,
  Settings,
  Clock,
  FlaskConical,
  DollarSign,
  Key,
  Eye,
  EyeOff,
  Trash2,
  CheckCircle,
  Timer,
  AlertCircle,
  Download,
} from "lucide-react";
import { toast } from "sonner";
import { getNcbiApiKey, setNcbiApiKey, clearNcbiApiKey } from "@/lib/apiKeys";
import type {
  AdminConfig,
  NicheNumericCriterion,
  NicheNumericMetric,
  NicheOperator,
  SJRQuartile,
} from "@/types";

const METRIC_LABELS: Record<NicheNumericMetric, string> = {
  sjr: "SJR Score",
  sjrHIndex: "SJR H-Index",
  totalDocs3yr: "Total Docs (3yr)",
  citPerDoc2yr: "Citations / Doc (2yr)",
};

const METRIC_HELP: Record<NicheNumericMetric, string> = {
  sjr: "SCImago Journal Rank — higher = more prestigious",
  sjrHIndex: "Journal-level h-index — higher = more established",
  totalDocs3yr: "Number of articles published in last 3 years — lower = more selective/niche",
  citPerDoc2yr: "Average citations per document over 2 years",
};

const QUARTILES: SJRQuartile[] = ["Q1", "Q2", "Q3", "Q4"];

const DEFAULT_NICHE: Pick<
  AdminConfig,
  "nicheQuartileCriterion" | "nicheNumericCriteria" | "nicheInterpolationMetric"
> = {
  nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1", "Q2"] },
  nicheNumericCriteria: [
    { metric: "totalDocs3yr", enabled: true, operator: "lte", threshold: 300 },
    { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
    { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
    { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
  ],
  nicheInterpolationMetric: "totalDocs3yr",
};

export default function AdminConfigPage() {
  const { state, dispatch } = useAppStore();
  const [config, setConfig] = useState<AdminConfig>(state.adminConfig);
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [hasApiKey, setHasApiKey] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    const existing = getNcbiApiKey();
    setHasApiKey(!!existing);
    if (existing) setApiKeyInput(existing);
  }, []);

  const handleSave = () => {
    dispatch({ type: "UPDATE_ADMIN_CONFIG", payload: config });
    toast.success("Admin configuration saved");
  };

  const handleReset = () => {
    const defaults: AdminConfig = {
      nicheBonusEnabled: true,
      nicheBonusMultiplierMin: 1.1,
      nicheBonusMultiplierMax: 1.3,
      nicheBonusMarketCapThreshold: 50,
      nicheBonusCAGRThreshold: 7,
      ...DEFAULT_NICHE,
      proxyEnabled: true,
      proxyConfidenceDiscount: 0.85,
      insufficientDataDiscount: 0.5,
      enrichmentCycleDays: 14,
      lastEnrichmentRun: state.adminConfig.lastEnrichmentRun,
      effortAnchorHours: 2,
      effortDampening: 0.5,
      effortMultiplierMin: 0.25,
      effortMultiplierMax: 3.0,
    };
    setConfig(defaults);
    dispatch({ type: "UPDATE_ADMIN_CONFIG", payload: defaults });
    toast.success("Reset to defaults");
  };

  const updateNumericCriterion = (
    metric: NicheNumericMetric,
    patch: Partial<NicheNumericCriterion>,
  ) => {
    setConfig((c) => ({
      ...c,
      nicheNumericCriteria: c.nicheNumericCriteria.map((nc) =>
        nc.metric === metric ? { ...nc, ...patch } : nc,
      ),
    }));
  };

  const toggleQuartile = (q: SJRQuartile) => {
    setConfig((c) => {
      const current = c.nicheQuartileCriterion.allowedQuartiles;
      const next = current.includes(q) ? current.filter((x) => x !== q) : [...current, q];
      return {
        ...c,
        nicheQuartileCriterion: { ...c.nicheQuartileCriterion, allowedQuartiles: next },
      };
    });
  };

  const nicheDisabled = config.nicheBonusEnabled === false;
  const interpolationOptions = config.nicheNumericCriteria.filter((c) => c.enabled);

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Admin Configuration</h2>
        <p className="text-sm text-muted-foreground">
          System-wide scoring parameters. These values are used by the ROI Scoring Engine.
        </p>
      </div>

      {/* API Keys */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            API Keys
          </CardTitle>
          <CardDescription>
            Stored locally in your browser only — never sent to any server or committed to code.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>NCBI API Key</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showApiKey ? "text" : "password"}
                  placeholder={hasApiKey ? "••••••••••••••••" : "Paste your NCBI API key here"}
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </Button>
              </div>
              <Button
                onClick={() => {
                  if (apiKeyInput.trim()) {
                    setNcbiApiKey(apiKeyInput.trim());
                    setHasApiKey(true);
                    setShowApiKey(false);
                    toast.success("NCBI API key saved securely in your browser");
                  }
                }}
                disabled={!apiKeyInput.trim()}
              >
                <Save className="h-4 w-4 mr-1" /> Save Key
              </Button>
              {hasApiKey && (
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => {
                    clearNcbiApiKey();
                    setApiKeyInput("");
                    setHasApiKey(false);
                    toast.success("NCBI API key removed");
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            {hasApiKey && (
              <div className="flex items-center gap-1 text-sm text-primary">
                <CheckCircle className="h-3.5 w-3.5" />
                API key configured — PubMed rate limit: 10 req/sec
              </div>
            )}
            {!hasApiKey && (
              <p className="text-xs text-muted-foreground">
                Without a key, PubMed rate limit is 3 req/sec. Get a free key at{" "}
                <a
                  href="https://account.ncbi.nlm.nih.gov/settings/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline text-primary"
                >
                  account.ncbi.nlm.nih.gov/settings
                </a>
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Niche Journal Bonus */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FlaskConical className="h-5 w-5" />
            Niche Journal Bonus
          </CardTitle>
          <CardDescription>
            Define what counts as a "niche" journal using SCImago metrics. All enabled criteria must
            match (AND). When matched, the Journal Prestige subscore is multiplied by the bonus.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-md border border-border p-3">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Niche Journal Bonus</Label>
              <p className="text-xs text-muted-foreground">
                When off, no niche multiplier is applied.
              </p>
            </div>
            <Switch
              checked={config.nicheBonusEnabled !== false}
              onCheckedChange={(checked) =>
                setConfig((c) => ({ ...c, nicheBonusEnabled: checked }))
              }
            />
          </div>

          <div className={nicheDisabled ? "opacity-50 pointer-events-none space-y-5" : "space-y-5"}>
            {/* Multiplier range */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Min Multiplier</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={config.nicheBonusMultiplierMin}
                  onChange={(e) =>
                    setConfig((c) => ({
                      ...c,
                      nicheBonusMultiplierMin: parseFloat(e.target.value) || 1,
                    }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Max Multiplier</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={config.nicheBonusMultiplierMax}
                  onChange={(e) =>
                    setConfig((c) => ({
                      ...c,
                      nicheBonusMultiplierMax: parseFloat(e.target.value) || 1,
                    }))
                  }
                />
              </div>
            </div>

            {/* Quartile criterion */}
            <div className="rounded-md border border-border p-3 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">SJR Quartile</Label>
                  <p className="text-xs text-muted-foreground">
                    Limit niche bonus to journals in selected quartiles.
                  </p>
                </div>
                <Switch
                  checked={config.nicheQuartileCriterion.enabled}
                  onCheckedChange={(checked) =>
                    setConfig((c) => ({
                      ...c,
                      nicheQuartileCriterion: { ...c.nicheQuartileCriterion, enabled: checked },
                    }))
                  }
                />
              </div>
              <div
                className={
                  config.nicheQuartileCriterion.enabled
                    ? "flex flex-wrap gap-3"
                    : "flex flex-wrap gap-3 opacity-50 pointer-events-none"
                }
              >
                {QUARTILES.map((q) => {
                  const checked = config.nicheQuartileCriterion.allowedQuartiles.includes(q);
                  return (
                    <label
                      key={q}
                      className="flex items-center gap-2 text-sm cursor-pointer select-none"
                    >
                      <Checkbox checked={checked} onCheckedChange={() => toggleQuartile(q)} />
                      <span>{q}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Numeric metric criteria */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Numeric Metric Criteria</Label>
              {config.nicheNumericCriteria.map((c) => (
                <div key={c.metric} className="rounded-md border border-border p-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm">{METRIC_LABELS[c.metric]}</Label>
                      <p className="text-xs text-muted-foreground">{METRIC_HELP[c.metric]}</p>
                    </div>
                    <Switch
                      checked={c.enabled}
                      onCheckedChange={(checked) =>
                        updateNumericCriterion(c.metric, { enabled: checked })
                      }
                    />
                  </div>
                  <div
                    className={
                      c.enabled
                        ? "grid grid-cols-[140px_1fr_120px] items-center gap-3"
                        : "grid grid-cols-[140px_1fr_120px] items-center gap-3 opacity-50 pointer-events-none"
                    }
                  >
                    <Select
                      value={c.operator}
                      onValueChange={(v) =>
                        updateNumericCriterion(c.metric, { operator: v as NicheOperator })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lte">≤ (at most)</SelectItem>
                        <SelectItem value="gte">≥ (at least)</SelectItem>
                      </SelectContent>
                    </Select>
                    <Slider
                      value={[c.threshold]}
                      min={0}
                      max={
                        c.metric === "totalDocs3yr"
                          ? 2000
                          : c.metric === "sjrHIndex"
                            ? 500
                            : c.metric === "sjr"
                              ? 20
                              : 50
                      }
                      step={
                        c.metric === "totalDocs3yr" || c.metric === "sjrHIndex" ? 10 : 0.1
                      }
                      onValueChange={(v) =>
                        updateNumericCriterion(c.metric, { threshold: v[0] })
                      }
                    />
                    <Input
                      type="number"
                      step={
                        c.metric === "totalDocs3yr" || c.metric === "sjrHIndex" ? 1 : 0.1
                      }
                      value={c.threshold}
                      onChange={(e) =>
                        updateNumericCriterion(c.metric, {
                          threshold: parseFloat(e.target.value) || 0,
                        })
                      }
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Interpolation driver */}
            <div className="rounded-md border border-border p-3 space-y-2">
              <Label className="text-sm font-medium">Bonus Strength Driver</Label>
              <p className="text-xs text-muted-foreground">
                Which enabled metric scales the bonus between Min and Max. Lower values of "≤"
                metrics (or higher values of "≥" metrics) yield bonuses closer to Max.
              </p>
              <Select
                value={config.nicheInterpolationMetric}
                onValueChange={(v) =>
                  setConfig((c) => ({ ...c, nicheInterpolationMetric: v as NicheNumericMetric }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(interpolationOptions.length > 0
                    ? interpolationOptions
                    : config.nicheNumericCriteria
                  ).map((opt) => (
                    <SelectItem key={opt.metric} value={opt.metric}>
                      {METRIC_LABELS[opt.metric]}
                      {!opt.enabled ? " (criterion disabled)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              <Badge variant="secondary" className="text-xs">
                Active: {[
                  config.nicheQuartileCriterion.enabled
                    ? `Quartile ∈ {${config.nicheQuartileCriterion.allowedQuartiles.join(", ")}}`
                    : null,
                  ...config.nicheNumericCriteria
                    .filter((c) => c.enabled)
                    .map(
                      (c) =>
                        `${METRIC_LABELS[c.metric]} ${c.operator === "lte" ? "≤" : "≥"} ${c.threshold}`,
                    ),
                ]
                  .filter(Boolean)
                  .join("  AND  ") || "no criteria enabled"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Proxy Scoring */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Proxy Scoring (Tier 2)
          </CardTitle>
          <CardDescription>
            When enrichment data is unavailable, REDCap proxy signals are used with a confidence
            discount
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-md border border-border p-3">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Proxy Scoring</Label>
              <p className="text-xs text-muted-foreground">
                When off, PIs without enrichment data will not receive a proxy-based score.
              </p>
            </div>
            <Switch
              checked={config.proxyEnabled !== false}
              onCheckedChange={(checked) => setConfig((c) => ({ ...c, proxyEnabled: checked }))}
            />
          </div>
          <div
            className={
              config.proxyEnabled === false ? "opacity-50 pointer-events-none space-y-4" : "space-y-4"
            }
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>T2 Proxy Confidence Discount</Label>
                <span className="text-sm font-mono text-muted-foreground">
                  {config.proxyConfidenceDiscount.toFixed(2)}
                </span>
              </div>
              <Slider
                value={[config.proxyConfidenceDiscount]}
                onValueChange={(v) => setConfig((c) => ({ ...c, proxyConfidenceDiscount: v[0] }))}
                min={0.5}
                max={1.0}
                step={0.05}
              />
              <p className="text-xs text-muted-foreground">
                T2 (partial-data) scores are multiplied by this value. Lower = less trust in proxy data.
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>T3 Insufficient-Data Discount</Label>
                <span className="text-sm font-mono text-muted-foreground">
                  {(config.insufficientDataDiscount ?? 0.5).toFixed(2)}
                </span>
              </div>
              <Slider
                value={[config.insufficientDataDiscount ?? 0.5]}
                onValueChange={(v) => setConfig((c) => ({ ...c, insufficientDataDiscount: v[0] }))}
                min={0.1}
                max={1.0}
                step={0.05}
              />
              <p className="text-xs text-muted-foreground">
                T3 (insufficient-data) scores are multiplied by this value. Typically lower than the T2 discount.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Effort Multiplier */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Timer className="h-5 w-5" />
            Effort Multiplier
          </CardTitle>
          <CardDescription>
            Scales the weighted return based on hours worked. Anchored so that the average project
            length yields a neutral 1.0× (no change). Faster projects get a bonus; slower ones a
            penalty — dampened by the exponent and clamped to the configured band.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Anchor Hours (neutral 1.0×)</Label>
              <Input
                type="number"
                step="0.5"
                min={0.25}
                value={config.effortAnchorHours ?? 2}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    effortAnchorHours: parseFloat(e.target.value) || 2,
                  }))
                }
              />
              <p className="text-xs text-muted-foreground">
                Projects taking this many hours yield multiplier 1.0×. Default: 2h.
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Dampening Exponent</Label>
                <span className="text-sm font-mono text-muted-foreground">
                  {(config.effortDampening ?? 0.5).toFixed(2)}
                </span>
              </div>
              <Slider
                value={[config.effortDampening ?? 0.5]}
                onValueChange={(v) => setConfig((c) => ({ ...c, effortDampening: v[0] }))}
                min={0}
                max={1}
                step={0.05}
              />
              <p className="text-xs text-muted-foreground">
                0 = disabled (always 1×). 0.5 = √-dampened (default). 1 = linear anchor/hours.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Min Multiplier (clamp)</Label>
              <Input
                type="number"
                step="0.05"
                min={0}
                value={config.effortMultiplierMin ?? 0.25}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    effortMultiplierMin: parseFloat(e.target.value) || 0,
                  }))
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Max Multiplier (clamp)</Label>
              <Input
                type="number"
                step="0.05"
                min={1}
                value={config.effortMultiplierMax ?? 3.0}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    effortMultiplierMax: parseFloat(e.target.value) || 1,
                  }))
                }
              />
            </div>
          </div>
          {/* Live preview */}
          <div className="rounded-md border border-border p-3 space-y-2">
            <Label className="text-sm font-medium">Live Preview</Label>
            <div className="grid grid-cols-7 gap-2 text-xs">
              {[0.5, 1, 2, 4, 8, 20, 40].map((h) => {
                const anchor = config.effortAnchorHours ?? 2;
                const exp = config.effortDampening ?? 0.5;
                const minM = config.effortMultiplierMin ?? 0.25;
                const maxM = config.effortMultiplierMax ?? 3.0;
                const raw = Math.pow(anchor / h, exp);
                const m = Math.min(maxM, Math.max(minM, raw));
                const isAnchor = h === anchor;
                return (
                  <div
                    key={h}
                    className={
                      isAnchor
                        ? "text-center p-2 rounded bg-primary/10 border border-primary/30"
                        : "text-center p-2 rounded bg-muted"
                    }
                  >
                    <p className="text-muted-foreground">{h}h</p>
                    <p className="font-mono font-semibold text-foreground">{m.toFixed(2)}×</p>
                  </div>
                );
              })}
            </div>
            <p className="text-xs text-muted-foreground">
              Bold cell = anchor hours (always 1.00×). Values outside [Min, Max] are clamped.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Enrichment Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Enrichment Schedule
          </CardTitle>
          <CardDescription>How often the PI enrichment cache is refreshed from public APIs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Enrichment Cycle (days)</Label>
            <Input
              type="number"
              min={1}
              max={90}
              value={config.enrichmentCycleDays}
              onChange={(e) =>
                setConfig((c) => ({ ...c, enrichmentCycleDays: parseInt(e.target.value) || 14 }))
              }
            />
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Last enrichment run:</span>
            {state.adminConfig.lastEnrichmentRun ? (
              <Badge variant="outline">
                {new Date(state.adminConfig.lastEnrichmentRun).toLocaleString()}
              </Badge>
            ) : (
              <Badge variant="secondary">Never</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Unresolved Journals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Unresolved Journals
          </CardTitle>
          <CardDescription>
            PubMed abbreviations that the resolution cascade (CrossRef → NLM Catalog → OpenAlex)
            could not expand into a full title. Helpful for spotting matching gaps.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {state.unresolvedJournals.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No unresolved journals — every abbreviation matched at least one tier.
            </p>
          ) : (
            <>
              <div className="max-h-64 overflow-y-auto rounded-md border border-border">
                <table className="w-full text-xs">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="text-left p-2 font-medium">Abbreviation</th>
                      <th className="text-right p-2 font-medium w-20">Attempts</th>
                      <th className="text-right p-2 font-medium w-44">Last Tried</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.unresolvedJournals.map((u) => (
                      <tr key={u.abbreviation} className="border-t border-border">
                        <td className="p-2 font-mono text-foreground">{u.abbreviation}</td>
                        <td className="p-2 text-right text-muted-foreground">{u.attempts}</td>
                        <td className="p-2 text-right text-muted-foreground">
                          {new Date(u.lastTriedAt).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const header = "abbreviation,attempts,lastTriedAt\n";
                    const rows = state.unresolvedJournals
                      .map(
                        (u) =>
                          `${JSON.stringify(u.abbreviation)},${u.attempts},${u.lastTriedAt}`,
                      )
                      .join("\n");
                    const blob = new Blob([header + rows], { type: "text/csv" });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `unresolved-journals-${new Date().toISOString().slice(0, 10)}.csv`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                >
                  <Download className="h-4 w-4 mr-1" /> Download CSV
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    dispatch({ type: "CLEAR_UNRESOLVED_JOURNALS" });
                    toast.success("Cleared unresolved journals list");
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-1" /> Clear list
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-2">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-1" /> Save Configuration
        </Button>
        <Button variant="outline" onClick={handleReset}>
          <Settings className="h-4 w-4 mr-1" /> Reset Defaults
        </Button>
      </div>
    </div>
  );
}

{
  /*
import { useState, useEffect } from "react";
import { useAppStore } from "@/store/AppContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Save, Settings, Clock, FlaskConical, DollarSign, Key, Eye, EyeOff, Trash2, CheckCircle } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { getNcbiApiKey, setNcbiApiKey, clearNcbiApiKey } from "@/lib/apiKeys";

export default function AdminConfigPage() {
  const { state, dispatch } = useAppStore();
  const [config, setConfig] = useState(state.adminConfig);
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [hasApiKey, setHasApiKey] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    const existing = getNcbiApiKey();
    setHasApiKey(!!existing);
    if (existing) setApiKeyInput(existing);
  }, []);

  const handleSave = () => {
    dispatch({ type: "UPDATE_ADMIN_CONFIG", payload: config });
    toast.success("Admin configuration saved");
  };

  const handleReset = () => {
    const defaults = {
      nicheBonusEnabled: true,
      nicheBonusMultiplierMin: 1.1,
      nicheBonusMultiplierMax: 1.15,
      nicheBonusMarketCapThreshold: 50,
      nicheBonusCAGRThreshold: 7,
      proxyConfidenceDiscount: 0.85,
      insufficientDataDiscount: 0.5,
      enrichmentCycleDays: 14,
      lastEnrichmentRun: state.adminConfig.lastEnrichmentRun,
    };
    setConfig(defaults);
    dispatch({ type: "UPDATE_ADMIN_CONFIG", payload: defaults });
    toast.success("Reset to defaults");
  };

  return (
    <div className="p-6 space-y-6 max-w-2xl">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Admin Configuration</h2>
        <p className="text-sm text-muted-foreground">
          System-wide scoring parameters. These values are used by the ROI Scoring Engine.
        </p>
      </div>
*/
}
{
  /* API Keys */
}
{
  /*
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            API Keys
          </CardTitle>
          <CardDescription>
            Stored locally in your browser only — never sent to any server or committed to code.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>NCBI API Key</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showApiKey ? "text" : "password"}
                  placeholder={hasApiKey ? "••••••••••••••••" : "Paste your NCBI API key here"}
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </Button>
              </div>
              <Button
                onClick={() => {
                  if (apiKeyInput.trim()) {
                    setNcbiApiKey(apiKeyInput.trim());
                    setHasApiKey(true);
                    setShowApiKey(false);
                    toast.success("NCBI API key saved securely in your browser");
                  }
                }}
                disabled={!apiKeyInput.trim()}
              >
                <Save className="h-4 w-4 mr-1" /> Save Key
              </Button>
              {hasApiKey && (
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => {
                    clearNcbiApiKey();
                    setApiKeyInput("");
                    setHasApiKey(false);
                    toast.success("NCBI API key removed");
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            {hasApiKey && (
              <div className="flex items-center gap-1 text-sm text-primary">
                <CheckCircle className="h-3.5 w-3.5" />
                API key configured — PubMed rate limit: 10 req/sec
              </div>
            )}
            {!hasApiKey && (
              <p className="text-xs text-muted-foreground">
                Without a key, PubMed rate limit is 3 req/sec. Get a free key at{" "}
                <a
                  href="https://account.ncbi.nlm.nih.gov/settings/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline text-primary"
                >
                  account.ncbi.nlm.nih.gov/settings
                </a>
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FlaskConical className="h-5 w-5" />
            Niche Journal Bonus
          </CardTitle>
          <CardDescription>Multiplier applied to Journal Prestige subscore for niche specialties</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-md border border-border p-3">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Niche Journal Bonus</Label>
              <p className="text-xs text-muted-foreground">
                When off, no niche multiplier is applied to Journal Prestige.
              </p>
            </div>
            <Switch
              checked={config.nicheBonusEnabled !== false}
              onCheckedChange={(checked) => setConfig((c) => ({ ...c, nicheBonusEnabled: checked }))}
            />
          </div>
          <div
            className={config.nicheBonusEnabled === false ? "opacity-50 pointer-events-none space-y-4" : "space-y-4"}
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Min Multiplier</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={config.nicheBonusMultiplierMin}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, nicheBonusMultiplierMin: parseFloat(e.target.value) || 1 }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Max Multiplier</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={config.nicheBonusMultiplierMax}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, nicheBonusMultiplierMax: parseFloat(e.target.value) || 1 }))
                  }
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Market Cap Threshold ($B)</Label>
                <Input
                  type="number"
                  value={config.nicheBonusMarketCapThreshold}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, nicheBonusMarketCapThreshold: parseFloat(e.target.value) || 0 }))
                  }
                />
                <p className="text-xs text-muted-foreground">Specialty market must be below this value</p>
              </div>
              <div className="space-y-2">
                <Label>CAGR Threshold (%)</Label>
                <Input
                  type="number"
                  value={config.nicheBonusCAGRThreshold}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, nicheBonusCAGRThreshold: parseFloat(e.target.value) || 0 }))
                  }
                />
                <p className="text-xs text-muted-foreground">Specialty CAGR must exceed this value</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
*/
}
{
  /* Proxy Scoring */
}
{
  /*
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Proxy Scoring (Tier 2)
          </CardTitle>
          <CardDescription>
            When enrichment data is unavailable, REDCap proxy signals are used with a confidence discount
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Proxy Confidence Discount</Label>
              <span className="text-sm font-mono text-muted-foreground">
                {config.proxyConfidenceDiscount.toFixed(2)}
              </span>
            </div>
            <Slider
              value={[config.proxyConfidenceDiscount]}
              onValueChange={(v) => setConfig((c) => ({ ...c, proxyConfidenceDiscount: v[0] }))}
              min={0.5}
              max={1.0}
              step={0.05}
            />
            <p className="text-xs text-muted-foreground">
              Proxy subscores are multiplied by this value. Lower = less trust in proxy data.
            </p>
          </div>
        </CardContent>
      </Card>
*/
}
{
  /* Enrichment Schedule */
}
{
  /*
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Enrichment Schedule
          </CardTitle>
          <CardDescription>How often the PI enrichment cache is refreshed from public APIs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Enrichment Cycle (days)</Label>
            <Input
              type="number"
              min={1}
              max={90}
              value={config.enrichmentCycleDays}
              onChange={(e) => setConfig((c) => ({ ...c, enrichmentCycleDays: parseInt(e.target.value) || 14 }))}
            />
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Last enrichment run:</span>
            {state.adminConfig.lastEnrichmentRun ? (
              <Badge variant="outline">{new Date(state.adminConfig.lastEnrichmentRun).toLocaleString()}</Badge>
            ) : (
              <Badge variant="secondary">Never</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Actions */
}
{
  /*
      <div className="flex gap-2">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-1" /> Save Configuration
        </Button>
        <Button variant="outline" onClick={handleReset}>
          <Settings className="h-4 w-4 mr-1" /> Reset Defaults
        </Button>
      </div>
    </div>
  );
}
*/
}
