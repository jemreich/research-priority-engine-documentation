import { useAppStore } from '@/store/AppContext';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ClipboardList, BookOpen } from 'lucide-react';

interface DictionaryEntry {
  term: string;
  definition: string;
}

interface DictionarySection {
  heading: string;
  entries: DictionaryEntry[];
}

const DATA_DICTIONARY: DictionarySection[] = [
  {
    heading: 'Dashboard Columns',
    entries: [
      { term: '#', definition: 'Row index in the current sorted view.' },
      { term: 'ROI', definition: 'Effort-Adjusted ROI score: weighted return × effort multiplier, after tier discount.' },
      { term: 'Return', definition: 'Weighted Return: sum of S1–S4 sub-scores (0–100), pre-effort.' },
      { term: 'Status', definition: 'Open or Closed, based on whether the request has a completion date.' },
      { term: 'Requested', definition: 'Date the REDCap request was submitted (dateOfRequest).' },
      { term: 'Pubs', definition: 'Count of PubMed publications linked to this request.' },
      { term: 'Type', definition: 'Request type from REDCap (e.g., Identified Data, De-identified Data).' },
      { term: 'Department', definition: "Requesting PI's department." },
      { term: 'Rank', definition: 'PI faculty rank: Professor, Associate, Assistant, Instructor, or Other.' },
      { term: 'PI', definition: 'Principal Investigator name.' },
      { term: 'Project Title', definition: 'Free-text project title from REDCap.' },
      { term: 'Funding', definition: 'Funding source category (NIH, Foundation, Internal, Industry, etc.).' },
      { term: 'Tier', definition: 'Data confidence tier: T1 = full enrichment, T2 = partial (proxy used), T3 = insufficient data.' },
    ],
  },
  {
    heading: 'PI Profile Columns',
    entries: [
      { term: 'PI Name', definition: 'Researcher name (normalized; merged aliases shown as "aka").' },
      { term: 'Faculty Rank', definition: "Highest faculty rank seen across this PI's requests." },
      { term: 'Requests', definition: 'Total number of REDCap requests submitted by this PI.' },
      { term: 'Funding', definition: 'Total NIH RePORTER funding aggregated across all grants, in millions USD.' },
      { term: 'Grants', definition: 'Total distinct grants on file from NIH RePORTER (deduped by core project number).' },
      { term: 'Active', definition: 'Number of currently active (non-expired) NIH grants.' },
      { term: 'Pubs', definition: "Total publications linked across all of this PI's requests." },
      { term: 'Avg RCR', definition: "Mean Relative Citation Ratio across this PI's publications." },
      { term: 'Median Authors', definition: 'Median number of authors per publication for this PI (from PubMed AuthorList). Median is used so a single mega-collaboration paper does not skew the metric.' },
      { term: 'Dept', definition: 'Department associated with this PI in REDCap.' },
    ],
  },
  {
    heading: 'Scoring Components & Tiers',
    entries: [
      { term: 'S1 — Publication Impact', definition: 'Weighted blend of RCR, NIH Percentile, and Citation Count.' },
      { term: 'S2 — Researcher Track Record', definition: 'h-index, total publications, total citations, and faculty rank.' },
      { term: 'S3 — Journal Prestige', definition: 'SJR Quartile, SJR, h5-index, and Cit/Doc 2yr.' },
      { term: 'S4 — Funding Activity', definition: 'Funding source, active grants, and total funding.' },
      { term: 'Effort Multiplier', definition: 'clamp((anchorHours ÷ tracHours) ^ dampening, [min, max]). Lower hours → higher multiplier.' },
      { term: 'Tier 1 (T1)', definition: 'Fully enriched (publications + journal + PI metrics) — no discount applied.' },
      { term: 'Tier 2 (T2)', definition: 'Partial data; proxy estimates used. Proxy discount applied if enabled in Admin Config.' },
      { term: 'Tier 3 (T3)', definition: 'Insufficient data. Insufficient-data discount applied if enabled in Admin Config.' },
      { term: 'Niche Bonus', definition: 'Optional multiplier for low-saturation journals matching SCImago criteria (quartile + numeric thresholds).' },
    ],
  },
  {
    heading: 'Reference Metrics',
    entries: [
      { term: 'RCR', definition: 'Relative Citation Ratio (NIH iCite): field- and time-normalized citation impact. 1.0 = NIH-funded average.' },
      { term: 'NIH Percentile', definition: 'Percentile rank of citation rate among NIH-funded papers in the same field/year.' },
      { term: 'Citation Count', definition: 'Total citations for the publication (from NIH iCite).' },
      { term: 'Authors', definition: 'Number of authors on a publication (parsed from PubMed AuthorList).' },
      { term: 'h-index', definition: "Researcher's h-index — number of publications cited at least h times each." },
      { term: 'h5-index', definition: 'Google Scholar 5-year h-index for the journal: articles in past 5 yrs each cited ≥ h5 times.' },
      { term: 'h5-median', definition: 'Median citation count of the h5 articles — typical impact within that core set.' },
      { term: 'SJR', definition: 'SCImago Journal Rank: prestige-weighted citations per document over the past 3 years.' },
      { term: 'SJR Quartile', definition: "Q1 (top 25%) – Q4 ranking within the journal's SCImago subject category." },
      { term: 'Cit/Doc 2yr', definition: 'Average citations per document over the past 2 years (SCImago).' },
      { term: 'Total Docs (3yr)', definition: 'Articles published by the journal over the past 3 years (SCImago).' },
    ],
  },
];

export default function AuditLogPage() {
  const { state } = useAppStore();

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Audit Log</h2>
        <p className="text-sm text-muted-foreground">Complete history of manual overrides and scoring actions.</p>
      </div>

      {/* Data Dictionary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <BookOpen className="h-5 w-5" />
            Data Dictionary
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Definitions for every column and metric shown across the Dashboard and PI Profiles tables.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {DATA_DICTIONARY.map(section => (
            <div key={section.heading} className="space-y-3">
              <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide border-b border-border pb-1.5">
                {section.heading}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {section.entries.map(entry => (
                  <div
                    key={`${section.heading}-${entry.term}`}
                    className="border border-border rounded-md bg-muted/30 overflow-hidden flex flex-col"
                  >
                    <div className="bg-muted px-3 py-2 border-b border-border">
                      <div className="font-semibold text-sm text-foreground">{entry.term}</div>
                    </div>
                    <div className="px-3 py-2 flex-1">
                      <p className="text-xs italic text-muted-foreground leading-relaxed">{entry.definition}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Override Log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardList className="h-5 w-5" />
            Manual Overrides ({state.overrides.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {state.overrides.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No overrides recorded yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Request ID</TableHead>
                  <TableHead>PI</TableHead>
                  <TableHead>Previous Rank</TableHead>
                  <TableHead>New Rank</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>User</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {state.overrides.map(o => (
                  <TableRow key={o.id}>
                    <TableCell className="text-xs">{new Date(o.timestamp).toLocaleString()}</TableCell>
                    <TableCell className="font-mono">{o.recordId}</TableCell>
                    <TableCell>{o.piName}</TableCell>
                    <TableCell>{o.previousRank ?? '—'}</TableCell>
                    <TableCell>
                      <Badge>{o.newRank}</Badge>
                    </TableCell>
                    <TableCell className="max-w-xs truncate" title={o.reason}>{o.reason}</TableCell>
                    <TableCell>{o.user}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Upload History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Upload History ({state.uploadLogs.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {state.uploadLogs.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No uploads yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Filename</TableHead>
                  <TableHead>Records</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {state.uploadLogs.map(log => (
                  <TableRow key={log.id}>
                    <TableCell className="text-xs">{new Date(log.timestamp).toLocaleString()}</TableCell>
                    <TableCell><Badge variant="outline">{log.type}</Badge></TableCell>
                    <TableCell>{log.filename}</TableCell>
                    <TableCell>{log.recordCount}</TableCell>
                    <TableCell>
                      <Badge variant={log.status === 'success' ? 'default' : 'secondary'}>{log.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
