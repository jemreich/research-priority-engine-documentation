import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { CalendarIcon, X, Filter } from 'lucide-react';
import { useAppStore } from '@/store/AppContext';
import { exportToExcel } from '@/lib/parseExcel';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Download, Database, FileSpreadsheet, BarChart3 } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as XLSX from 'xlsx';
import type { RedcapRequest, RequestScore, PIEnrichmentCache, JournalEnrichment, RequestPublication, OverrideLog } from '@/types';

function buildRankedSheet(
  requests: RedcapRequest[],
  scores: RequestScore[],
  overrides: OverrideLog[],
  publications: RequestPublication[],
  piCache: PIEnrichmentCache[],
  journalCache: JournalEnrichment[],
) {
  const open = requests.filter(r => !r.dateCompleted);
  const sorted = [...open].sort((a, b) => {
    const sa = scores.find(s => s.recordId === a.recordId);
    const sb = scores.find(s => s.recordId === b.recordId);
    return (sb?.effortAdjustedROIScore ?? -1) - (sa?.effortAdjustedROIScore ?? -1);
  });

  return sorted.map((r, idx) => {
    const score = scores.find(s => s.recordId === r.recordId);
    const override = overrides.find(o => o.recordId === r.recordId);
    const pi = piCache.find(p => p.piName === r.pi);
    const pubs = publications.filter(p => p.recordId === r.recordId);
    const topJournal = pubs.length > 0 ? journalCache.find(j => j.originalName === pubs[0].journal || j.journalName === pubs[0].journal) : null;

    return {
      'Rank': override?.newRank ?? score?.rank ?? idx + 1,
      'PI Name': r.pi,
      'Department': r.department,
      'Faculty Rank': r.facultyRank,
      'Study Title': r.projectTitle,
      'Request Type': r.requestType,
      'Funding Source': r.fundingSource || '—',
      'Date of Request': r.dateOfRequest,
      'Effort-Adjusted ROI': score?.effortAdjustedROIScore?.toFixed(1) ?? 'Pending',
      'Weighted Return': score?.weightedReturnScore?.toFixed(1) ?? 'Pending',
      'Publication Impact (S1)': score?.publicationImpactScore?.toFixed(1) ?? '—',
      'Journal Prestige (S2)': score?.journalPrestigeScore?.toFixed(1) ?? '—',
      'Funding Activity (S3)': score?.fundingActivityScore?.toFixed(1) ?? '—',
      'Research Output (S4)': score?.researchOutputScore?.toFixed(1) ?? '—',
      'Effort Multiplier': score?.effortMultiplier?.toFixed(2) ?? '—',
      'Scoring Tier': score?.scoringTier ? `T${score.scoringTier}` : '—',
      'h-Index': pi?.hIndex ?? '—',
      'Total Citations': pi?.totalCitations ?? '—',
      'Active Grants': pi?.activeGrants ?? '—',
      'Total Grant Funding': pi?.totalGrantFunding ? `$${pi.totalGrantFunding.toLocaleString()}` : '—',
      'Publications Found': pubs.length,
      'Top Journal': topJournal?.journalName ?? pubs[0]?.journal ?? '—',
      'Specialty': topJournal?.specialty ?? '—',
      'Override Applied': override ? 'Yes' : 'No',
      'Override Reason': override?.reason ?? '',
    };
  });
}

function buildPISheet(piCache: PIEnrichmentCache[]) {
  return piCache.map(pi => ({
    'PI Name': pi.piName,
    'Status': pi.status,
    'h-Index': pi.hIndex ?? '—',
    'Total Citations': pi.totalCitations ?? '—',
    'Total Publications': pi.totalPublications ?? '—',
    'Grant Count': pi.grantCount ?? '—',
    'Active Grants': pi.activeGrants ?? '—',
    'Total Grant Funding': pi.totalGrantFunding ? `$${pi.totalGrantFunding.toLocaleString()}` : '—',
    'NIH Projects Found': pi.nihReporterData?.totalProjectsFound ?? '—',
    'Enriched At': pi.enrichedAt ?? 'Pending',
  }));
}

function buildJournalSheet(journalCache: JournalEnrichment[]) {
  return journalCache.map(j => ({
    'Journal Name': j.journalName,
    'Original Name': j.originalName ?? '',
    'Specialty': j.specialty ?? '—',
    'Market Cap ($B)': j.marketCapBillions ?? '—',
    'Market CAGR (%)': j.marketCAGR ?? '—',
    'h5-Index': j.h5Index ?? 'Pending',
    'h5-Median': j.h5Median ?? 'Pending',
    'SJR': j.sjr ?? 'Pending',
    'SJR Quartile': j.sjrQuartile ?? 'Pending',
    'SJR H-index': j.sjrHIndex ?? 'Pending',
    'Docs (3yr)': j.totalDocs3yr ?? 'Pending',
    'Cit/Doc (2yr)': j.citPerDoc2yr ?? 'Pending',
    'Enriched At': j.enrichedAt,
  }));
}

function buildPublicationsSheet(publications: RequestPublication[]) {
  return publications.map(p => ({
    'Record ID': p.recordId,
    'PMID': p.pmid,
    'Title': p.title,
    'Journal': p.journal,
    'DOI': p.doi,
    'Year': p.yearPublished ?? '—',
    'RCR': p.relativeCitationRatio?.toFixed(2) ?? '—',
    'Citation Count': p.citationCount ?? '—',
    'APT': p.apt?.toFixed(2) ?? '—',
    'NIH Percentile': p.nihPercentile?.toFixed(1) ?? '—',
    'Citations/Year': p.citationsPerYear?.toFixed(1) ?? '—',
    'Is Clinical': p.isClinical === null ? '—' : p.isClinical ? 'Yes' : 'No',
    'Grants': p.grants,
    'iCite Enriched': p.iciteEnrichedAt ?? 'No',
  }));
}

function buildAuditSheet(overrides: OverrideLog[]) {
  return overrides.map(o => ({
    'Record ID': o.recordId,
    'PI Name': o.piName,
    'Previous Rank': o.previousRank ?? '—',
    'New Rank': o.newRank,
    'Reason': o.reason,
    'User': o.user,
    'Timestamp': o.timestamp,
  }));
}

function autoFitColumns(ws: XLSX.WorkSheet, data: Record<string, unknown>[]) {
  if (data.length === 0) return;
  const keys = Object.keys(data[0]);
  ws['!cols'] = keys.map(key => {
    const maxLen = Math.max(
      key.length,
      ...data.map(row => String(row[key] ?? '').length)
    );
    return { wch: Math.min(maxLen + 2, 50) };
  });
}

function filterByDateRange(requests: RedcapRequest[], from?: Date, to?: Date): RedcapRequest[] {
  if (!from && !to) return requests;
  return requests.filter(r => {
    if (!r.dateOfRequest) return false;
    const d = new Date(r.dateOfRequest);
    if (isNaN(d.getTime())) return false;
    if (from && d < from) return false;
    if (to) {
      const endOfDay = new Date(to);
      endOfDay.setHours(23, 59, 59, 999);
      if (d > endOfDay) return false;
    }
    return true;
  });
}

export default function ExportPage() {
  const { state } = useAppStore();
  const [fromDate, setFromDate] = useState<Date | undefined>();
  const [toDate, setToDate] = useState<Date | undefined>();
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'closed'>('all');

  const filteredRequests = useMemo(() => {
    let reqs = filterByDateRange(state.requests, fromDate, toDate);
    if (statusFilter === 'open') reqs = reqs.filter(r => !r.dateCompleted);
    if (statusFilter === 'closed') reqs = reqs.filter(r => !!r.dateCompleted);
    return reqs;
  }, [state.requests, fromDate, toDate, statusFilter]);

  const filteredRecordIds = useMemo(() => new Set(filteredRequests.map(r => r.recordId)), [filteredRequests]);
  const filteredScores = useMemo(() => state.scores.filter(s => filteredRecordIds.has(s.recordId)), [state.scores, filteredRecordIds]);
  const filteredPubs = useMemo(() => state.publications.filter(p => filteredRecordIds.has(p.recordId)), [state.publications, filteredRecordIds]);
  const filteredOverrides = useMemo(() => state.overrides.filter(o => filteredRecordIds.has(o.recordId)), [state.overrides, filteredRecordIds]);

  const handleExportAll = () => {
    exportToExcel(filteredRequests, `research_requests_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportOpenRequests = () => {
    const data = buildRankedSheet(filteredRequests, filteredScores, filteredOverrides, filteredPubs, state.piCache, state.journalCache);
    const ws = XLSX.utils.json_to_sheet(data);
    autoFitColumns(ws, data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Ranked Open Requests');
    XLSX.writeFile(wb, `Open_Requests_Ranked_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportComprehensive = () => {
    const wb = XLSX.utils.book_new();

    const ranked = buildRankedSheet(filteredRequests, filteredScores, filteredOverrides, filteredPubs, state.piCache, state.journalCache);
    const ws1 = XLSX.utils.json_to_sheet(ranked);
    autoFitColumns(ws1, ranked);
    XLSX.utils.book_append_sheet(wb, ws1, 'Ranked Requests');

    const pis = buildPISheet(state.piCache);
    const ws2 = XLSX.utils.json_to_sheet(pis);
    autoFitColumns(ws2, pis);
    XLSX.utils.book_append_sheet(wb, ws2, 'PI Profiles');

    const journals = buildJournalSheet(state.journalCache);
    const ws3 = XLSX.utils.json_to_sheet(journals);
    autoFitColumns(ws3, journals);
    XLSX.utils.book_append_sheet(wb, ws3, 'Journal Metrics');

    const pubs = buildPublicationsSheet(filteredPubs);
    const ws4 = XLSX.utils.json_to_sheet(pubs);
    autoFitColumns(ws4, pubs);
    XLSX.utils.book_append_sheet(wb, ws4, 'Publications');

    if (filteredOverrides.length > 0) {
      const audit = buildAuditSheet(filteredOverrides);
      const ws5 = XLSX.utils.json_to_sheet(audit);
      autoFitColumns(ws5, audit);
      XLSX.utils.book_append_sheet(wb, ws5, 'Override Audit Log');
    }

    const activeWeight = state.weights.find(w => w.isActive);
    if (activeWeight) {
      const weightData = [{
        'Preset': activeWeight.presetName,
        'Scientific Merit (w1)': activeWeight.w1ScientificMerit,
        'Researcher Track (w2)': activeWeight.w2ResearcherTrack,
        'Institutional Alignment (w3)': activeWeight.w3InstitutionalAlignment,
        'Operational Efficiency (w4)': activeWeight.w4OperationalEfficiency,
        'Created At': activeWeight.createdAt,
      }];
      const ws6 = XLSX.utils.json_to_sheet(weightData);
      autoFitColumns(ws6, weightData);
      XLSX.utils.book_append_sheet(wb, ws6, 'Weight Config');
    }

    XLSX.writeFile(wb, `Research_Prioritization_Report_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const isFiltered = !!(fromDate || toDate || statusFilter !== 'all');
  const openCount = filteredRequests.filter(r => !r.dateCompleted).length;
  const closedCount = filteredRequests.filter(r => !!r.dateCompleted).length;
  const scoredCount = filteredScores.filter(s => s.status === 'scored').length;

  return (
    <div className="p-6 space-y-6 max-w-2xl">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Export & Reporting</h2>
        <p className="text-sm text-muted-foreground">Download scored data, enrichment results, and audit logs.</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Export Filters
            {isFiltered && (
              <Badge variant="secondary" className="ml-2 text-xs">
                {filteredRequests.length} of {state.requests.length} requests
              </Badge>
            )}
          </CardTitle>
          <CardDescription>Filter by status and date range. Leave empty to include all.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground w-14">Status:</span>
            {(['all', 'open', 'closed'] as const).map(s => (
              <Button
                key={s}
                size="sm"
                variant={statusFilter === s ? 'default' : 'outline'}
                onClick={() => setStatusFilter(s)}
                className="capitalize"
              >
                {s}
              </Button>
            ))}
          </div>
          {/* Date Range */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-sm text-muted-foreground w-14">Dates:</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-[170px] justify-start text-left font-normal", !fromDate && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {fromDate ? format(fromDate, 'MMM d, yyyy') : 'From date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={fromDate} onSelect={setFromDate} initialFocus className="p-3 pointer-events-auto" />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground text-sm">to</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-[170px] justify-start text-left font-normal", !toDate && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {toDate ? format(toDate, 'MMM d, yyyy') : 'To date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={toDate} onSelect={setToDate} initialFocus className="p-3 pointer-events-auto" />
              </PopoverContent>
            </Popover>
            {isFiltered && (
              <Button variant="ghost" size="sm" onClick={() => { setFromDate(undefined); setToDate(undefined); setStatusFilter('all'); }}>
                <X className="h-4 w-4 mr-1" /> Clear All
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Comprehensive Multi-Sheet Report */}
      <Card className="border-primary/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Comprehensive Report
          </CardTitle>
          <CardDescription>
            Multi-sheet .xlsx with ranked requests, PI profiles, journal metrics, publications, audit log, and weight config.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center gap-3">
          <Button onClick={handleExportComprehensive} disabled={state.requests.length === 0}>
            <Download className="h-4 w-4 mr-1" />
            Export Full Report
          </Button>
          <span className="text-xs text-muted-foreground">
            {scoredCount} scored · {state.piCache.length} PIs · {state.journalCache.length} journals
          </span>
        </CardContent>
      </Card>

      {/* Open Requests Export */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Open Requests (Ranked)
          </CardTitle>
          <CardDescription>
            Ranked by Effort-Adjusted ROI with subscores, PI metrics, and enrichment data.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center gap-3">
          <Button variant="outline" onClick={handleExportOpenRequests} disabled={openCount === 0}>
            <Download className="h-4 w-4 mr-1" />
            Export {openCount} Open Requests
          </Button>
          <span className="text-xs text-muted-foreground">{closedCount} closed excluded</span>
        </CardContent>
      </Card>

      {/* Full Raw Export */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Raw Data Backup
          </CardTitle>
          <CardDescription>All request data (open + closed) as .xlsx backup</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="outline" onClick={handleExportAll} disabled={state.requests.length === 0}>
            <Download className="h-4 w-4 mr-1" />
            Download All {state.requests.length} Requests
          </Button>
        </CardContent>
      </Card>

      {/* Data Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Data Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Open Requests</span>
              <Badge variant="default">{openCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Closed Requests</span>
              <Badge variant="secondary">{closedCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Scored Requests</span>
              <Badge variant="default">{scoredCount}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">PI Profiles</span>
              <Badge variant="outline">{state.piCache.filter(p => p.status === 'enriched').length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Journal Records</span>
              <Badge variant="outline">{state.journalCache.length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Publications</span>
              <Badge variant="outline">{filteredPubs.length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Manual Overrides</span>
              <Badge variant="outline">{filteredOverrides.length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Upload Logs</span>
              <Badge variant="outline">{state.uploadLogs.length}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
