import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAppStore } from '@/store/AppContext';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowUpDown, Search, AlertCircle, Clock, BookOpen, Filter, ChevronDown } from 'lucide-react';
import type { SortField, SortDirection, RedcapRequest } from '@/types';
import RequestDetail from '@/components/RequestDetail';
import PubMedSearchPanel from '@/components/PubMedSearchPanel';
import PIEnrichmentPanel from '@/components/PIEnrichmentPanel';
import JournalEnrichmentPanel from '@/components/JournalEnrichmentPanel';
import ScoringPanel from '@/components/ScoringPanel';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { collectFollowOns } from '@/components/GrantsHoverCard';
import { canonicalPIName } from '@/lib/piNameNormalize';

function MultiSelectFilter({
  label,
  options,
  selected,
  onToggle,
  onClear,
}: {
  label: string;
  options: string[];
  selected: Set<string>;
  onToggle: (value: string) => void;
  onClear: () => void;
}) {
  const summary = selected.size === 0 ? 'Any' : `${selected.size} selected`;
  return (
    <div className="flex flex-col gap-1">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="h-8 justify-between min-w-[160px] font-normal">
            <span className="truncate">{summary}</span>
            <ChevronDown className="h-3 w-3 ml-2 opacity-60" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-0 bg-popover" align="start">
          <div className="flex items-center justify-between px-3 py-2 border-b">
            <span className="text-xs font-medium text-muted-foreground">{label}</span>
            {selected.size > 0 && (
              <Button variant="ghost" size="sm" className="h-6 text-xs px-2" onClick={onClear}>Clear</Button>
            )}
          </div>
          <ScrollArea className="max-h-64">
            <div className="p-2 space-y-1">
              {options.length === 0 && (
                <div className="text-xs text-muted-foreground px-2 py-1">No options available</div>
              )}
              {options.map(opt => {
                const id = `${label}-${opt}`;
                return (
                  <div key={opt} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-accent">
                    <Checkbox id={id} checked={selected.has(opt)} onCheckedChange={() => onToggle(opt)} />
                    <Label htmlFor={id} className="text-sm font-normal cursor-pointer flex-1 truncate" title={opt}>
                      {opt}
                    </Label>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </PopoverContent>
      </Popover>
    </div>
  );
}

export default function Dashboard() {
  const { state } = useAppStore();
  const [sortField, setSortField] = useState<SortField>('dateOfRequest');
  const [sortDir, setSortDir] = useState<SortDirection>('desc');
  const [search, setSearch] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<RedcapRequest | null>(null);
  const [hasPubsFilter, setHasPubsFilter] = useState(false);
  const [hasGrantsFilter, setHasGrantsFilter] = useState(false);
  const [hasFollowOnsFilter, setHasFollowOnsFilter] = useState(false);
  const [hasIRBFilter, setHasIRBFilter] = useState(false);
  const [yearFrom, setYearFrom] = useState<string>('any');
  const [yearTo, setYearTo] = useState<string>('any');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'closed'>('all');
  const [fundingFilter, setFundingFilter] = useState<Set<string>>(new Set());
  const [rankFilter, setRankFilter] = useState<Set<string>>(new Set());
  const [tierFilter, setTierFilter] = useState<Set<number>>(new Set());

  // Derived option lists from current data
  const yearOptions = useMemo(() => {
    const years = new Set<number>();
    for (const r of state.requests) {
      const y = r.dateOfRequest ? new Date(r.dateOfRequest).getFullYear() : NaN;
      if (Number.isFinite(y)) years.add(y);
    }
    return Array.from(years).sort((a, b) => b - a);
  }, [state.requests]);

  const fundingOptions = useMemo(() => {
    const set = new Set<string>();
    state.requests.forEach(r => { if (r.fundingSource?.trim()) set.add(r.fundingSource.trim()); });
    return Array.from(set).sort();
  }, [state.requests]);

  const rankOptions = useMemo(() => {
    const set = new Set<string>();
    state.requests.forEach(r => { if (r.facultyRank?.trim()) set.add(r.facultyRank.trim()); });
    return Array.from(set).sort();
  }, [state.requests]);

  const toggleSetValue = <T,>(setter: React.Dispatch<React.SetStateAction<Set<T>>>, value: T) => {
    setter(prev => {
      const next = new Set(prev);
      if (next.has(value)) next.delete(value); else next.add(value);
      return next;
    });
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  // Helper: lookup PI cache by canonical name match
  const findPICache = (piName: string) => {
    const canonical = canonicalPIName(piName);
    return state.piCache.find(p => canonicalPIName(p.piName) === canonical) ?? null;
  };

  const filtered = useMemo(() => {
    let data = [...state.requests];
    if (search) {
      const q = search.toLowerCase();
      data = data.filter(r =>
        r.pi.toLowerCase().includes(q) ||
        r.department.toLowerCase().includes(q) ||
        r.projectTitle.toLowerCase().includes(q) ||
        r.recordId.includes(q)
      );
    }
    if (hasPubsFilter) {
      data = data.filter(r => state.publications.some(p => p.recordId === r.recordId));
    }
    if (hasGrantsFilter) {
      data = data.filter(r => {
        const pi = findPICache(r.pi);
        return (pi?.grantCount ?? 0) > 0;
      });
    }
    if (hasFollowOnsFilter) {
      data = data.filter(r => {
        const pi = findPICache(r.pi);
        if (!pi?.nihReporterData) return false;
        const pubs = state.publications.filter(p => p.recordId === r.recordId);
        return pubs.some(pub => {
          const followOns = collectFollowOns(pub.grants || '', pi.nihReporterData);
          return followOns.some(f => f.followOns.length > 0);
        });
      });
    }
    if (hasIRBFilter) {
      data = data.filter(r => !!r.irbNumber?.trim());
    }
    if (yearFrom !== 'any' || yearTo !== 'any') {
      const from = yearFrom === 'any' ? -Infinity : Number(yearFrom);
      const to = yearTo === 'any' ? Infinity : Number(yearTo);
      const lo = Math.min(from, to);
      const hi = Math.max(from, to);
      data = data.filter(r => {
        const y = r.dateOfRequest ? new Date(r.dateOfRequest).getFullYear() : NaN;
        return Number.isFinite(y) && y >= lo && y <= hi;
      });
    }
    if (statusFilter !== 'all') {
      data = data.filter(r => (statusFilter === 'open' ? !r.dateCompleted : !!r.dateCompleted));
    }
    if (fundingFilter.size > 0) {
      data = data.filter(r => fundingFilter.has((r.fundingSource || '').trim()));
    }
    if (rankFilter.size > 0) {
      data = data.filter(r => rankFilter.has((r.facultyRank || '').trim()));
    }
    if (tierFilter.size > 0) {
      data = data.filter(r => {
        const t = state.scores.find(s => s.recordId === r.recordId)?.scoringTier;
        return t != null && tierFilter.has(t);
      });
    }
    data.sort((a, b) => {
      // Sort by score fields if available
      if (sortField === 'weightedReturnScore' || sortField === 'effortAdjustedROIScore') {
        const scoreA = state.scores.find(s => s.recordId === a.recordId);
        const scoreB = state.scores.find(s => s.recordId === b.recordId);
        const valA = sortField === 'weightedReturnScore' ? scoreA?.weightedReturnScore : scoreA?.effortAdjustedROIScore;
        const valB = sortField === 'weightedReturnScore' ? scoreB?.weightedReturnScore : scoreB?.effortAdjustedROIScore;
        const cmp = (valA ?? -1) - (valB ?? -1);
        return sortDir === 'asc' ? cmp : -cmp;
      }
      if (sortField === 'rank') {
        const rankA = state.scores.find(s => s.recordId === a.recordId)?.rank ?? 9999;
        const rankB = state.scores.find(s => s.recordId === b.recordId)?.rank ?? 9999;
        const cmp = rankA - rankB;
        return sortDir === 'asc' ? cmp : -cmp;
      }
      const aVal = a[sortField as keyof RedcapRequest] ?? '';
      const bVal = b[sortField as keyof RedcapRequest] ?? '';
      const cmp = String(aVal).localeCompare(String(bVal), undefined, { numeric: true });
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return data;
  }, [state.requests, state.scores, state.publications, state.piCache, search, sortField, sortDir, hasPubsFilter, hasGrantsFilter, hasFollowOnsFilter, hasIRBFilter, yearFrom, yearTo, statusFilter, fundingFilter, rankFilter, tierFilter]);

  const getScore = (recordId: string) => state.scores.find(s => s.recordId === recordId);
  const getPubCount = (recordId: string) => state.publications.filter(p => p.recordId === recordId).length;

  const SortHeader = ({ field, label }: { field: SortField; label: string }) => (
    <Button variant="ghost" size="sm" className="h-8 -ml-3 font-medium" onClick={() => toggleSort(field)}>
      {label}
      <ArrowUpDown className="ml-1 h-3 w-3" />
    </Button>
  );

  const TierIndicator = ({ recordId }: { recordId: string }) => {
    const score = getScore(recordId);
    if (!score) return <span className="text-xs text-muted-foreground">—</span>;
    if (score.scoringTier === 3) return <Badge variant="destructive" className="text-xs">T3</Badge>;
    if (score.scoringTier === 2) return <Badge variant="secondary" className="text-xs">T2</Badge>;
    return <Badge className="text-xs">T1</Badge>;
  };

  if (state.requests.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-12 text-center">
        <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold text-foreground mb-2">No Requests Loaded</h2>
        <p className="text-muted-foreground mb-6 max-w-md">
          Upload a REDCap export (.xlsx) to get started. Your data stays entirely in your browser.
        </p>
        <Button asChild>
          <Link to="/upload">Upload Data</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Ranked Request Queue</h2>
          <div className="flex items-center gap-3 mt-1">
            <p className="text-sm text-muted-foreground">{filtered.length} of {state.requests.length} requests</p>
            {state.lastQueueUpdate && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                Queue updated: {new Date(state.lastQueueUpdate).toLocaleString()}
              </div>
            )}
          </div>
        </div>
        <div className="relative w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search PI, department, title..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <PubMedSearchPanel />
      <PIEnrichmentPanel />
      <JournalEnrichmentPanel />
      <ScoringPanel />

      {/* Filter card */}
      <Card>
        <CardContent className="py-3 space-y-3">
          {/* Row 1: presence checkboxes */}
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Filter className="h-4 w-4" />
              Filters
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="filter-pubs" checked={hasPubsFilter} onCheckedChange={(v) => setHasPubsFilter(v === true)} />
              <Label htmlFor="filter-pubs" className="text-sm font-normal cursor-pointer">Has publications</Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="filter-grants" checked={hasGrantsFilter} onCheckedChange={(v) => setHasGrantsFilter(v === true)} />
              <Label htmlFor="filter-grants" className="text-sm font-normal cursor-pointer">Has grants</Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="filter-followon" checked={hasFollowOnsFilter} onCheckedChange={(v) => setHasFollowOnsFilter(v === true)} />
              <Label htmlFor="filter-followon" className="text-sm font-normal cursor-pointer">Has follow-on grants</Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="filter-irb" checked={hasIRBFilter} onCheckedChange={(v) => setHasIRBFilter(v === true)} />
              <Label htmlFor="filter-irb" className="text-sm font-normal cursor-pointer">Has IRB</Label>
            </div>
          </div>

          {/* Row 2: dropdown filters */}
          <div className="flex flex-wrap items-end gap-3">
            {/* Year range */}
            <div className="flex flex-col gap-1">
              <Label className="text-xs text-muted-foreground">Year requested</Label>
              <div className="flex items-center gap-1">
                <Select value={yearFrom} onValueChange={setYearFrom}>
                  <SelectTrigger className="h-8 w-[110px]"><SelectValue placeholder="From" /></SelectTrigger>
                  <SelectContent className="bg-popover">
                    <SelectItem value="any">From: Any</SelectItem>
                    {yearOptions.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
                <span className="text-xs text-muted-foreground">–</span>
                <Select value={yearTo} onValueChange={setYearTo}>
                  <SelectTrigger className="h-8 w-[110px]"><SelectValue placeholder="To" /></SelectTrigger>
                  <SelectContent className="bg-popover">
                    <SelectItem value="any">To: Any</SelectItem>
                    {yearOptions.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Status */}
            <div className="flex flex-col gap-1">
              <Label className="text-xs text-muted-foreground">Status</Label>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as 'all' | 'open' | 'closed')}>
                <SelectTrigger className="h-8 w-[120px]"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-popover">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Funding source (multi) */}
            <MultiSelectFilter
              label="Funding source"
              options={fundingOptions}
              selected={fundingFilter}
              onToggle={(v) => toggleSetValue(setFundingFilter, v)}
              onClear={() => setFundingFilter(new Set())}
            />

            {/* Faculty rank (multi) */}
            <MultiSelectFilter
              label="Faculty rank"
              options={rankOptions}
              selected={rankFilter}
              onToggle={(v) => toggleSetValue(setRankFilter, v)}
              onClear={() => setRankFilter(new Set())}
            />

            {/* Tier (multi) */}
            <div className="flex flex-col gap-1">
              <Label className="text-xs text-muted-foreground">Tier</Label>
              <div className="flex items-center gap-2 h-8">
                {[1, 2, 3].map(t => (
                  <div key={t} className="flex items-center gap-1">
                    <Checkbox
                      id={`tier-${t}`}
                      checked={tierFilter.has(t)}
                      onCheckedChange={() => toggleSetValue(setTierFilter, t)}
                    />
                    <Label htmlFor={`tier-${t}`} className="text-sm font-normal cursor-pointer">T{t}</Label>
                  </div>
                ))}
              </div>
            </div>

            {(hasPubsFilter || hasGrantsFilter || hasFollowOnsFilter || hasIRBFilter ||
              yearFrom !== 'any' || yearTo !== 'any' || statusFilter !== 'all' ||
              fundingFilter.size > 0 || rankFilter.size > 0 || tierFilter.size > 0) && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs ml-auto"
                onClick={() => {
                  setHasPubsFilter(false); setHasGrantsFilter(false); setHasFollowOnsFilter(false); setHasIRBFilter(false);
                  setYearFrom('any'); setYearTo('any'); setStatusFilter('all');
                  setFundingFilter(new Set()); setRankFilter(new Set()); setTierFilter(new Set());
                }}
              >
                Clear filters
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="border border-border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12"><SortHeader field="rank" label="#" /></TableHead>
              <TableHead><SortHeader field="effortAdjustedROIScore" label="ROI" /></TableHead>
              <TableHead><SortHeader field="weightedReturnScore" label="Return" /></TableHead>
              <TableHead>Status</TableHead>
              <TableHead><SortHeader field="dateOfRequest" label="Requested" /></TableHead>
              <TableHead>Pubs</TableHead>
              <TableHead><SortHeader field="requestType" label="Type" /></TableHead>
              <TableHead><SortHeader field="department" label="Department" /></TableHead>
              <TableHead><SortHeader field="facultyRank" label="Rank" /></TableHead>
              <TableHead><SortHeader field="pi" label="PI" /></TableHead>
              <TableHead>Project Title</TableHead>
              <TableHead><SortHeader field="fundingSource" label="Funding" /></TableHead>
              <TableHead>Tier</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((req, idx) => {
              const score = getScore(req.recordId);
              const isOpen = !req.dateCompleted;
              return (
                <TableRow
                  key={req.recordId}
                  className="cursor-pointer"
                  onClick={() => setSelectedRequest(req)}
                >
                  <TableCell className="font-mono text-muted-foreground">{score?.rank ?? idx + 1}</TableCell>
                  <TableCell>
                    {score?.effortAdjustedROIScore != null ? (
                      <span className="font-mono text-sm font-bold">{score.effortAdjustedROIScore.toFixed(1)}</span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Pending</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {score?.weightedReturnScore != null ? (
                      <span className="font-mono text-sm">{score.weightedReturnScore.toFixed(1)}</span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Pending</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {isOpen ? (
                      <Badge variant="default">Open</Badge>
                    ) : (
                      <Badge variant="secondary">Closed</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-sm">{req.dateOfRequest}</TableCell>
                  <TableCell>
                    {getPubCount(req.recordId) > 0 ? (
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-3 w-3 text-muted-foreground" />
                        <span className="text-sm font-mono">{getPubCount(req.recordId)}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={req.requestType === 'Identified Data' ? 'default' : 'secondary'}>
                      {req.requestType || '—'}
                    </Badge>
                  </TableCell>
                  <TableCell>{req.department}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{req.facultyRank || '—'}</Badge>
                  </TableCell>
                  <TableCell className="font-medium">{req.pi}</TableCell>
                  <TableCell className="max-w-[200px] truncate" title={req.projectTitle}>{req.projectTitle}</TableCell>
                  <TableCell className="text-sm">{req.fundingSource || '—'}</TableCell>
                  <TableCell><TierIndicator recordId={req.recordId} /></TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <RequestDetail
        request={selectedRequest}
        open={!!selectedRequest}
        onClose={() => setSelectedRequest(null)}
      />
    </div>
  );
}
