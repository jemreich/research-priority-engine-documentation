import { useState, useMemo } from 'react';
import { useAppStore } from '@/store/AppContext';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, ArrowUpDown, TrendingUp, DollarSign, BookOpen, FlaskConical, Calendar, Filter } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { buildPINameMap, canonicalPIName } from '@/lib/piNameNormalize';
import { parseGrants } from '@/lib/grantParser';
import { collectFollowOns } from '@/components/GrantsHoverCard';
import type { PIEnrichmentCache, RequestPublication, RedcapRequest, ReporterProjectSummary } from '@/types';

interface PIRow {
  piName: string;
  rawNames: string[];
  department: string;
  facultyRank: string;
  requestCount: number;
  openRequests: number;
  pubCount: number;
  avgRCR: number | null;
  avgAuthorCount: number | null;
  totalCitations: number | null;
  grantCount: number | null;
  activeGrants: number | null;
  totalFunding: number | null;
  hasFollowOns: boolean;
  status: 'enriched' | 'pending' | 'error' | 'none';
}

type SortKey = 'piName' | 'facultyRank' | 'requestCount' | 'pubCount' | 'avgRCR' | 'avgAuthorCount' | 'totalFunding' | 'grantCount' | 'activeGrants';

export default function PIProfiles() {
  const { state } = useAppStore();
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('totalFunding');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [selectedPI, setSelectedPI] = useState<string | null>(null);
  const [fyFilter, setFyFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'active' | 'ended'>('all');
  const [hasPubsFilter, setHasPubsFilter] = useState(false);
  const [hasFollowOnsFilter, setHasFollowOnsFilter] = useState(false);
  const [selectedRanks, setSelectedRanks] = useState<Set<string>>(new Set());

  // Build canonical name map
  const nameMap = useMemo(() => {
    const allNames = state.requests.map(r => r.pi);
    state.piCache.forEach(p => allNames.push(p.piName));
    return buildPINameMap(allNames);
  }, [state.requests, state.piCache]);

  const piRows = useMemo(() => {
    const piMap = new Map<string, PIRow>();

    for (const req of state.requests) {
      const canonical = nameMap.get(req.pi) ?? req.pi;
      const key = canonicalPIName(req.pi);
      if (!piMap.has(key)) {
        piMap.set(key, {
          piName: canonical,
          rawNames: [req.pi],
          department: req.department || '—',
          facultyRank: req.facultyRank || '—',
          requestCount: 0,
          openRequests: 0,
          pubCount: 0,
          avgRCR: null,
          avgAuthorCount: null,
          totalCitations: null,
          grantCount: null,
          activeGrants: null,
          totalFunding: null,
          hasFollowOns: false,
          status: 'none',
        });
      }
      const row = piMap.get(key)!;
      if (!row.rawNames.includes(req.pi)) row.rawNames.push(req.pi);
      row.requestCount++;
      if (!req.dateCompleted) row.openRequests++;
    }

    // Merge PI enrichment (match by any raw name variant)
    for (const pi of state.piCache) {
      const key = canonicalPIName(pi.piName);
      const row = piMap.get(key);
      if (row) {
        row.grantCount = pi.grantCount;
        row.activeGrants = pi.activeGrants;
        row.totalFunding = pi.totalGrantFunding;
        row.status = pi.status;
      }
    }

    // Merge publication metrics
    const pubsByKey = new Map<string, RequestPublication[]>();
    for (const pub of state.publications) {
      const req = state.requests.find(r => r.recordId === pub.recordId);
      if (!req) continue;
      const key = canonicalPIName(req.pi);
      if (!pubsByKey.has(key)) pubsByKey.set(key, []);
      pubsByKey.get(key)!.push(pub);
    }

    for (const [key, allPubs] of pubsByKey) {
      const row = piMap.get(key);
      if (!row) continue;
      // Dedupe by PMID so a paper linked to several of this PI's requests counts once.
      const seen = new Set<string>();
      const pubs = allPubs.filter(p => {
        const id = p.pmid || `${p.recordId}::${p.journal}::${p.title}`;
        if (seen.has(id)) return false;
        seen.add(id);
        return true;
      });
      row.pubCount = pubs.length;
      const rcrs = pubs.filter(p => p.relativeCitationRatio != null).map(p => p.relativeCitationRatio!);
      row.avgRCR = rcrs.length > 0 ? rcrs.reduce((a, b) => a + b, 0) / rcrs.length : null;
      // Median author count: robust to mega-collaboration papers (1000+ authors)
      // that would otherwise inflate a simple mean.
      const authorCounts = pubs
        .filter(p => p.authorCount != null && p.authorCount! > 0)
        .map(p => p.authorCount!)
        .sort((a, b) => a - b);
      if (authorCounts.length > 0) {
        const mid = Math.floor(authorCounts.length / 2);
        row.avgAuthorCount = authorCounts.length % 2 === 0
          ? (authorCounts[mid - 1] + authorCounts[mid]) / 2
          : authorCounts[mid];
      } else {
        row.avgAuthorCount = null;
      }
      const cits = pubs.filter(p => p.citationCount != null).map(p => p.citationCount!);
      row.totalCitations = cits.length > 0 ? cits.reduce((a, b) => a + b, 0) : null;

      // Follow-on grants flag: any pub has follow-ons in PI's NIH RePORTER data
      const piEntry = state.piCache.find(p => canonicalPIName(p.piName) === key);
      const reporterData = piEntry?.nihReporterData ?? null;
      if (reporterData) {
        row.hasFollowOns = pubs.some(pub => {
          const followOns = collectFollowOns(pub.grants || '', reporterData);
          return followOns.some(f => f.followOns.length > 0);
        });
      }
    }

    return Array.from(piMap.values());
  }, [state.requests, state.piCache, state.publications, nameMap]);

  // Distinct faculty ranks present in data, sorted alphabetically
  const availableRanks = useMemo(() => {
    const set = new Set<string>();
    for (const r of piRows) {
      if (r.facultyRank && r.facultyRank !== '—') set.add(r.facultyRank);
    }
    return Array.from(set).sort();
  }, [piRows]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = q ? piRows.filter(r => r.piName.toLowerCase().includes(q) || r.department.toLowerCase().includes(q)) : piRows;

    if (selectedRanks.size > 0) {
      rows = rows.filter(r => selectedRanks.has(r.facultyRank));
    }
    if (hasPubsFilter) {
      rows = rows.filter(r => r.pubCount > 0);
    }
    if (hasFollowOnsFilter) {
      rows = rows.filter(r => r.hasFollowOns);
    }

    return [...rows].sort((a, b) => {
      const av = a[sortKey] ?? -Infinity;
      const bv = b[sortKey] ?? -Infinity;
      if (typeof av === 'string' && typeof bv === 'string') {
        return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      return sortDir === 'asc' ? (av as number) - (bv as number) : (bv as number) - (av as number);
    });
  }, [piRows, search, sortKey, sortDir, selectedRanks, hasPubsFilter, hasFollowOnsFilter]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  // Selected PI data (match by canonical key against all raw names)
  const selected = selectedPI ? piRows.find(r => canonicalPIName(r.piName) === selectedPI) : null;
  const selectedRawNames = selected?.rawNames ?? [];
  const selectedPubs = useMemo(() => {
    if (!selectedRawNames.length) return [];
    return state.publications.filter(p => {
      const req = state.requests.find(r => r.recordId === p.recordId);
      return req && selectedRawNames.includes(req.pi);
    });
  }, [selectedRawNames, state.publications, state.requests]);
  const selectedRequests = useMemo(() => {
    if (!selectedRawNames.length) return [];
    return state.requests.filter(r => selectedRawNames.includes(r.pi));
  }, [selectedRawNames, state.requests]);
  const selectedCache = useMemo(() => {
    if (!selectedPI) return null;
    // Match by canonical key so the cache entry is found regardless of
    // exact name format used at enrichment time vs. on the request rows.
    return (
      state.piCache.find(p => selectedRawNames.includes(p.piName)) ??
      state.piCache.find(p => canonicalPIName(p.piName) === selectedPI) ??
      null
    );
  }, [selectedPI, selectedRawNames, state.piCache]);

  // Get all fiscal years for filter dropdown
  const allFiscalYears = useMemo(() => {
    const years = new Set<number>();
    if (selectedCache?.nihReporterData?.projects) {
      for (const p of selectedCache.nihReporterData.projects) {
        years.add(p.fiscalYear);
      }
    }
    return Array.from(years).sort((a, b) => b - a);
  }, [selectedCache]);

  // Filter grants in the detail panel
  const filteredGrants = useMemo(() => {
    if (!selectedCache?.nihReporterData?.projects) return [];
    let projects = selectedCache.nihReporterData.projects;

    // Deduplicate by canonical core project number.
    // NIH project_num format: "<appType><activity><IC><serial>-<suffix>"
    // (e.g. "5R01CA123456-04A1"). The "core" is activity+IC+serial; the
    // app-type prefix digit and the amendment suffix vary per fiscal year
    // but represent the same underlying award.
    const canonical = (projectNum: string): string => {
      if (!projectNum) return '';
      const stripped = projectNum.split('-')[0]; // remove "-04A1"
      // Drop leading app-type digits (1, 2, 3, 5, 7, 9)
      return stripped.replace(/^\d+/, '').toUpperCase().replace(/\s+/g, '');
    };
    const seen = new Map<string, typeof projects[number]>();
    for (const p of projects) {
      const key = canonical(p.projectNum);
      const existing = seen.get(key);
      // Keep the most recent fiscal year as the representative entry.
      if (!existing || (p.fiscalYear ?? 0) > (existing.fiscalYear ?? 0)) {
        seen.set(key, p);
      }
    }
    projects = Array.from(seen.values());

    // FY filter
    if (fyFilter !== 'all') {
      const fy = parseInt(fyFilter, 10);
      projects = projects.filter(p => p.fiscalYear === fy);
    }

    // Date status filter
    if (dateFilter === 'active') {
      projects = projects.filter(p => p.isActive);
    } else if (dateFilter === 'ended') {
      projects = projects.filter(p => !p.isActive);
    }

    return projects;
  }, [selectedCache, fyFilter, dateFilter]);

  const SortButton = ({ field, label }: { field: SortKey; label: string }) => (
    <button
      className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
      onClick={() => toggleSort(field)}
    >
      {label}
      {sortKey === field && <ArrowUpDown className="h-3 w-3" />}
    </button>
  );

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">PI Profiles</h2>
        <p className="text-sm text-muted-foreground mt-1">Compare principal investigators by funding, publications, and research output</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or department..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Filter card */}
      <Card>
        <CardContent className="py-3 space-y-3">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Filter className="h-4 w-4" />
              Filters
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="pi-has-pubs"
                checked={hasPubsFilter}
                onCheckedChange={(v) => setHasPubsFilter(v === true)}
              />
              <Label htmlFor="pi-has-pubs" className="text-sm font-normal cursor-pointer">
                Has publications
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="pi-has-followons"
                checked={hasFollowOnsFilter}
                onCheckedChange={(v) => setHasFollowOnsFilter(v === true)}
              />
              <Label htmlFor="pi-has-followons" className="text-sm font-normal cursor-pointer">
                Has follow-on grants
              </Label>
            </div>
            {(selectedRanks.size > 0 || hasPubsFilter || hasFollowOnsFilter) && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs ml-auto"
                onClick={() => { setSelectedRanks(new Set()); setHasPubsFilter(false); setHasFollowOnsFilter(false); }}
              >
                Clear filters
              </Button>
            )}
          </div>
          {availableRanks.length > 0 && (
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-2 border-t border-border">
              <div className="text-sm font-medium text-muted-foreground">Faculty rank:</div>
              {availableRanks.map(rank => (
                <div key={rank} className="flex items-center gap-2">
                  <Checkbox
                    id={`rank-${rank}`}
                    checked={selectedRanks.has(rank)}
                    onCheckedChange={(v) => {
                      setSelectedRanks(prev => {
                        const next = new Set(prev);
                        if (v === true) next.add(rank);
                        else next.delete(rank);
                        return next;
                      });
                    }}
                  />
                  <Label htmlFor={`rank-${rank}`} className="text-sm font-normal cursor-pointer">
                    {rank}
                  </Label>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-6">
        {/* Table */}
        <div className="flex-1 border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted border-b border-border">
                  <th className="text-left px-4 py-3"><SortButton field="piName" label="PI Name" /></th>
                  <th className="text-left px-4 py-3"><SortButton field="facultyRank" label="Faculty Rank" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="requestCount" label="Requests" /></th>
                  <th className="text-right px-4 py-3"><SortButton field="totalFunding" label="Funding" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="grantCount" label="Grants" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="activeGrants" label="Active" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="pubCount" label="Pubs" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="avgRCR" label="Avg RCR" /></th>
                  <th className="text-center px-3 py-3"><SortButton field="avgAuthorCount" label="Median Authors" /></th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Dept</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(row => (
                  <tr
                    key={row.piName}
                    className={`border-b border-border hover:bg-muted/50 cursor-pointer transition-colors ${selectedPI === canonicalPIName(row.piName) ? 'bg-accent' : ''}`}
                    onClick={() => setSelectedPI(selectedPI === canonicalPIName(row.piName) ? null : canonicalPIName(row.piName))}
                  >
                    <td className="px-4 py-3 font-medium text-foreground">
                      {row.piName}
                      {row.rawNames.length > 1 && (
                        <span className="ml-1.5 text-xs text-muted-foreground">(aka {row.rawNames.filter(n => n !== row.piName).join(', ')})</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{row.facultyRank}</td>
                    <td className="text-center px-3 py-3">
                      <span className="text-foreground">{row.requestCount}</span>
                      {row.openRequests > 0 && (
                        <span className="ml-1 text-xs text-muted-foreground">({row.openRequests} open)</span>
                      )}
                    </td>
                    <td className="text-right px-4 py-3 font-mono text-foreground">
                      {row.totalFunding != null ? `$${(row.totalFunding / 1_000_000).toFixed(1)}M` : '—'}
                    </td>
                    <td className="text-center px-3 py-3 text-foreground">{row.grantCount ?? '—'}</td>
                    <td className="text-center px-3 py-3">
                      {row.activeGrants != null ? (
                        <Badge variant={row.activeGrants > 0 ? 'default' : 'secondary'}>
                          {row.activeGrants}
                        </Badge>
                      ) : '—'}
                    </td>
                    <td className="text-center px-3 py-3 text-foreground">{row.pubCount || '—'}</td>
                    <td className="text-center px-3 py-3 text-foreground">{row.avgRCR?.toFixed(2) ?? '—'}</td>
                    <td className="text-center px-3 py-3 text-foreground">{row.avgAuthorCount != null ? row.avgAuthorCount.toFixed(0) : '—'}</td>
                    <td className="px-4 py-3 text-muted-foreground">{row.department}</td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={10} className="text-center py-8 text-muted-foreground">
                      {state.requests.length === 0 ? 'No data uploaded yet.' : 'No PIs match your search.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="w-96 border border-border rounded-lg p-4 space-y-4 bg-background shrink-0 max-h-[calc(100vh-12rem)] overflow-y-auto">
            <div>
              <h3 className="text-lg font-bold text-foreground">{selected.piName}</h3>
              <p className="text-sm text-muted-foreground">{selected.department}</p>
              <p className="text-xs text-muted-foreground">{selected.facultyRank}</p>
            </div>

            <Separator />

            {/* Summary cards */}
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 rounded-md bg-muted text-center">
                <DollarSign className="h-3 w-3 mx-auto text-muted-foreground" />
                <p className="text-xs text-muted-foreground mt-1">Total Funding</p>
                <p className="text-sm font-bold text-foreground">
                  {selected.totalFunding != null ? `$${(selected.totalFunding / 1_000_000).toFixed(1)}M` : '—'}
                </p>
              </div>
              <div className="p-2 rounded-md bg-muted text-center">
                <FlaskConical className="h-3 w-3 mx-auto text-muted-foreground" />
                <p className="text-xs text-muted-foreground mt-1">Active Grants</p>
                <p className="text-sm font-bold text-foreground">{selected.activeGrants ?? '—'}</p>
              </div>
              <div className="p-2 rounded-md bg-muted text-center">
                <BookOpen className="h-3 w-3 mx-auto text-muted-foreground" />
                <p className="text-xs text-muted-foreground mt-1">Publications</p>
                <p className="text-sm font-bold text-foreground">{selected.pubCount || '—'}</p>
              </div>
              <div className="p-2 rounded-md bg-muted text-center">
                <TrendingUp className="h-3 w-3 mx-auto text-muted-foreground" />
                <p className="text-xs text-muted-foreground mt-1">Avg RCR</p>
                <p className="text-sm font-bold text-foreground">{selected.avgRCR?.toFixed(2) ?? '—'}</p>
              </div>
            </div>

            {/* Requests list - full titles */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Requests ({selectedRequests.length})</p>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {selectedRequests.map(req => (
                  <div key={req.recordId} className="text-xs p-2 rounded bg-muted">
                    <span className="font-mono text-muted-foreground">#{req.recordId}</span>
                    <p className="mt-0.5 text-foreground leading-snug">{req.projectTitle || 'Untitled'}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* RePORTER grants with filters */}
            {selectedCache?.nihReporterData?.projects && selectedCache.nihReporterData.projects.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                  NIH Grants ({selectedCache.nihReporterData.uniqueGrants})
                </p>

                {/* Grant filters */}
                <div className="flex gap-2 mb-2">
                  <Select value={fyFilter} onValueChange={setFyFilter}>
                    <SelectTrigger className="h-7 text-xs flex-1">
                      <SelectValue placeholder="Fiscal Year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All FYs</SelectItem>
                      {allFiscalYears.map(fy => (
                        <SelectItem key={fy} value={String(fy)}>FY {fy}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={dateFilter} onValueChange={(v) => setDateFilter(v as 'all' | 'active' | 'ended')}>
                    <SelectTrigger className="h-7 text-xs flex-1">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active Only</SelectItem>
                      <SelectItem value="ended">Ended Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1 max-h-64 overflow-y-auto">
                  {filteredGrants.length === 0 ? (
                    <p className="text-xs text-muted-foreground text-center py-4">No grants match filters.</p>
                  ) : (
                    filteredGrants.map((proj, i) => {
                      // Parse the grant to get full activity code and IC names
                      const parsed = parseGrants(proj.projectNum);
                      const grant = parsed[0];
                      return (
                        <div key={`${proj.projectNum}-${i}`} className="text-xs p-2 rounded bg-muted space-y-0.5">
                          <p className="font-mono font-medium text-foreground">{proj.projectNum}</p>
                          {grant?.isNIH && grant.instituteName && (
                            <p className="text-muted-foreground">{grant.instituteName}</p>
                          )}
                          {grant?.isNIH && grant.activityCodeName && (
                            <p className="text-muted-foreground">{grant.activityCodeName}</p>
                          )}
                          {proj.title && (
                            <p className="text-foreground leading-snug font-medium">{proj.title}</p>
                          )}
                          <p className="text-muted-foreground">
                            <Calendar className="inline h-3 w-3 mr-1 -mt-0.5" />
                            {proj.startDate ? new Date(proj.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '?'}
                            {' → '}
                            {proj.endDate ? new Date(proj.endDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '?'}
                            {proj.isActive && <span className="ml-1.5 text-green-600 font-medium">● Active</span>}
                          </p>
                          {proj.amount != null && (
                            <p className="text-muted-foreground">${(proj.amount / 1000).toFixed(0)}K (FY{proj.fiscalYear})</p>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
