import { useMemo, useState } from 'react';
import { useAppStore } from '@/store/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { BarChart3, Filter } from 'lucide-react';
import { canonicalPIName } from '@/lib/piNameNormalize';

interface MetricSummary {
  label: string;
  count: number;
  min: number | null;
  avg: number | null;
  max: number | null;
  values: number[];
}

function summarize(label: string, values: (number | null | undefined)[]): MetricSummary {
  const nums = values.filter((v): v is number => v != null && isFinite(v));
  if (nums.length === 0) return { label, count: 0, min: null, avg: null, max: null, values: [] };
  return {
    label,
    count: nums.length,
    min: Math.min(...nums),
    avg: nums.reduce((a, b) => a + b, 0) / nums.length,
    max: Math.max(...nums),
    values: nums,
  };
}

function fmt(v: number | null, decimals = 2): string {
  if (v == null) return '—';
  if (Math.abs(v) >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (Math.abs(v) >= 1_000) return v.toLocaleString(undefined, { maximumFractionDigits: decimals });
  return v.toFixed(decimals);
}

/** Metrics that should always be displayed as integers (no decimals). */
const INTEGER_METRICS = new Set<string>([
  'Active Grants',
  'Total Publications',
  'Total Citations',
  'Grant Count',
  'H-Index',
  'Total Docs (3yr)',
  'Citation Count',
  'SJR H-Index',
  'H5-Index (Google Scholar)',
  'H5-Median (Google Scholar)',
]);

function fmtForMetric(v: number | null, label: string): string {
  if (v == null) return '—';
  if (INTEGER_METRICS.has(label)) {
    if (Math.abs(v) >= 1_000) return Math.round(v).toLocaleString();
    return Math.round(v).toString();
  }
  return fmt(v);
}

/**
 * Build histogram from explicit bucket edges. The last edge defines the start of
 * the overflow bucket (e.g. edges [0,10,50,200] → "0–10", "10–50", "50–200", "200+").
 */
function buildHistogramFromEdges(
  values: number[],
  edges: number[],
  label: string,
): { label: string; count: number; pct: number }[] {
  if (values.length === 0 || edges.length < 2) return [];
  const bins = edges.slice(0, -1).map((lo, i) => ({
    lo,
    hi: edges[i + 1],
    count: 0,
    isLast: false,
  }));
  const overflowStart = edges[edges.length - 1];
  bins.push({ lo: overflowStart, hi: Infinity, count: 0, isLast: true });

  for (const v of values) {
    let idx = bins.findIndex(b => v >= b.lo && v < b.hi);
    if (idx === -1) idx = v >= overflowStart ? bins.length - 1 : 0;
    bins[idx].count++;
  }
  const maxCount = Math.max(...bins.map(b => b.count));
  return bins.map(b => ({
    label: b.isLast
      ? `${fmtForMetric(b.lo, label)}+`
      : `${fmtForMetric(b.lo, label)}–${fmtForMetric(b.hi, label)}`,
    count: b.count,
    pct: maxCount > 0 ? (b.count / maxCount) * 100 : 0,
  }));
}

/** Custom bucket edges for skewed metrics. Last value = start of "X+" overflow bucket. */
const CUSTOM_BUCKETS: Record<string, number[]> = {
  'Citation Count': [0, 5, 10, 25, 50, 100, 150, 200],
  'Citations per Year': [0, 1, 2, 5, 10, 20, 50, 100],
  'Relative Citation Ratio (RCR)': [0, 0.5, 1, 1.5, 2, 3, 5, 10],
  'Total Citations': [0, 10, 50, 100, 250, 500, 1000, 2000, 5000, 10000, 25000, 50000, 100000, 200000, 300000],
  'Total Grant Funding ($)': [0, 100_000, 500_000, 1_000_000, 2_500_000, 5_000_000, 10_000_000, 15_000_000, 22_600_000],
};

/** Build histogram bins from raw values, using custom buckets if defined for the label. */
function buildHistogram(
  values: number[],
  label: string,
  binCount = 10,
): { label: string; count: number; pct: number }[] {
  if (values.length === 0) return [];
  const customEdges = CUSTOM_BUCKETS[label];
  if (customEdges) return buildHistogramFromEdges(values, customEdges, label);

  const min = Math.min(...values);
  const max = Math.max(...values);
  if (min === max) {
    return [{ label: fmtForMetric(min, label), count: values.length, pct: 100 }];
  }
  const binWidth = (max - min) / binCount;
  const bins = Array.from({ length: binCount }, (_, i) => ({
    lo: min + i * binWidth,
    hi: min + (i + 1) * binWidth,
    count: 0,
  }));
  for (const v of values) {
    let idx = Math.floor((v - min) / binWidth);
    if (idx >= binCount) idx = binCount - 1;
    bins[idx].count++;
  }
  const maxCount = Math.max(...bins.map(b => b.count));
  return bins.map(b => ({
    label: `${fmtForMetric(b.lo, label)}–${fmtForMetric(b.hi, label)}`,
    count: b.count,
    pct: maxCount > 0 ? (b.count / maxCount) * 100 : 0,
  }));
}

export default function SummaryStats() {
  const { state } = useAppStore();
  const [enabledSections, setEnabledSections] = useState<Record<string, boolean>>({
    'Imported Data': true,
    'Publication Metrics (PubMed / iCite)': true,
    'PI Enrichment (NIH RePORTER)': true,
    'Journal Enrichment (SCImago / Google Scholar)': true,
    'ROI Scoring': true,
  });
  const [distributionMetric, setDistributionMetric] = useState<string>('none');

  const sections = useMemo(() => {
    const importedMetrics: MetricSummary[] = [
      summarize('TRAC Hours', state.tracHours.map(t => t.totalHours)),
    ];

    const pubs = state.publications;
    const pubMetrics: MetricSummary[] = [
      summarize('Relative Citation Ratio (RCR)', pubs.map(p => p.relativeCitationRatio)),
      summarize('Citation Count', pubs.map(p => p.citationCount)),
      summarize('NIH Percentile', pubs.map(p => p.nihPercentile)),
      summarize('Citations per Year', pubs.map(p => p.citationsPerYear)),
      summarize('Expected Citations/Year', pubs.map(p => p.expectedCitationsPerYear)),
      summarize('Field Citation Rate', pubs.map(p => p.fieldCitationRate)),
      summarize('Article-level APT', pubs.map(p => p.apt)),
    ];

    // Derive per-PI publication metrics from state.publications, matched by canonical PI name.
    // (state.piCache only carries grant data; pub-derived stats live alongside requests.)
    const pubsByPIKey = new Map<string, typeof state.publications>();
    for (const pub of state.publications) {
      const req = state.requests.find(r => r.recordId === pub.recordId);
      if (!req?.pi) continue;
      const key = canonicalPIName(req.pi);
      if (!pubsByPIKey.has(key)) pubsByPIKey.set(key, []);
      pubsByPIKey.get(key)!.push(pub);
    }
    // h-index = largest h such that h papers each have ≥ h citations.
    const computeHIndex = (citations: number[]): number => {
      const sorted = [...citations].sort((a, b) => b - a);
      let h = 0;
      for (let i = 0; i < sorted.length; i++) {
        if (sorted[i] >= i + 1) h = i + 1;
        else break;
      }
      return h;
    };
    const piPubStats = Array.from(pubsByPIKey.entries()).map(([, pubs]) => {
      const cits = pubs.map(p => p.citationCount).filter((c): c is number => c != null);
      return {
        totalPublications: pubs.length,
        totalCitations: cits.length > 0 ? cits.reduce((a, b) => a + b, 0) : null,
        hIndex: cits.length > 0 ? computeHIndex(cits) : null,
      };
    });

    const piMetrics: MetricSummary[] = [
      summarize('H-Index', piPubStats.map(p => p.hIndex)),
      summarize('Total Citations', piPubStats.map(p => p.totalCitations)),
      summarize('Total Publications', piPubStats.map(p => p.totalPublications)),
      summarize('Grant Count', state.piCache.map(p => p.grantCount)),
      summarize('Active Grants', state.piCache.map(p => p.activeGrants)),
      summarize('Total Grant Funding ($)', state.piCache.map(p => p.totalGrantFunding)),
    ];

    const jc = state.journalCache;
    const journalMetrics: MetricSummary[] = [
      summarize('H5-Index (Google Scholar)', jc.map(j => j.h5Index)),
      summarize('H5-Median (Google Scholar)', jc.map(j => j.h5Median)),
      summarize('SJR', jc.map(j => j.sjr)),
      summarize('SJR H-Index', jc.map(j => j.sjrHIndex)),
      summarize('Total Docs (3yr)', jc.map(j => j.totalDocs3yr)),
      summarize('Citations/Doc (2yr)', jc.map(j => j.citPerDoc2yr)),
      summarize('Market Cap ($B)', jc.map(j => j.marketCapBillions)),
      summarize('Market CAGR (%)', jc.map(j => j.marketCAGR)),
    ];

    const sc = state.scores;
    const scoreMetrics: MetricSummary[] = [
      summarize('Publication Impact Score', sc.map(s => s.publicationImpactScore)),
      summarize('Journal Prestige Score', sc.map(s => s.journalPrestigeScore)),
      summarize('Funding Activity Score', sc.map(s => s.fundingActivityScore)),
      summarize('Research Output Score', sc.map(s => s.researchOutputScore)),
      summarize('Weighted Return Score', sc.map(s => s.weightedReturnScore)),
      summarize('Effort-Adjusted ROI', sc.map(s => s.effortAdjustedROIScore)),
      summarize('Effort Multiplier', sc.map(s => s.effortMultiplier)),
    ];

    return [
      { title: 'Imported Data', metrics: importedMetrics },
      { title: 'Publication Metrics (PubMed / iCite)', metrics: pubMetrics },
      { title: 'PI Enrichment (NIH RePORTER)', metrics: piMetrics },
      { title: 'Journal Enrichment (SCImago / Google Scholar)', metrics: journalMetrics },
      { title: 'ROI Scoring', metrics: scoreMetrics },
    ];
  }, [state]);

  // Flat list of all metrics for the distribution selector
  const allMetrics = useMemo(() => {
    const list: { key: string; label: string; section: string; metric: MetricSummary }[] = [];
    for (const sec of sections) {
      for (const m of sec.metrics) {
        if (m.count > 0) list.push({ key: `${sec.title}::${m.label}`, label: m.label, section: sec.title, metric: m });
      }
    }
    return list;
  }, [sections]);

  const distMetric = distributionMetric === 'none'
    ? null
    : allMetrics.find(m => m.key === distributionMetric) ?? null;

  const histogram = useMemo(
    () => (distMetric ? buildHistogram(distMetric.metric.values, distMetric.label) : []),
    [distMetric]
  );

  const totalRequests = state.requests.length;
  const totalPubs = state.publications.length;
  const totalPIs = state.piCache.length;
  const totalJournals = state.journalCache.length;
  const totalScored = state.scores.filter(s => s.status === 'scored').length;

  const visibleSections = sections.filter(s => enabledSections[s.title]);
  const allOn = Object.values(enabledSections).every(Boolean);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Summary Statistics</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Min, average, and max for all metrics across imported and enriched data
        </p>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {[
          { label: 'Requests', value: totalRequests },
          { label: 'Publications', value: totalPubs },
          { label: 'PI Profiles', value: totalPIs },
          { label: 'Journals Enriched', value: totalJournals },
          { label: 'Scored Requests', value: totalScored },
        ].map(c => (
          <Card key={c.label} className="text-center">
            <CardContent className="pt-4 pb-3">
              <p className="text-2xl font-bold text-foreground">{c.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{c.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filter card */}
      <Card>
        <CardContent className="py-3 space-y-3">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Filter className="h-4 w-4" />
              Show sections
            </div>
            {sections.map(sec => (
              <div key={sec.title} className="flex items-center gap-2">
                <Checkbox
                  id={`sec-${sec.title}`}
                  checked={enabledSections[sec.title] ?? true}
                  onCheckedChange={(v) =>
                    setEnabledSections(prev => ({ ...prev, [sec.title]: v === true }))
                  }
                />
                <Label htmlFor={`sec-${sec.title}`} className="text-sm font-normal cursor-pointer">
                  {sec.title.replace(/\s*\(.*\)\s*/, '')}
                </Label>
              </div>
            ))}
            {!allOn && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs ml-auto"
                onClick={() =>
                  setEnabledSections(Object.fromEntries(sections.map(s => [s.title, true])))
                }
              >
                Show all
              </Button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-border">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <BarChart3 className="h-4 w-4" />
              View distribution
            </div>
            <Select value={distributionMetric} onValueChange={setDistributionMetric}>
              <SelectTrigger className="h-8 w-72">
                <SelectValue placeholder="Select a metric to view its distribution..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {allMetrics.map(m => (
                  <SelectItem key={m.key} value={m.key}>
                    {m.label} <span className="text-muted-foreground">({m.section.replace(/\s*\(.*\)\s*/, '')})</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Distribution chart */}
      {distMetric && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
              Distribution: {distMetric.label}
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                n={distMetric.metric.count} · min {fmtForMetric(distMetric.metric.min, distMetric.label)} · avg {fmtForMetric(distMetric.metric.avg, distMetric.label)} · max {fmtForMetric(distMetric.metric.max, distMetric.label)}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {histogram.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No data.</p>
            ) : (
              <div className="space-y-1.5">
                {histogram.map((bin, i) => (
                  <div key={i} className="flex items-center gap-3 text-xs">
                    <div className="w-32 font-mono text-muted-foreground text-right">{bin.label}</div>
                    <div className="flex-1 h-5 bg-muted rounded-sm overflow-hidden relative">
                      <div
                        className="h-full bg-primary transition-all"
                        style={{ width: `${bin.pct}%` }}
                      />
                    </div>
                    <div className="w-12 font-mono text-foreground">{bin.count}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Metric sections */}
      {visibleSections.map(section => {
        const hasData = section.metrics.some(m => m.count > 0);
        return (
          <Card key={section.title}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
                {section.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!hasData ? (
                <p className="text-sm text-muted-foreground py-4 text-center">No data available yet. Run the enrichment steps to populate.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[280px]">Metric</TableHead>
                      <TableHead className="text-center w-20">N</TableHead>
                      <TableHead className="text-right">Min</TableHead>
                      <TableHead className="text-right">Average</TableHead>
                      <TableHead className="text-right">Max</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {section.metrics.map(m => (
                      <TableRow key={m.label}>
                        <TableCell className="font-medium">{m.label}</TableCell>
                        <TableCell className="text-center text-muted-foreground">{m.count}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{fmtForMetric(m.min, m.label)}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{fmtForMetric(m.avg, m.label)}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{fmtForMetric(m.max, m.label)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
