import { useState, useCallback } from 'react';
import { useAppStore } from '@/store/AppContext';
import { parseRedcapExcel, parseTracExcel } from '@/lib/parseExcel';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload as UploadIcon, FileSpreadsheet, CheckCircle2, AlertTriangle, Loader2, X, Trash2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import type { UploadLog } from '@/types';

type UploadType = 'redcap' | 'trac';

interface StagedFile {
  file: File;
  type: UploadType;
}

interface UploadResult {
  type: UploadType;
  filename: string;
  recordCount: number;
  errors: string[];
  status: 'success' | 'error' | 'partial';
}

export default function UploadPage() {
  const { state, dispatch } = useAppStore();
  const [loading, setLoading] = useState(false);
  const [lastResult, setLastResult] = useState<UploadResult | null>(null);
  const [dragOver, setDragOver] = useState<UploadType | null>(null);
  const [stagedFile, setStagedFile] = useState<StagedFile | null>(null);

  const stageFile = useCallback((file: File, type: UploadType) => {
    setStagedFile({ file, type });
    setLastResult(null);
  }, []);

  const confirmUpload = useCallback(async () => {
    if (!stagedFile) return;
    const { file, type } = stagedFile;
    setLoading(true);
    setLastResult(null);

    try {
      if (type === 'redcap') {
        const { requests, errors } = await parseRedcapExcel(file);
        dispatch({ type: 'ADD_REQUESTS', payload: requests });
        const log: UploadLog = {
          id: crypto.randomUUID(),
          type: 'redcap',
          filename: file.name,
          timestamp: new Date().toISOString(),
          recordCount: requests.length,
          status: errors.length ? 'partial' : 'success',
          errors,
        };
        dispatch({ type: 'ADD_UPLOAD_LOG', payload: log });
        setLastResult({ type, filename: file.name, recordCount: requests.length, errors, status: log.status });
      } else {
        const { hours, errors } = await parseTracExcel(file);
        dispatch({ type: 'ADD_TRAC_HOURS', payload: hours });
        const log: UploadLog = {
          id: crypto.randomUUID(),
          type: 'trac',
          filename: file.name,
          timestamp: new Date().toISOString(),
          recordCount: hours.length,
          status: errors.length ? 'partial' : 'success',
          errors,
        };
        dispatch({ type: 'ADD_UPLOAD_LOG', payload: log });
        setLastResult({ type, filename: file.name, recordCount: hours.length, errors, status: log.status });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setLastResult({ type, filename: file.name, recordCount: 0, errors: [msg], status: 'error' });
    } finally {
      setLoading(false);
      setStagedFile(null);
    }
  }, [stagedFile, dispatch]);

  const onDrop = useCallback((e: React.DragEvent, type: UploadType) => {
    e.preventDefault();
    setDragOver(null);
    const file = e.dataTransfer.files[0];
    if (file) stageFile(file, type);
  }, [stageFile]);

  const onFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>, type: UploadType) => {
    const file = e.target.files?.[0];
    if (file) stageFile(file, type);
    e.target.value = '';
  }, [stageFile]);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Upload Data</h2>
        <p className="text-sm text-muted-foreground">Import REDCap and Trac Excel files. All parsing happens locally in your browser.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* REDCap Upload */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              REDCap Export
            </CardTitle>
            <CardDescription>Upload the REDCap service request export (.xlsx)</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              onDrop={e => onDrop(e, 'redcap')}
              onDragOver={e => { e.preventDefault(); setDragOver('redcap'); }}
              onDragLeave={() => setDragOver(null)}
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                dragOver === 'redcap' ? 'border-primary bg-accent' : 'border-border hover:border-primary/50'
              }`}
              onClick={() => document.getElementById('redcap-input')?.click()}
            >
              <UploadIcon className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
              <p className="text-sm font-medium text-foreground">Drop .xlsx file here or click to browse</p>
              <p className="text-xs text-muted-foreground mt-1">REDCap data extraction request export</p>
              <input id="redcap-input" type="file" accept=".xlsx,.xls" className="hidden" onChange={e => onFileSelect(e, 'redcap')} />
            </div>
          </CardContent>
        </Card>

        {/* Trac Upload */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              Trac Hours
            </CardTitle>
            <CardDescription>Upload the Trac time tracking export (.xlsx)</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              onDrop={e => onDrop(e, 'trac')}
              onDragOver={e => { e.preventDefault(); setDragOver('trac'); }}
              onDragLeave={() => setDragOver(null)}
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                dragOver === 'trac' ? 'border-primary bg-accent' : 'border-border hover:border-primary/50'
              }`}
              onClick={() => document.getElementById('trac-input')?.click()}
            >
              <UploadIcon className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
              <p className="text-sm font-medium text-foreground">Drop .xlsx file here or click to browse</p>
              <p className="text-xs text-muted-foreground mt-1">Trac time/hours tracking export</p>
              <input id="trac-input" type="file" accept=".xlsx,.xls" className="hidden" onChange={e => onFileSelect(e, 'trac')} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Staged File Confirmation */}
      {stagedFile && !loading && (
        <Card className="border-primary">
          <CardContent className="flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium text-foreground">{stagedFile.file.name}</p>
                <p className="text-xs text-muted-foreground">
                  Ready to import as <Badge variant="outline" className="ml-1">{stagedFile.type === 'redcap' ? 'REDCap' : 'Trac'}</Badge>
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => setStagedFile(null)}>
                <X className="h-4 w-4 mr-1" />
                Cancel
              </Button>
              <Button size="sm" onClick={confirmUpload}>
                <UploadIcon className="h-4 w-4 mr-1" />
                Upload Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading */}
      {loading && (
        <Card>
          <CardContent className="flex items-center gap-3 py-4">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <span className="text-sm text-foreground">Parsing file...</span>
          </CardContent>
        </Card>
      )}

      {/* Result */}
      {lastResult && !loading && (
        <Card>
          <CardContent className="py-4 space-y-2">
            <div className="flex items-center gap-2">
              {lastResult.status === 'success' ? (
                <CheckCircle2 className="h-5 w-5 text-primary" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-destructive" />
              )}
              <span className="font-medium text-foreground">
                {lastResult.filename}: {lastResult.recordCount} records imported
              </span>
              <Badge variant={lastResult.status === 'success' ? 'default' : 'secondary'}>
                {lastResult.status}
              </Badge>
            </div>
            {lastResult.errors.length > 0 && (
              <div className="text-xs text-muted-foreground space-y-1 max-h-32 overflow-auto">
                {lastResult.errors.map((err, i) => <p key={i}>{err}</p>)}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Upload History */}
      {state.uploadLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upload History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {state.uploadLogs.slice(0, 10).map(log => (
                <div key={log.id} className="flex items-center gap-3 text-sm">
                  <Badge variant="outline">{log.type}</Badge>
                  <span className="text-foreground">{log.filename}</span>
                  <span className="text-muted-foreground">{log.recordCount} records</span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Data Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Current Data</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">REDCap Requests:</span>{' '}
              <span className="font-medium text-foreground">{state.requests.length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Trac Hours Records:</span>{' '}
              <span className="font-medium text-foreground">{state.tracHours.length}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Clear All Data */}
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <Trash2 className="h-5 w-5" />
            Clear All Data
          </CardTitle>
          <CardDescription>Remove all loaded data from browser storage. This cannot be undone.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="destructive" onClick={() => {
            dispatch({ type: 'CLEAR_ALL' });
            toast.success('All data cleared');
          }}>
            Clear All Data
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
