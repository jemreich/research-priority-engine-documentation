import { useState, useMemo } from "react";
import { useAppStore } from "@/store/AppContext";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, RotateCcw, Lock, Unlock, ChevronDown, ChevronUp, Check, Trash2 } from "lucide-react";
import { DEFAULT_SUB_WEIGHTS } from "@/types";
import type { WeightConfig as WeightConfigType } from "@/types";

// ─── Types & definitions ─────────────────────────────────────

type MetricKey = keyof typeof DEFAULT_SUB_WEIGHTS;

interface MetricDef {
  key: MetricKey;
  label: string;
  description: string;
}

interface SectionDef {
  id: "s1" | "s2" | "s3" | "s4";
  title: string;
  color: string;
  textColor: string;
  metrics: MetricDef[];
}

const SECTIONS: SectionDef[] = [
  {
    id: "s1",
    title: "Scientific Merit",
    color: "bg-blue-500",
    textColor: "text-blue-600",
    metrics: [
      {
        key: "s1_rcr",
        label: "Relative Citation Ratio",
        description: "Field-normalized citation impact; 2.0+ is top-tier.",
      },
      {
        key: "s1_nihPercentile",
        label: "NIH Percentile",
        description: "Publication percentile within NIH-funded literature.",
      },
      { key: "s1_citationCount", label: "Citation Count", description: "Raw citations (log-scaled)." },
    ],
  },
  {
    id: "s2",
    title: "Researcher Track Record",
    color: "bg-violet-500",
    textColor: "text-violet-600",
    metrics: [
      { key: "s2_hIndex", label: "h-index", description: "Career h-index of the PI." },
      { key: "s2_totalPublications", label: "Total Publications", description: "Lifetime publication count." },
      { key: "s2_totalCitations", label: "Total Citations", description: "Lifetime citations (log-scaled)." },
      {
        key: "s2_facultyRank",
        label: "Faculty Rank",
        description: "Academic rank: endowed/full Prof → top, postdoc/RA → bottom.",
      },
    ],
  },
  {
    id: "s3",
    title: "Institutional Alignment",
    color: "bg-emerald-500",
    textColor: "text-emerald-600",
    metrics: [
      { key: "s3_sjrQuartile", label: "SJR Quartile", description: "Journal quartile (Q1–Q4)." },
      { key: "s3_sjr", label: "SJR Score", description: "SCImago Journal Rank value." },
      { key: "s3_h5Index", label: "h5-Index", description: "Google Scholar 5-year h-index." },
      {
        key: "s3_citPerDoc2yr",
        label: "Citations / Doc (2yr)",
        description: "Average citations per document over 2 years.",
      },
    ],
  },
  {
    id: "s4",
    title: "Operational Efficiency",
    color: "bg-amber-500",
    textColor: "text-amber-600",
    metrics: [
      {
        key: "s4_fundingSource",
        label: "Funding Source",
        description: "NIH/federal weighted highest, internal/pilot lowest.",
      },
      { key: "s4_activeGrants", label: "Active Grants", description: "PI's count of currently-active NIH grants." },
      {
        key: "s4_totalFunding",
        label: "Total Grant Funding",
        description: "Cumulative NIH award amount across the PI portfolio.",
      },
    ],
  },
];

const ALL_METRIC_KEYS = SECTIONS.flatMap((s) => s.metrics.map((m) => m.key));
const METRIC_COUNT = ALL_METRIC_KEYS.length;

// ─── Presets ─────────────────────────────────────────────────

const PRESETS: { label: string; values: Record<MetricKey, number> }[] = [
  {
    label: "Equal",
    values: Object.fromEntries(ALL_METRIC_KEYS.map((k) => [k, 1 / METRIC_COUNT])) as Record<MetricKey, number>,
  },
  {
    label: "Science-heavy",
    values: {
      s1_rcr: 0.18,
      s1_nihPercentile: 0.12,
      s1_citationCount: 0.08,
      s2_hIndex: 0.1,
      s2_totalPublications: 0.06,
      s2_totalCitations: 0.06,
      s2_facultyRank: 0.06,
      s3_sjrQuartile: 0.06,
      s3_sjr: 0.05,
      s3_h5Index: 0.05,
      s3_citPerDoc2yr: 0.05,
      s4_fundingSource: 0.05,
      s4_activeGrants: 0.04,
      s4_totalFunding: 0.04,
    },
  },
  {
    label: "Researcher-heavy",
    values: {
      s1_rcr: 0.08,
      s1_nihPercentile: 0.06,
      s1_citationCount: 0.06,
      s2_hIndex: 0.18,
      s2_totalPublications: 0.12,
      s2_totalCitations: 0.12,
      s2_facultyRank: 0.1,
      s3_sjrQuartile: 0.05,
      s3_sjr: 0.05,
      s3_h5Index: 0.05,
      s3_citPerDoc2yr: 0.05,
      s4_fundingSource: 0.04,
      s4_activeGrants: 0.02,
      s4_totalFunding: 0.02,
    },
  },
  {
    label: "Funding-heavy",
    values: {
      s1_rcr: 0.07,
      s1_nihPercentile: 0.06,
      s1_citationCount: 0.05,
      s2_hIndex: 0.06,
      s2_totalPublications: 0.05,
      s2_totalCitations: 0.05,
      s2_facultyRank: 0.05,
      s3_sjrQuartile: 0.05,
      s3_sjr: 0.05,
      s3_h5Index: 0.04,
      s3_citPerDoc2yr: 0.04,
      s4_fundingSource: 0.16,
      s4_activeGrants: 0.14,
      s4_totalFunding: 0.13,
    },
  },
];

// ─── Rebalance helper ─────────────────────────────────────────

function rebalanceGlobal(
  values: Record<MetricKey, number>,
  changedKey: MetricKey,
  newVal: number,
  lockedKeys: Set<MetricKey>,
): Record<MetricKey, number> {
  // Sum of OTHER locked keys (excluding the one being changed) — this is the floor we cannot reduce
  const otherLockedSum = ALL_METRIC_KEYS
    .filter((k) => k !== changedKey && lockedKeys.has(k))
    .reduce((s, k) => s + (values[k] ?? 0), 0);

  // Maximum the changed key can take so the total never exceeds 1 (100%)
  const maxAllowed = Math.max(0, 1 - otherLockedSum);
  const clamped = Math.min(maxAllowed, Math.max(0, newVal));

  const next = { ...values, [changedKey]: clamped };
  const nextLocked = new Set(lockedKeys).add(changedKey);
  const unlocked = ALL_METRIC_KEYS.filter((k) => !nextLocked.has(k));
  const lockedSum = ALL_METRIC_KEYS.filter((k) => nextLocked.has(k)).reduce((s, k) => s + next[k], 0);
  const remaining = Math.max(0, 1 - lockedSum);

  if (unlocked.length > 0) {
    const each = parseFloat((remaining / unlocked.length).toFixed(4));
    unlocked.forEach((k) => {
      next[k] = Math.max(0, each);
    });
    const total = ALL_METRIC_KEYS.reduce((s, k) => s + next[k], 0);
    const err = parseFloat((1 - total).toFixed(4));
    if (Math.abs(err) > 0.0001) {
      // Apply correction without going negative
      const corrected = parseFloat((next[unlocked[0]] + err).toFixed(4));
      next[unlocked[0]] = Math.max(0, corrected);
    }
  }

  // Final safety clamp: ensure no value is negative or above 1
  ALL_METRIC_KEYS.forEach((k) => {
    if (next[k] < 0) next[k] = 0;
    if (next[k] > 1) next[k] = 1;
  });

  return next;
}

// ─── Component ──────────────────────────────────────────────

export default function WeightConfigPage() {
  const { state, dispatch } = useAppStore();
  const activeWeights = useMemo(() => state.weights.find((w) => w.isActive) ?? state.weights[0], [state.weights]);

  const [values, setValues] = useState<Record<MetricKey, number>>(() => {
    const initial = {} as Record<MetricKey, number>;
    ALL_METRIC_KEYS.forEach((k) => {
      initial[k] = (activeWeights as unknown as Record<MetricKey, number>)[k] ?? DEFAULT_SUB_WEIGHTS[k];
    });
    return initial;
  });

  const [lockedKeys, setLockedKeys] = useState<Set<MetricKey>>(new Set());
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(SECTIONS.map((s) => s.id)));
  const [presetName, setPresetName] = useState("");
  const [inputDraft, setInputDraft] = useState<Partial<Record<MetricKey, string>>>({});

  const globalTotal = useMemo(() => ALL_METRIC_KEYS.reduce((s, k) => s + (values[k] ?? 0), 0), [values]);

  const sectionTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    SECTIONS.forEach((sec) => {
      totals[sec.id] = sec.metrics.reduce((s, m) => s + (values[m.key] ?? 0), 0);
    });
    return totals;
  }, [values]);

  const allValid = Math.abs(globalTotal - 1.0) < 0.01;

  // ─── Handlers ─────────────────────────────────────────────

  const handleSlider = (key: MetricKey, val: number[]) => {
    const newVal = parseFloat((val[0] / 100).toFixed(4));
    setLockedKeys((prev) => new Set(prev).add(key));
    setValues((prev) => rebalanceGlobal(prev, key, newVal, lockedKeys));
    setInputDraft((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleInputChange = (key: MetricKey, raw: string) => {
    setInputDraft((prev) => ({ ...prev, [key]: raw }));
  };

  const handleInputCommit = (key: MetricKey) => {
    const raw = inputDraft[key];
    if (raw === undefined) return;
    const parsed = parseFloat(raw);
    if (isNaN(parsed)) {
      setInputDraft((prev) => ({ ...prev, [key]: undefined }));
      return;
    }
    const clamped = Math.min(100, Math.max(0, parsed));
    const newVal = parseFloat((clamped / 100).toFixed(4));
    setLockedKeys((prev) => new Set(prev).add(key));
    setValues((prev) => rebalanceGlobal(prev, key, newVal, lockedKeys));
    setInputDraft((prev) => ({ ...prev, [key]: undefined }));
  };

  const toggleLock = (key: MetricKey) => {
    setLockedKeys((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const applyPreset = (preset: (typeof PRESETS)[number]) => {
    setValues({ ...preset.values });
    setLockedKeys(new Set());
    setInputDraft({});
  };

  const loadSavedPreset = (w: WeightConfigType) => {
    const next = {} as Record<MetricKey, number>;
    ALL_METRIC_KEYS.forEach((k) => {
      next[k] = (w as unknown as Record<MetricKey, number>)[k] ?? DEFAULT_SUB_WEIGHTS[k];
    });
    setValues(next);
    setLockedKeys(new Set());
    setInputDraft({});
    setPresetName(w.presetName);
    dispatch({ type: "ACTIVATE_WEIGHT", payload: { id: w.id } });
  };

  const deleteSavedPreset = (id: string) => {
    dispatch({ type: "DELETE_WEIGHT", payload: { id } });
  };

  const handleResetAll = () => {
    const each = parseFloat((1 / METRIC_COUNT).toFixed(4));
    const equal = Object.fromEntries(ALL_METRIC_KEYS.map((k) => [k, each])) as Record<MetricKey, number>;
    setValues(equal);
    setLockedKeys(new Set());
    setInputDraft({});
  };

  const toggleSection = (id: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleSave = () => {
    const config: WeightConfigType = {
      id: crypto.randomUUID(),
      presetName: presetName || `Custom ${new Date().toLocaleDateString()}`,
      w1ScientificMerit: 0.25,
      w2ResearcherTrack: 0.25,
      w3InstitutionalAlignment: 0.25,
      w4OperationalEfficiency: 0.25,
      ...values,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: "UPDATE_WEIGHTS", payload: config });
    setPresetName("");
  };

  // ─── Render ───────────────────────────────────────────────

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground">Weight Configuration</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Each metric gets a slice of 100%. Adjusting one metric auto-redistributes the remainder across unlocked
          metrics. Lock a metric to protect its value.
        </p>
      </div>

      {/* ── Allocation bar ── */}
      <Card>
        <CardContent className="pt-5 pb-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-foreground">Total allocation</span>
            <span className={`text-sm font-mono font-bold ${allValid ? "text-emerald-600" : "text-destructive"}`}>
              {(globalTotal * 100).toFixed(1)}%{allValid ? " ✓" : " — must reach 100%"}
            </span>
          </div>

          {/* Stacked bar */}
          <div className="flex h-7 w-full rounded-lg overflow-hidden gap-0.5 bg-muted">
            {SECTIONS.map((sec) => {
              const pct = (sectionTotals[sec.id] ?? 0) * 100;
              return (
                <div
                  key={sec.id}
                  className={`${sec.color} transition-all duration-300 flex items-center justify-center overflow-hidden`}
                  style={{ width: `${pct}%`, minWidth: pct > 0 ? 2 : 0 }}
                  title={`${sec.title}: ${pct.toFixed(1)}%`}
                >
                  {pct > 9 && (
                    <span className="text-white text-[11px] font-bold px-1 truncate select-none">
                      {pct.toFixed(0)}%
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-x-5 gap-y-1">
            {SECTIONS.map((sec) => (
              <div key={sec.id} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className={`inline-block w-2.5 h-2.5 rounded-sm flex-shrink-0 ${sec.color}`} />
                <span>{sec.title}</span>
                <span className={`font-mono font-bold ${sec.textColor}`}>
                  {((sectionTotals[sec.id] ?? 0) * 100).toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ── Quick presets ── */}
      <div className="space-y-2">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Quick presets</p>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((preset) => (
            <Button
              key={preset.label}
              variant="outline"
              size="sm"
              onClick={() => applyPreset(preset)}
              className="text-xs h-8"
            >
              {preset.label}
            </Button>
          ))}
          <Button variant="ghost" size="sm" onClick={handleResetAll} className="text-xs h-8 text-muted-foreground">
            <RotateCcw className="h-3 w-3 mr-1" /> Reset equal
          </Button>
        </div>
      </div>

      {/* ── Section cards ── */}
      <div className="space-y-3">
        {SECTIONS.map((sec) => {
          const isExpanded = expandedSections.has(sec.id);
          const sectionPct = (sectionTotals[sec.id] ?? 0) * 100;

          return (
            <Card key={sec.id} className="overflow-hidden">
              {/* Collapsible header */}
              <button
                className="w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 rounded-t-lg"
                onClick={() => toggleSection(sec.id)}
              >
                <CardHeader className="py-3 px-5">
                  <div className="flex items-center gap-3">
                    <span className={`w-3 h-3 rounded-sm flex-shrink-0 ${sec.color}`} />
                    <CardTitle className="text-sm font-semibold flex-1 text-foreground">{sec.title}</CardTitle>
                    <span className={`text-sm font-mono font-bold ${sec.textColor} w-14 text-right`}>
                      {sectionPct.toFixed(1)}%
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                </CardHeader>
              </button>

              {/* Metric rows */}
              {isExpanded && (
                <CardContent className="px-5 pb-4 pt-0 border-t border-border">
                  {sec.metrics.map((metric, idx) => {
                    const pct = (values[metric.key] ?? 0) * 100;
                    const isLocked = lockedKeys.has(metric.key);
                    const draft = inputDraft[metric.key];
                    const displayVal = draft !== undefined ? draft : pct.toFixed(1);

                    return (
                      <div key={metric.key}>
                        {idx > 0 && <div className="border-t border-border/40" />}
                        <div className="py-3 space-y-2">
                          {/* Label + controls */}
                          <div className="flex items-center gap-2">
                            <Label className="text-xs font-medium text-foreground flex-1 leading-snug">
                              {metric.label}
                            </Label>
                            {/* % input */}
                            <div className="relative flex-shrink-0">
                              <Input
                                className="h-7 w-[72px] text-xs font-mono pr-6 text-right"
                                value={displayVal}
                                onChange={(e) => handleInputChange(metric.key, e.target.value)}
                                onBlur={() => handleInputCommit(metric.key)}
                                onKeyDown={(e) => e.key === "Enter" && handleInputCommit(metric.key)}
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground pointer-events-none">
                                %
                              </span>
                            </div>
                            {/* Lock toggle */}
                            <Button
                              variant="ghost"
                              size="icon"
                              className={`h-7 w-7 flex-shrink-0 ${isLocked ? "text-primary bg-primary/10" : "text-muted-foreground"}`}
                              onClick={() => toggleLock(metric.key)}
                              title={isLocked ? "Locked — click to allow auto-adjustment" : "Unlocked — click to lock"}
                            >
                              {isLocked ? <Lock className="h-3.5 w-3.5" /> : <Unlock className="h-3.5 w-3.5" />}
                            </Button>
                          </div>

                          {/* Slider */}
                          <Slider
                            value={[pct]}
                            onValueChange={(v) => handleSlider(metric.key, v)}
                            min={0}
                            max={100}
                            step={0.5}
                            className={isLocked ? "opacity-50" : ""}
                          />

                          <p className="text-[11px] text-muted-foreground leading-tight">{metric.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {/* ── Save bar ── */}
      <Card>
        <CardContent className="pt-5 pb-5">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <Input
              placeholder="Preset name (optional)"
              value={presetName}
              onChange={(e) => setPresetName(e.target.value)}
              className="max-w-xs text-sm"
            />
            <div className="flex gap-2 items-center flex-wrap">
              <Button onClick={handleSave} disabled={!allValid} size="sm">
                <Save className="h-3.5 w-3.5 mr-1.5" /> Save weights
              </Button>
              {!allValid && <span className="text-xs text-destructive">Total must equal 100% before saving.</span>}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Weight history ── */}
      {state.weights.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">Saved presets</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Click a preset to load its values into the editor and make it active for scoring.
            </p>
          </CardHeader>
          <CardContent className="space-y-1">
            {state.weights.map((w) => (
              <div
                key={w.id}
                className={`flex items-center gap-3 text-sm rounded-md border transition-colors ${
                  w.isActive ? "border-primary/40 bg-primary/5" : "border-transparent hover:bg-muted/60"
                }`}
              >
                <button
                  type="button"
                  onClick={() => loadSavedPreset(w)}
                  className="flex items-center gap-3 flex-1 text-left px-2 py-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
                  title="Load this preset and make it active"
                >
                  <span
                    className={`w-2 h-2 rounded-full flex-shrink-0 ${w.isActive ? "bg-emerald-500" : "bg-muted-foreground/30"}`}
                  />
                  <span className="font-medium text-foreground flex-1 truncate">{w.presetName}</span>
                  {w.isActive ? (
                    <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
                      <Check className="h-3 w-3" /> Active
                    </span>
                  ) : (
                    <span className="text-[11px] text-muted-foreground">Click to apply</span>
                  )}
                  <span className="text-xs text-muted-foreground w-20 text-right">
                    {new Date(w.createdAt).toLocaleDateString()}
                  </span>
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 mr-1 text-muted-foreground hover:text-destructive"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (state.weights.length <= 1) return;
                    deleteSavedPreset(w.id);
                  }}
                  disabled={state.weights.length <= 1}
                  title={state.weights.length <= 1 ? "Cannot delete the last preset" : "Delete preset"}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
