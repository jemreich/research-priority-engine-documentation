import React, { createContext, useContext, useReducer, useEffect, useRef, type ReactNode } from "react";
import { get as idbGet, set as idbSet, del as idbDel } from "idb-keyval";
import type {
  AppState,
  RedcapRequest,
  TracHours,
  WeightConfig,
  AdminConfig,
  UploadLog,
  OverrideLog,
  RequestPublication,
  PIEnrichmentCache,
  JournalEnrichment,
  RequestScore,
  UnresolvedJournal,
} from "@/types";
import { DEFAULT_SUB_WEIGHTS } from "@/types";
import { mergeRequestsByRecordId, mergeTracHoursByRecordId } from "@/store/mergeState";

const STORAGE_KEY = "research-prioritization-store";

const defaultAdminConfig: AdminConfig = {
  nicheBonusEnabled: false,
  nicheBonusMultiplierMin: 1.1,
  nicheBonusMultiplierMax: 1.3,
  nicheBonusMarketCapThreshold: 50,
  nicheBonusCAGRThreshold: 7,
  nicheQuartileCriterion: {
    enabled: true,
    allowedQuartiles: ["Q1", "Q2"],
  },
  nicheNumericCriteria: [
    { metric: "totalDocs3yr", enabled: true, operator: "lte", threshold: 300 },
    { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
    { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
    { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
  ],
  nicheInterpolationMetric: "totalDocs3yr",
  proxyEnabled: false,
  proxyConfidenceDiscount: 0.85,
  insufficientDataDiscount: 0.5,
  enrichmentCycleDays: 14,
  lastEnrichmentRun: null,
  effortAnchorHours: 2,
  effortDampening: 0.5,
  effortMultiplierMin: 0.25,
  effortMultiplierMax: 3.0,
};

const initialState: AppState = {
  requests: [],
  tracHours: [],
  publications: [],
  piCache: [],
  journalCache: [],
  scores: [],
  weights: [
    {
      id: "default",
      presetName: "Default",
      w1ScientificMerit: 0.25,
      w2ResearcherTrack: 0.25,
      w3InstitutionalAlignment: 0.25,
      w4OperationalEfficiency: 0.25,
      ...DEFAULT_SUB_WEIGHTS,
      isActive: true,
      createdAt: new Date().toISOString(),
    },
  ],
  adminConfig: defaultAdminConfig,
  overrides: [],
  uploadLogs: [],
  unresolvedJournals: [],
  lastQueueUpdate: null,
};

type Action =
  | { type: "LOAD_STATE"; payload: AppState }
  | { type: "SET_REQUESTS"; payload: RedcapRequest[] }
  | { type: "ADD_REQUESTS"; payload: RedcapRequest[] }
  | { type: "SET_TRAC_HOURS"; payload: TracHours[] }
  | { type: "ADD_TRAC_HOURS"; payload: TracHours[] }
  | { type: "UPDATE_WEIGHTS"; payload: WeightConfig }
  | { type: "ACTIVATE_WEIGHT"; payload: { id: string } }
  | { type: "DELETE_WEIGHT"; payload: { id: string } }
  | { type: "UPDATE_ADMIN_CONFIG"; payload: Partial<AdminConfig> }
  | { type: "ADD_UPLOAD_LOG"; payload: UploadLog }
  | { type: "ADD_OVERRIDE"; payload: OverrideLog }
  | { type: "SET_PUBLICATIONS"; payload: RequestPublication[] }
  | { type: "ADD_PUBLICATIONS"; payload: RequestPublication[] }
  | { type: "UPDATE_PUBLICATIONS"; payload: RequestPublication[] }
  | { type: "SET_PI_CACHE"; payload: PIEnrichmentCache[] }
  | { type: "ADD_PI_CACHE"; payload: PIEnrichmentCache[] }
  | { type: "SET_JOURNAL_CACHE"; payload: JournalEnrichment[] }
  | { type: "ADD_JOURNAL_CACHE"; payload: JournalEnrichment[] }
  | { type: "SET_SCORES"; payload: RequestScore[] }
  | { type: "SET_QUEUE_UPDATED" }
  | { type: "ADD_UNRESOLVED_JOURNAL"; payload: { abbreviation: string } }
  | { type: "CLEAR_UNRESOLVED_JOURNALS" }
  | { type: "CLEAR_ALL" };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "LOAD_STATE": {
      // Migrate legacy weight presets where each section summed to 1.0 (total ≈ 4.0)
      // to the new equal-balanced defaults where the global total is 1.0.
      const subKeys = Object.keys(DEFAULT_SUB_WEIGHTS) as (keyof typeof DEFAULT_SUB_WEIGHTS)[];
      const migratedWeights = (action.payload.weights ?? initialState.weights).map((w) => {
        const total = subKeys.reduce(
          (s, k) => s + ((w as unknown as Record<string, number>)[k] ?? 0),
          0,
        );
        // If totals are clearly legacy (≥ ~2.0) replace sub-weights with new defaults.
        if (total > 1.5) {
          return { ...w, ...DEFAULT_SUB_WEIGHTS };
        }
        return w;
      });
      return {
        ...initialState,
        ...action.payload,
        weights: migratedWeights.length > 0 ? migratedWeights : initialState.weights,
        adminConfig: { ...defaultAdminConfig, ...action.payload.adminConfig },
        unresolvedJournals: action.payload.unresolvedJournals ?? [],
      };
    }
    case "SET_REQUESTS":
      return { ...state, requests: action.payload, lastQueueUpdate: new Date().toISOString() };
    case "ADD_REQUESTS":
      return {
        ...state,
        requests: mergeRequestsByRecordId(state.requests, action.payload),
        lastQueueUpdate: new Date().toISOString(),
      };
    case "SET_TRAC_HOURS":
      return { ...state, tracHours: action.payload };
    case "ADD_TRAC_HOURS":
      return {
        ...state,
        tracHours: mergeTracHoursByRecordId(state.tracHours, action.payload),
      };
    case "UPDATE_WEIGHTS": {
      const updated = state.weights.map((w) => (w.isActive ? { ...w, isActive: false } : w));
      return { ...state, weights: [...updated, { ...action.payload, isActive: true }] };
    }
    case "ACTIVATE_WEIGHT": {
      return {
        ...state,
        weights: state.weights.map((w) => ({ ...w, isActive: w.id === action.payload.id })),
      };
    }
    case "DELETE_WEIGHT": {
      const remaining = state.weights.filter((w) => w.id !== action.payload.id);
      // Ensure at least one preset remains active
      if (remaining.length > 0 && !remaining.some((w) => w.isActive)) {
        remaining[0] = { ...remaining[0], isActive: true };
      }
      return { ...state, weights: remaining };
    }
    case "UPDATE_ADMIN_CONFIG":
      return { ...state, adminConfig: { ...state.adminConfig, ...action.payload } };
    case "ADD_UPLOAD_LOG":
      return { ...state, uploadLogs: [action.payload, ...state.uploadLogs] };
    case "ADD_OVERRIDE":
      return { ...state, overrides: [action.payload, ...state.overrides] };
    case "SET_PUBLICATIONS":
      return { ...state, publications: action.payload };
    case "ADD_PUBLICATIONS": {
      // Dedupe by (recordId, pmid) — the same PMID can legitimately link to
      // multiple requests/PIs, so global PMID dedupe would undercount.
      const existing = new Set(state.publications.map((p) => `${p.recordId}::${p.pmid}`));
      const newPubs = action.payload.filter((p) => !existing.has(`${p.recordId}::${p.pmid}`));
      return { ...state, publications: [...state.publications, ...newPubs] };
    }
    case "UPDATE_PUBLICATIONS": {
      // Key by (recordId, pmid) so that updates targeting a specific
      // request-publication row don't clobber the recordId of duplicates.
      const updates = new Map(action.payload.map((p) => [`${p.recordId}::${p.pmid}`, p]));
      return {
        ...state,
        publications: state.publications.map((p) => updates.get(`${p.recordId}::${p.pmid}`) ?? p),
      };
    }
    case "SET_PI_CACHE":
      return { ...state, piCache: action.payload };
    case "ADD_PI_CACHE": {
      const existingNames = new Set(state.piCache.map((p) => p.piName));
      const newEntries = action.payload.filter((p) => !existingNames.has(p.piName));
      // Update existing entries with new data
      const updated = state.piCache.map((existing) => {
        const newer = action.payload.find((p) => p.piName === existing.piName);
        return newer ?? existing;
      });
      return { ...state, piCache: [...updated, ...newEntries] };
    }
    case "SET_JOURNAL_CACHE":
      return { ...state, journalCache: action.payload };
    case "ADD_JOURNAL_CACHE": {
      const existingKeys = new Set(state.journalCache.flatMap((j) => [j.journalName, j.originalName].filter(Boolean)));
      const newEntries = action.payload.filter(
        (j) => !existingKeys.has(j.journalName) && (!j.originalName || !existingKeys.has(j.originalName)),
      );
      const updated = state.journalCache.map((existing) => {
        const newer = action.payload.find(
          (j) => j.journalName === existing.journalName || j.originalName === existing.originalName,
        );
        return newer ?? existing;
      });
      return { ...state, journalCache: [...updated, ...newEntries] };
    }
    case "SET_SCORES":
      return { ...state, scores: action.payload };
    case "SET_QUEUE_UPDATED":
      return { ...state, lastQueueUpdate: new Date().toISOString() };
    case "ADD_UNRESOLVED_JOURNAL": {
      const abbr = action.payload.abbreviation.trim();
      if (!abbr) return state;
      const existing = state.unresolvedJournals.find((u) => u.abbreviation === abbr);
      const now = new Date().toISOString();
      const next = existing
        ? state.unresolvedJournals.map((u) =>
            u.abbreviation === abbr ? { ...u, attempts: u.attempts + 1, lastTriedAt: now } : u,
          )
        : [...state.unresolvedJournals, { abbreviation: abbr, attempts: 1, lastTriedAt: now }];
      return { ...state, unresolvedJournals: next };
    }
    case "CLEAR_UNRESOLVED_JOURNALS":
      return { ...state, unresolvedJournals: [] };
    case "CLEAR_ALL":
      return initialState;
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const hydrated = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load: prefer IndexedDB; one-time migrate from localStorage if present.
  useEffect(() => {
    (async () => {
      try {
        let parsed: AppState | null = null;
        const idbVal = await idbGet<AppState>(STORAGE_KEY);
        if (idbVal) {
          parsed = idbVal;
        } else {
          const stored = localStorage.getItem(STORAGE_KEY);
          if (stored) {
            parsed = JSON.parse(stored) as AppState;
            // Migrated; free up the localStorage slot to avoid quota issues.
            try { localStorage.removeItem(STORAGE_KEY); } catch { /* noop */ }
          }
        }
        if (parsed) dispatch({ type: "LOAD_STATE", payload: parsed });
      } catch (e) {
        console.error("Failed to load persisted state:", e);
      } finally {
        hydrated.current = true;
      }
    })();
  }, []);

  // Persist (debounced) to IndexedDB — supports much larger payloads than localStorage.
  useEffect(() => {
    if (!hydrated.current) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      idbSet(STORAGE_KEY, state).catch((e) => {
        console.error("Failed to persist state:", e);
      });
    }, 250);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [state]);

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

// Exported for "Clear all data" workflows that need to wipe persistence too.
export async function clearPersistedState() {
  try { await idbDel(STORAGE_KEY); } catch { /* noop */ }
  try { localStorage.removeItem(STORAGE_KEY); } catch { /* noop */ }
}

export function useAppStore() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppStore must be used within AppProvider");
  return context;
}
