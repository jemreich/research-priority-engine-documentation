import type { RedcapRequest, TracHours } from '@/types';

export function mergeRequestsByRecordId(existing: RedcapRequest[], incoming: RedcapRequest[]) {
  const merged = new Map<string, RedcapRequest>();

  existing.forEach((request) => {
    if (request.recordId) merged.set(request.recordId, request);
  });

  incoming.forEach((request) => {
    if (request.recordId) merged.set(request.recordId, request);
  });

  return Array.from(merged.values());
}

export function mergeTracHoursByRecordId(existing: TracHours[], incoming: TracHours[]) {
  const merged = new Map<string, TracHours>();

  existing.forEach((entry) => {
    if (entry.recordId) merged.set(entry.recordId, entry);
  });

  incoming.forEach((entry) => {
    if (entry.recordId) merged.set(entry.recordId, entry);
  });

  return Array.from(merged.values());
}
