import { describe, it, expect } from 'vitest';
import { parseGrants, countGrants } from '@/lib/grantParser';

describe('grantParser', () => {
  describe('parseGrants', () => {
    it('parses a standard NIH R01 grant', () => {
      const result = parseGrants('R01 CA218398');
      expect(result).toHaveLength(1);
      expect(result[0].isNIH).toBe(true);
      expect(result[0].instituteName).toBe('National Cancer Institute');
      expect(result[0].activityCodeName).toContain('Research Project');
      expect(result[0].coreProjectNumber).toBe('R01 CA218398');
    });

    it('parses a P30 center core grant', () => {
      const result = parseGrants('P30 CA012197');
      expect(result).toHaveLength(1);
      expect(result[0].isNIH).toBe(true);
      expect(result[0].instituteName).toBe('National Cancer Institute');
      expect(result[0].activityCodeName).toContain('Center Core Grants');
      expect(result[0].coreProjectNumber).toBe('P30 CA012197');
    });

    it('parses grant with leading application type digit', () => {
      const result = parseGrants('5R01CA654321-01A1');
      expect(result).toHaveLength(1);
      expect(result[0].isNIH).toBe(true);
      expect(result[0].coreProjectNumber).toBe('R01 CA654321');
    });

    it('parses multiple grants separated by semicolons', () => {
      const result = parseGrants('P30 CA012197; R01 CA218398');
      expect(result).toHaveLength(2);
      expect(result[0].isNIH).toBe(true);
      expect(result[1].isNIH).toBe(true);
    });

    it('treats unknown/international grants as non-NIH', () => {
      const result = parseGrants('Wellcome Trust 203141/Z/16/Z');
      expect(result).toHaveLength(1);
      expect(result[0].isNIH).toBe(false);
      expect(result[0].raw).toContain('Wellcome Trust');
    });

    it('handles mixed NIH and international grants', () => {
      const result = parseGrants('R01 CA218398; Cancer Research UK C1234');
      expect(result).toHaveLength(2);
      expect(result[0].isNIH).toBe(true);
      expect(result[1].isNIH).toBe(false);
    });

    it('returns empty for empty string', () => {
      expect(parseGrants('')).toHaveLength(0);
      expect(parseGrants('  ')).toHaveLength(0);
    });

    it('parses K-series career development awards', () => {
      const result = parseGrants('K23 MH123456');
      expect(result).toHaveLength(1);
      expect(result[0].instituteName).toBe('National Institute of Mental Health');
      expect(result[0].activityCodeName).toContain('Mentored Patient-Oriented');
    });

    it('parses T32 training grants', () => {
      const result = parseGrants('T32 HL007055');
      expect(result).toHaveLength(1);
      expect(result[0].instituteName).toBe('National Heart, Lung, and Blood Institute');
      expect(result[0].activityCodeName).toContain('Institutional National Research Service Award');
    });
  });

  describe('countGrants', () => {
    it('counts grants correctly', () => {
      expect(countGrants('P30 CA012197; R01 CA218398')).toBe(2);
      expect(countGrants('')).toBe(0);
      expect(countGrants('R01 CA218398')).toBe(1);
    });
  });
});
