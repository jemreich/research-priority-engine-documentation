import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import GrantsHoverCard from '@/components/GrantsHoverCard';

describe('GrantsHoverCard', () => {
  it('does not show details until hovered', async () => {
    render(<GrantsHoverCard grantsString="P30 CA012197; R01 CA218398" />);

    expect(screen.queryByText('Grant Details')).not.toBeInTheDocument();

    fireEvent.mouseEnter(screen.getByRole('button', { name: /2 grants/i }));

    expect(await screen.findByText('Grant Details')).toBeInTheDocument();
  });
});
