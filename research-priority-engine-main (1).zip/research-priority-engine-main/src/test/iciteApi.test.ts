import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest';
import { mapICiteRecord, fetchICiteMetrics, type ICiteRecord } from '@/lib/iciteApi';

describe('iciteApi', () => {
  describe('mapICiteRecord', () => {
    it('maps a full iCite record to ICiteMetrics', () => {
      const record: ICiteRecord = {
        pmid: 28968381,
        year: 2017,
        title: 'Test Article',
        relative_citation_ratio: 1.73,
        nih_percentile: 70.3,
        citation_count: 26,
        citations_per_year: 4.33,
        expected_citations_per_year: 2.51,
        field_citation_rate: 4.87,
        apt: 0.75,
        is_clinical: 'No',
        provisional: 'No',
        doi: '10.1234/test',
        journal: 'Test Journal',
      };

      const result = mapICiteRecord(record);

      expect(result.pmid).toBe('28968381');
      expect(result.relativeCitationRatio).toBe(1.73);
      expect(result.nihPercentile).toBe(70.3);
      expect(result.citationCount).toBe(26);
      expect(result.citationsPerYear).toBe(4.33);
      expect(result.expectedCitationsPerYear).toBe(2.51);
      expect(result.fieldCitationRate).toBe(4.87);
      expect(result.apt).toBe(0.75);
      expect(result.isClinical).toBe(false);
    });

    it('handles clinical = Yes', () => {
      const record: ICiteRecord = {
        pmid: 12345,
        year: 2020,
        title: null,
        relative_citation_ratio: null,
        nih_percentile: null,
        citation_count: 0,
        citations_per_year: null,
        expected_citations_per_year: null,
        field_citation_rate: null,
        apt: null,
        is_clinical: 'Yes',
        provisional: null,
        doi: null,
        journal: null,
      };

      const result = mapICiteRecord(record);
      expect(result.isClinical).toBe(true);
      expect(result.relativeCitationRatio).toBeNull();
      expect(result.apt).toBeNull();
    });

    it('handles null is_clinical', () => {
      const record: ICiteRecord = {
        pmid: 99999,
        year: null,
        title: null,
        relative_citation_ratio: 0.5,
        nih_percentile: 30.0,
        citation_count: 5,
        citations_per_year: 1.0,
        expected_citations_per_year: 2.0,
        field_citation_rate: 3.0,
        apt: 0.1,
        is_clinical: null,
        provisional: null,
        doi: null,
        journal: null,
      };

      expect(mapICiteRecord(record).isClinical).toBeNull();
    });
  });

  describe('fetchICiteMetrics', () => {
    let fetchSpy: ReturnType<typeof vi.fn>;

    beforeEach(() => {
      fetchSpy = vi.fn();
      vi.stubGlobal('fetch', fetchSpy);
    });

    afterEach(() => {
      vi.restoreAllMocks();
    });

    it('fetches metrics for a list of PMIDs', async () => {
      const mockResponse = {
        data: [
          {
            pmid: 111,
            year: 2020,
            title: 'Article 1',
            relative_citation_ratio: 2.0,
            nih_percentile: 80.0,
            citation_count: 50,
            citations_per_year: 10.0,
            expected_citations_per_year: 5.0,
            field_citation_rate: 6.0,
            apt: 0.9,
            is_clinical: 'No',
            provisional: 'No',
            doi: '10.1/a',
            journal: 'J1',
          },
          {
            pmid: 222,
            year: 2021,
            title: 'Article 2',
            relative_citation_ratio: 0.5,
            nih_percentile: 25.0,
            citation_count: 3,
            citations_per_year: 1.5,
            expected_citations_per_year: 3.0,
            field_citation_rate: 4.0,
            apt: 0.3,
            is_clinical: 'Yes',
            provisional: 'No',
            doi: '10.1/b',
            journal: 'J2',
          },
        ],
      };

      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await fetchICiteMetrics(['111', '222']);

      expect(result.size).toBe(2);
      expect(result.get('111')?.relativeCitationRatio).toBe(2.0);
      expect(result.get('222')?.isClinical).toBe(true);

      // Verify URL contains PMIDs
      const calledUrl = fetchSpy.mock.calls[0][0] as string;
      expect(calledUrl).toContain('pmids=111,222');
    });

    it('deduplicates PMIDs before fetching', async () => {
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve({ data: [{ pmid: 111, year: 2020, title: null, relative_citation_ratio: 1.0, nih_percentile: null, citation_count: 5, citations_per_year: null, expected_citations_per_year: null, field_citation_rate: null, apt: null, is_clinical: null, provisional: null, doi: null, journal: null }] }),
      });

      const result = await fetchICiteMetrics(['111', '111', '111']);

      expect(fetchSpy).toHaveBeenCalledTimes(1);
      const calledUrl = fetchSpy.mock.calls[0][0] as string;
      // Should only have one 111, not three
      expect(calledUrl).toContain('pmids=111');
      expect(calledUrl).not.toContain('pmids=111,111');
      expect(result.size).toBe(1);
    });

    it('returns empty map for empty input', async () => {
      const result = await fetchICiteMetrics([]);
      expect(result.size).toBe(0);
      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it('calls progress callback', async () => {
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve({ data: [] }),
      });

      const progress = vi.fn();
      await fetchICiteMetrics(['111'], progress);
      expect(progress).toHaveBeenCalledWith(1, 1);
    });

    it('retries on 503', async () => {
      fetchSpy
        .mockResolvedValueOnce({ ok: false, status: 503, statusText: 'Service Unavailable' })
        .mockResolvedValueOnce({
          ok: true,
          json: () => Promise.resolve({ data: [{ pmid: 111, year: 2020, title: null, relative_citation_ratio: 1.0, nih_percentile: null, citation_count: 5, citations_per_year: null, expected_citations_per_year: null, field_citation_rate: null, apt: null, is_clinical: null, provisional: null, doi: null, journal: null }] }),
        });

      const result = await fetchICiteMetrics(['111']);
      expect(result.size).toBe(1);
      expect(fetchSpy).toHaveBeenCalledTimes(2);
    });
  });
});
