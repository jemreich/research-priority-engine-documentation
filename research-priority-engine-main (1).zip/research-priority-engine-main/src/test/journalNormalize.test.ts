import { describe, it, expect } from 'vitest';
import { normalizeJournalKey, normalizeIssn, buildNormalizedIndex } from '@/lib/journalNormalize';

describe('normalizeJournalKey', () => {
  it('lowercases and strips punctuation', () => {
    expect(normalizeJournalKey('Nature Communications')).toBe('nature communications');
    expect(normalizeJournalKey('J. Am. Chem. Soc.')).toBe('j am chem soc');
  });

  it('strips diacritics', () => {
    expect(normalizeJournalKey('Médecine Tropicale')).toBe('medecine tropicale');
  });

  it('expands ampersands', () => {
    expect(normalizeJournalKey('Cell & Tissue Research')).toBe('cell and tissue research');
  });

  it('collapses repeated whitespace', () => {
    expect(normalizeJournalKey('  The   Lancet  ')).toBe('the lancet');
  });

  it('handles null/undefined safely', () => {
    expect(normalizeJournalKey(null)).toBe('');
    expect(normalizeJournalKey(undefined)).toBe('');
  });
});

describe('normalizeIssn', () => {
  it('formats 8-digit strings as XXXX-XXXX', () => {
    expect(normalizeIssn('20411723')).toBe('2041-1723');
    expect(normalizeIssn('2041-1723')).toBe('2041-1723');
    expect(normalizeIssn('2041 1723')).toBe('2041-1723');
  });

  it('uppercases trailing X check digit', () => {
    expect(normalizeIssn('1234567x')).toBe('1234-567X');
  });

  it('returns empty string for invalid input', () => {
    expect(normalizeIssn('')).toBe('');
    expect(normalizeIssn('not-an-issn')).toBe('');
    expect(normalizeIssn(null)).toBe('');
  });
});

describe('buildNormalizedIndex', () => {
  it('keys lookups by normalized name', () => {
    const idx = buildNormalizedIndex({
      'Nature Communications': { sjr: 5.0 },
      'J. Am. Chem. Soc.': { sjr: 6.0 },
    });
    expect(idx.get('nature communications')).toEqual({ sjr: 5.0 });
    expect(idx.get('j am chem soc')).toEqual({ sjr: 6.0 });
  });

  it('matches a SCImago-style record by normalized full title', () => {
    const data = {
      'Cell & Tissue Research': { sjr: 1.2, sjrQuartile: 'Q2' },
    };
    const idx = buildNormalizedIndex(data);
    const lookupKey = normalizeJournalKey('Cell and Tissue Research');
    expect(idx.get(lookupKey)?.sjrQuartile).toBe('Q2');
  });
});
