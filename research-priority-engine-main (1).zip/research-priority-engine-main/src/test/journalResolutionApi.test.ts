import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { resolveJournal, parseNLMCatalogXml, clearResolutionCache } from '@/lib/journalResolutionApi';

describe('parseNLMCatalogXml', () => {
  it('extracts the main title and ISSNs', () => {
    const xml = `
      <NLMCatalogRecord>
        <TitleMain><Title>Nature Communications.</Title></TitleMain>
        <ISSN IssnType="Electronic">2041-1723</ISSN>
        <ISSN IssnType="Linking">2041-1723</ISSN>
      </NLMCatalogRecord>
    `;
    const result = parseNLMCatalogXml(xml);
    expect(result?.fullTitle).toBe('Nature Communications');
    expect(result?.issns).toEqual(['2041-1723']);
  });

  it('returns null when no TitleMain', () => {
    expect(parseNLMCatalogXml('<NLMCatalogRecord></NLMCatalogRecord>')).toBeNull();
  });
});

describe('resolveJournal cascade', () => {
  beforeEach(() => {
    clearResolutionCache();
    vi.restoreAllMocks();
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('uses CrossRef when DOI provided', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (url) => {
      const u = String(url);
      if (u.includes('api.crossref.org')) {
        return new Response(
          JSON.stringify({
            message: { 'container-title': ['Nature Communications'], ISSN: ['2041-1723'] },
          }),
          { status: 200 },
        );
      }
      throw new Error(`Unexpected fetch ${u}`);
    });

    const r = await resolveJournal({ isoAbbreviation: 'Nat Commun', doi: '10.1038/s41467-024-12345-6' });
    expect(r.tier).toBe('CROSSREF_DOI');
    expect(r.fullTitle).toBe('Nature Communications');
    expect(r.issns).toContain('2041-1723');
  });

  it('falls back to NLM Catalog when no DOI', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (url) => {
      const u = String(url);
      if (u.includes('esearch.fcgi')) {
        return new Response(JSON.stringify({ esearchresult: { idlist: ['101528555'] } }), { status: 200 });
      }
      if (u.includes('efetch.fcgi')) {
        return new Response(
          '<NLMCatalogRecord><TitleMain><Title>Nature Communications</Title></TitleMain><ISSN IssnType="Electronic">2041-1723</ISSN></NLMCatalogRecord>',
          { status: 200 },
        );
      }
      throw new Error(`Unexpected fetch ${u}`);
    });

    const r = await resolveJournal({ isoAbbreviation: 'Nat Commun' });
    expect(r.tier).toBe('NLM_CATALOG');
    expect(r.fullTitle).toBe('Nature Communications');
    expect(r.issns).toContain('2041-1723');
  });

  it('falls through to OpenAlex text search when CrossRef + NLM fail', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async (url) => {
      const u = String(url);
      if (u.includes('api.crossref.org')) return new Response('not found', { status: 404 });
      if (u.includes('esearch.fcgi')) {
        return new Response(JSON.stringify({ esearchresult: { idlist: [] } }), { status: 200 });
      }
      if (u.includes('api.openalex.org/sources?search=')) {
        return new Response(
          JSON.stringify({
            results: [{ display_name: 'Nature Communications', issn_l: '2041-1723', issn: ['2041-1723'] }],
          }),
          { status: 200 },
        );
      }
      throw new Error(`Unexpected fetch ${u}`);
    });

    const r = await resolveJournal({ isoAbbreviation: 'Nat Commun', doi: '10.1000/fake' });
    expect(r.tier).toBe('OPENALEX_TEXT');
    expect(r.fullTitle).toBe('Nature Communications');
  });

  it('returns UNRESOLVED when every tier fails', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(async () => new Response('', { status: 404 }));
    const r = await resolveJournal({ isoAbbreviation: 'Made Up Journal' });
    expect(r.tier).toBe('UNRESOLVED');
    expect(r.fullTitle).toBe('Made Up Journal');
  });

  it('caches results by abbreviation within the session', async () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockImplementation(
      async () =>
        new Response(
          JSON.stringify({ message: { 'container-title': ['Nature Communications'], ISSN: ['2041-1723'] } }),
          { status: 200 },
        ),
    );
    await resolveJournal({ isoAbbreviation: 'Nat Commun', doi: '10.1/x' });
    await resolveJournal({ isoAbbreviation: 'Nat Commun', doi: '10.1/x' });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });
});
