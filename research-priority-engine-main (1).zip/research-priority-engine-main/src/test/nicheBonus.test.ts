import { describe, it, expect } from "vitest";
import { scoreAllRequests, type ScoringInput } from "@/lib/scoringEngine";
import { DEFAULT_SUB_WEIGHTS } from "@/types";
import type {
  RedcapRequest,
  RequestPublication,
  PIEnrichmentCache,
  JournalEnrichment,
  WeightConfig,
  AdminConfig,
} from "@/types";

// ─── Factories ───────────────────────────────────────────

function makeRequest(overrides: Partial<RedcapRequest> = {}): RedcapRequest {
  return {
    recordId: "1001",
    dateOfRequest: "2024-01-01",
    dateCompleted: "",
    requestor: "Test",
    pi: "Smith, John",
    department: "Medicine",
    projectTitle: "Test",
    requestorEmail: "",
    piDepartment: "Medicine",
    piPosition: "Professor",
    piEmail: "",
    facultyRank: "Professor",
    fundingSource: "NIH",
    fundingMechanism: "",
    otherFunding: "",
    institutionalPilot: "",
    pilotSource: "",
    otherPilotSource: "",
    irbNumber: "",
    irbShortTitle: "",
    qiProject: "",
    dataDeadline: "",
    initiative: "",
    recruitmentRelated: "",
    inclusionCriteria: "",
    exclusionCriteria: "",
    dataElements: "",
    requestType: "data pull",
    tracTime: null,
    ...overrides,
  };
}

function makePub(overrides: Partial<RequestPublication> = {}): RequestPublication {
  return {
    recordId: "1001",
    pmid: "12345",
    title: "Test",
    doi: "10.1234/test",
    journal: "Niche Journal",
    yearPublished: 2023,
    grants: "",
    relativeCitationRatio: 1.5,
    citationCount: 50,
    apt: 0.5,
    nihPercentile: 70,
    citationsPerYear: 10,
    expectedCitationsPerYear: 8,
    fieldCitationRate: 5,
    isClinical: true,
    iciteEnrichedAt: "2024-01-01",
    authorCount: 5,
    ...overrides,
  };
}

function makePI(): PIEnrichmentCache {
  return {
    piName: "Smith, John",
    hIndex: 25,
    totalCitations: 3000,
    totalPublications: 100,
    grantCount: 5,
    totalGrantFunding: 2_000_000,
    activeGrants: 2,
    nihReporterData: null,
    enrichedAt: "2024-01-01",
    status: "enriched",
  };
}

function makeJournal(overrides: Partial<JournalEnrichment> = {}): JournalEnrichment {
  return {
    journalName: "Niche Journal",
    openAlexId: "W123",
    concepts: [],
    specialty: "Cardiology",
    hrcsCategory: null,
    hrcsCategoryResolvedAt: null,
    marketCapBillions: null,
    marketCAGR: null,
    h5Index: null,
    h5Median: null,
    sjr: null,
    sjrQuartile: null,
    sjrHIndex: null,
    totalDocs3yr: null,
    citPerDoc2yr: null,
    enrichedAt: "2024-01-01",
    ...overrides,
  };
}

const weights: WeightConfig = {
  id: "w1",
  presetName: "Equal",
  w1ScientificMerit: 0.25,
  w2ResearcherTrack: 0.25,
  w3InstitutionalAlignment: 0.25,
  w4OperationalEfficiency: 0.25,
  ...DEFAULT_SUB_WEIGHTS,
  isActive: true,
  createdAt: "2024-01-01",
};

function baseAdmin(overrides: Partial<AdminConfig> = {}): AdminConfig {
  return {
    nicheBonusEnabled: true,
    nicheBonusMultiplierMin: 1.0,
    nicheBonusMultiplierMax: 1.3,
    nicheBonusMarketCapThreshold: 50,
    nicheBonusCAGRThreshold: 5,
    nicheQuartileCriterion: { enabled: false, allowedQuartiles: ["Q1", "Q2"] },
    nicheNumericCriteria: [
      { metric: "totalDocs3yr", enabled: false, operator: "lte", threshold: 300 },
      { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
      { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
      { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
    ],
    nicheInterpolationMetric: "totalDocs3yr",
    proxyEnabled: true,
    proxyConfidenceDiscount: 0.85,
    insufficientDataDiscount: 0.5,
    enrichmentCycleDays: 90,
    lastEnrichmentRun: null,
    effortAnchorHours: 2,
    effortDampening: 0.5,
    effortMultiplierMin: 0.25,
    effortMultiplierMax: 3.0,
    ...overrides,
  };
}

function makeInput(adminConfig: AdminConfig, journalCache: JournalEnrichment[] = []): ScoringInput {
  return {
    requests: [makeRequest()],
    publications: [makePub()],
    piCache: [makePI()],
    journalCache,
    tracHours: [],
    weights,
    adminConfig,
  };
}

// ─── Tests ───────────────────────────────────────────────

describe("Niche Bonus Multiplier (SCImago-based)", () => {
  it("no bonus when no criteria are enabled (same journal, bonus on vs off)", () => {
    const j = [makeJournal({ sjrQuartile: "Q1", totalDocs3yr: 50 })];
    const off = scoreAllRequests(makeInput(baseAdmin({ nicheBonusEnabled: false }), j))[0];
    const onNoCriteria = scoreAllRequests(makeInput(baseAdmin(), j))[0];
    // No criteria enabled → no multiplier applied even when bonus toggle is on
    expect(onNoCriteria.weightedReturnScore).toBe(off.weightedReturnScore);
  });

  it("applies bonus when enabled quartile criterion matches", () => {
    const admin = baseAdmin({
      nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1", "Q2"] },
    });
    const baseline = scoreAllRequests(
      makeInput(admin, [makeJournal({ sjrQuartile: "Q4" })]),
    )[0];
    const matched = scoreAllRequests(
      makeInput(admin, [makeJournal({ sjrQuartile: "Q1" })]),
    )[0];
    expect(matched.weightedReturnScore!).toBeGreaterThan(baseline.weightedReturnScore!);
  });

  it("user-configurable: Q3 with low Total Docs (3yr) qualifies", () => {
    const admin = baseAdmin({
      nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q3"] },
      nicheNumericCriteria: [
        { metric: "totalDocs3yr", enabled: true, operator: "lte", threshold: 200 },
        { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
        { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
        { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
      ],
      nicheInterpolationMetric: "totalDocs3yr",
    });

    // Only the matching journal varies — same SCImago metrics so S2 baseline is identical.
    const matchedQ3Low = scoreAllRequests(
      makeInput(admin, [makeJournal({ sjrQuartile: "Q3", totalDocs3yr: 100 })]),
    )[0];
    const wrongQuartile = scoreAllRequests(
      makeInput(admin, [makeJournal({ sjrQuartile: "Q1", totalDocs3yr: 100 })]),
    )[0];
    const tooManyDocs = scoreAllRequests(
      makeInput(admin, [makeJournal({ sjrQuartile: "Q3", totalDocs3yr: 500 })]),
    )[0];

    // Q1 actually scores higher in S2 (better quartile), so compare against the wrong-quartile
    // case using the bonus toggle: disabling the bonus removes the niche advantage entirely.
    const matchedNoBonus = scoreAllRequests(
      makeInput(
        { ...admin, nicheBonusEnabled: false },
        [makeJournal({ sjrQuartile: "Q3", totalDocs3yr: 100 })],
      ),
    )[0];
    expect(matchedQ3Low.weightedReturnScore!).toBeGreaterThan(matchedNoBonus.weightedReturnScore!);
    expect(matchedQ3Low.weightedReturnScore!).toBeGreaterThan(tooManyDocs.weightedReturnScore!);
    // sanity: wrongQuartile gets no bonus but better Q1 prestige; still defined
    expect(wrongQuartile.weightedReturnScore).toBeDefined();
  });

  it("AND semantics: all enabled criteria must match", () => {
    const admin = baseAdmin({
      nicheNumericCriteria: [
        { metric: "totalDocs3yr", enabled: true, operator: "lte", threshold: 300 },
        { metric: "sjr", enabled: true, operator: "gte", threshold: 1.0 },
        { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
        { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
      ],
    });
    const both = scoreAllRequests(
      makeInput(admin, [makeJournal({ totalDocs3yr: 100, sjr: 2.0 })]),
    )[0];
    const onlyOne = scoreAllRequests(
      makeInput(admin, [makeJournal({ totalDocs3yr: 100, sjr: 0.5 })]),
    )[0];
    expect(both.weightedReturnScore!).toBeGreaterThan(onlyOne.weightedReturnScore!);
  });

  it("missing metric value disqualifies an enabled numeric criterion", () => {
    const admin = baseAdmin({
      nicheNumericCriteria: [
        { metric: "totalDocs3yr", enabled: true, operator: "lte", threshold: 300 },
        { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
        { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
        { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
      ],
    });
    const present = scoreAllRequests(
      makeInput(admin, [makeJournal({ totalDocs3yr: 100 })]),
    )[0];
    const missing = scoreAllRequests(
      makeInput(admin, [makeJournal({ totalDocs3yr: null })]),
    )[0];
    expect(present.weightedReturnScore!).toBeGreaterThan(missing.weightedReturnScore!);
  });

  it("disabling the bonus removes any multiplier", () => {
    const enabledAdmin = baseAdmin({
      nicheBonusEnabled: true,
      nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1"] },
    });
    const disabledAdmin = baseAdmin({
      nicheBonusEnabled: false,
      nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1"] },
    });
    const j = [makeJournal({ sjrQuartile: "Q1" })];
    const enabled = scoreAllRequests(makeInput(enabledAdmin, j))[0];
    const disabled = scoreAllRequests(makeInput(disabledAdmin, j))[0];
    expect(enabled.weightedReturnScore!).toBeGreaterThan(disabled.weightedReturnScore!);
  });

  it("respects custom multiplier range (wider Max → bigger bonus)", () => {
    const j = [makeJournal({ sjrQuartile: "Q1", totalDocs3yr: 50 })];
    const narrow = scoreAllRequests(
      makeInput(
        baseAdmin({
          nicheBonusMultiplierMin: 1.0,
          nicheBonusMultiplierMax: 1.1,
          nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1"] },
        }),
        j,
      ),
    )[0];
    const wide = scoreAllRequests(
      makeInput(
        baseAdmin({
          nicheBonusMultiplierMin: 1.0,
          nicheBonusMultiplierMax: 2.0,
          nicheQuartileCriterion: { enabled: true, allowedQuartiles: ["Q1"] },
        }),
        j,
      ),
    )[0];
    expect(wide.weightedReturnScore!).toBeGreaterThan(narrow.weightedReturnScore!);
  });
});
