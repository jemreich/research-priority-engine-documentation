import { describe, it, expect } from 'vitest';
import {
  extractLastName,
  extractKeywords,
  buildQuery,
  parseYearFromPubDate,
  parseArticleXml,
  authorMatchesInXml,
  filterArticles,
  toRequestPublication,
} from '@/lib/pubmedApi';

describe('extractLastName', () => {
  it('extracts last name from "Last, First" format', () => {
    expect(extractLastName('Smith, John')).toBe('Smith');
  });

  it('handles extra whitespace', () => {
    expect(extractLastName('  O\'Brien , Mary ')).toBe("O'Brien");
  });

  it('handles name without comma', () => {
    expect(extractLastName('Smith')).toBe('Smith');
  });
});

describe('extractKeywords', () => {
  it('removes stopwords and returns two longest words', () => {
    const result = extractKeywords('Retrospective Analysis of Cardiovascular Outcomes Following Transplantation');
    expect(result).toHaveLength(2);
    expect(result).toContain('transplantation');
    expect(result).toContain('cardiovascular');
  });

  it('returns empty for undefined', () => {
    expect(extractKeywords(undefined)).toEqual([]);
  });

  it('filters out PRD-specified research stopwords', () => {
    const result = extractKeywords('study analysis assessment data patients');
    expect(result).toEqual([]);
  });

  it('returns fewer than 2 if not enough keywords', () => {
    const result = extractKeywords('the a an Diabetes');
    expect(result).toEqual(['diabetes']);
  });
});

describe('buildQuery', () => {
  it('builds full query with keywords and year', () => {
    const query = buildQuery({
      recordId: '100',
      piName: 'Smith, John',
      yearCompleted: 2020,
      projectTitle: 'Cardiovascular Transplantation Outcomes',
    });
    expect(query).toContain('Smith[Author]');
    expect(query).toContain('Wake Forest[Affiliation]');
    expect(query).toContain('2022:3000[dp]'); // yearCompleted + 2
    expect(query).toContain('(transplantation)');
    expect(query).toContain('(cardiovascular)');
  });

  it('builds query without year when yearCompleted is null', () => {
    const query = buildQuery({
      recordId: '100',
      piName: 'Jones, Alice',
      yearCompleted: null,
      projectTitle: 'Diabetes Prevention',
    });
    expect(query).toContain('Jones[Author]');
    expect(query).not.toContain('[dp]');
  });

  it('builds query with author+affiliation only when no keywords', () => {
    const query = buildQuery({
      recordId: '100',
      piName: 'Lee, Bob',
      yearCompleted: 2019,
      projectTitle: 'data analysis study',
    });
    expect(query).toBe('Lee[Author] AND Wake Forest[Affiliation] AND 2021:3000[dp]');
  });
});

describe('parseYearFromPubDate', () => {
  it('parses structured Year', () => {
    expect(parseYearFromPubDate('<Year>2022</Year><Month>03</Month>')).toBe(2022);
  });

  it('parses MedlineDate fallback', () => {
    expect(parseYearFromPubDate('<MedlineDate>Winter 2019</MedlineDate>')).toBe(2019);
  });

  it('handles MedlineDate with range', () => {
    expect(parseYearFromPubDate('<MedlineDate>2020 Jan-Feb</MedlineDate>')).toBe(2020);
  });

  it('returns null for unparseable', () => {
    expect(parseYearFromPubDate('<Season>Spring</Season>')).toBeNull();
  });
});

describe('parseArticleXml', () => {
  const sampleXml = `
    <PMID Version="1">12345678</PMID>
    <ArticleId IdType="doi">10.1000/test.123</ArticleId>
    <ISOAbbreviation>J Test Med</ISOAbbreviation>
    <Title>Journal of Testing Medicine</Title>
    <PubDate><Year>2023</Year></PubDate>
    <Grant><GrantID>R01-123</GrantID><Agency>NIH</Agency><Country>US</Country></Grant>
  `;

  it('parses all fields correctly', () => {
    const result = parseArticleXml(sampleXml, 'REC001');
    expect(result).not.toBeNull();
    expect(result!.pmid).toBe('12345678');
    expect(result!.doi).toBe('10.1000/test.123');
    expect(result!.journal).toBe('J Test Med');
    expect(result!.yearPublished).toBe(2023);
    expect(result!.grants).toContain('R01-123');
    expect(result!.recordId).toBe('REC001');
  });

  it('returns null DOI when not present', () => {
    const xml = '<PMID Version="1">99999</PMID><PubDate><Year>2021</Year></PubDate>';
    const result = parseArticleXml(xml, 'REC002');
    expect(result!.doi).toBeNull();
  });

  it('falls back to Title when no ISOAbbreviation', () => {
    const xml = '<PMID Version="1">88888</PMID><Title>Full Journal Name</Title><PubDate><Year>2020</Year></PubDate>';
    const result = parseArticleXml(xml, 'REC003');
    expect(result!.journal).toBe('Full Journal Name');
  });
});

describe('authorMatchesInXml', () => {
  const xml = `
    <AuthorList>
      <Author><LastName>Smith</LastName><ForeName>John</ForeName></Author>
      <Author><LastName>Jones</LastName><ForeName>Alice</ForeName></Author>
    </AuthorList>
  `;

  it('matches case-insensitively', () => {
    expect(authorMatchesInXml(xml, 'smith')).toBe(true);
    expect(authorMatchesInXml(xml, 'JONES')).toBe(true);
  });

  it('returns false for non-matching name', () => {
    expect(authorMatchesInXml(xml, 'Williams')).toBe(false);
  });

  it('returns false when no AuthorList', () => {
    expect(authorMatchesInXml('<Article></Article>', 'Smith')).toBe(false);
  });
});

describe('filterArticles', () => {
  const articles = [
    { recordId: '1', pmid: '111', doi: null, journal: 'J1', yearPublished: 2020, grants: '', title: 'Test 1', authorCount: 3 },
    { recordId: '1', pmid: '222', doi: null, journal: 'J2', yearPublished: 2023, grants: '', title: 'Test 2', authorCount: 4 },
    { recordId: '1', pmid: '333', doi: null, journal: 'J3', yearPublished: 2025, grants: '', title: 'Test 3', authorCount: 5 },
  ];

  it('filters by yearCompleted + 2', () => {
    const result = filterArticles(articles, 'Smith', 2021);
    // Only articles with year >= 2023 should pass
    expect(result).toHaveLength(2);
    expect(result.map(a => a.pmid)).toEqual(['222', '333']);
  });

  it('keeps all when yearCompleted is null', () => {
    const result = filterArticles(articles, 'Smith', null);
    expect(result).toHaveLength(3);
  });
});

describe('toRequestPublication', () => {
  it('converts PubMedResult to RequestPublication', () => {
    const pub = toRequestPublication({
      recordId: '100',
      pmid: '12345',
      title: 'Test Article',
      doi: '10.1000/test',
      journal: 'J Med',
      yearPublished: 2022,
      grants: 'R01/NIH',
      authorCount: 6,
    });
    expect(pub.recordId).toBe('100');
    expect(pub.pmid).toBe('12345');
    expect(pub.doi).toBe('10.1000/test');
  });

  it('converts null DOI to empty string', () => {
    const pub = toRequestPublication({
      recordId: '100',
      pmid: '12345',
      title: 'Test',
      doi: null,
      journal: 'J Med',
      yearPublished: 2022,
      grants: '',
      authorCount: null,
    });
    expect(pub.doi).toBe('');
  });
});
