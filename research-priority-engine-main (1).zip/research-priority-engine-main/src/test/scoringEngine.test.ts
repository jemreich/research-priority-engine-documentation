import { describe, it, expect } from "vitest";
import { scoreAllRequests, type ScoringInput } from "@/lib/scoringEngine";
import type {
  RedcapRequest,
  RequestPublication,
  PIEnrichmentCache,
  JournalEnrichment,
  TracHours,
  WeightConfig,
  AdminConfig,
} from "@/types";
import { DEFAULT_SUB_WEIGHTS } from "@/types";

// ─── Factories ───────────────────────────────────────────

function makeRequest(overrides: Partial<RedcapRequest> = {}): RedcapRequest {
  return {
    recordId: "1001",
    dateOfRequest: "2024-01-01",
    dateCompleted: "",
    requestor: "Test",
    pi: "Smith, John",
    department: "Medicine",
    projectTitle: "Test Project",
    requestorEmail: "",
    piDepartment: "Medicine",
    piPosition: "Professor",
    piEmail: "",
    facultyRank: "Professor",
    fundingSource: "",
    fundingMechanism: "",
    otherFunding: "",
    institutionalPilot: "",
    pilotSource: "",
    otherPilotSource: "",
    irbNumber: "",
    irbShortTitle: "",
    qiProject: "",
    dataDeadline: "",
    initiative: "",
    recruitmentRelated: "",
    inclusionCriteria: "",
    exclusionCriteria: "",
    dataElements: "",
    requestType: "data pull",
    tracTime: null,
    ...overrides,
  };
}

function makePub(overrides: Partial<RequestPublication> = {}): RequestPublication {
  return {
    recordId: "1001",
    pmid: "12345",
    title: "Test Pub",
    doi: "10.1234/test",
    journal: "Test Journal",
    yearPublished: 2023,
    grants: "",
    relativeCitationRatio: 1.5,
    citationCount: 50,
    apt: 0.5,
    nihPercentile: 70,
    citationsPerYear: 10,
    expectedCitationsPerYear: 8,
    fieldCitationRate: 5,
    isClinical: true,
    iciteEnrichedAt: "2024-01-01",
    authorCount: 5,
    ...overrides,
  };
}

function makePI(overrides: Partial<PIEnrichmentCache> = {}): PIEnrichmentCache {
  return {
    piName: "Smith, John",
    hIndex: 25,
    totalCitations: 3000,
    totalPublications: 100,
    grantCount: 5,
    totalGrantFunding: 2_000_000,
    activeGrants: 2,
    nihReporterData: null,
    enrichedAt: "2024-01-01",
    status: "enriched",
    ...overrides,
  };
}

const defaultWeights: WeightConfig = {
  id: "w1",
  presetName: "Equal",
  w1ScientificMerit: 0.25,
  w2ResearcherTrack: 0.25,
  w3InstitutionalAlignment: 0.25,
  w4OperationalEfficiency: 0.25,
  ...DEFAULT_SUB_WEIGHTS,
  isActive: true,
  createdAt: "2024-01-01",
};

const defaultAdmin: AdminConfig = {
  nicheBonusEnabled: true,
  nicheBonusMultiplierMin: 1.0,
  nicheBonusMultiplierMax: 1.3,
  nicheBonusMarketCapThreshold: 50,
  nicheBonusCAGRThreshold: 5,
  nicheQuartileCriterion: { enabled: false, allowedQuartiles: ["Q1", "Q2"] },
  nicheNumericCriteria: [
    { metric: "totalDocs3yr", enabled: false, operator: "lte", threshold: 300 },
    { metric: "sjr", enabled: false, operator: "gte", threshold: 1.0 },
    { metric: "sjrHIndex", enabled: false, operator: "lte", threshold: 100 },
    { metric: "citPerDoc2yr", enabled: false, operator: "gte", threshold: 2.0 },
  ],
  nicheInterpolationMetric: "totalDocs3yr",
  proxyEnabled: true,
  proxyConfidenceDiscount: 0.85,
  insufficientDataDiscount: 0.5,
  enrichmentCycleDays: 90,
  lastEnrichmentRun: null,
  effortAnchorHours: 2,
  effortDampening: 0.5,
  effortMultiplierMin: 0.25,
  effortMultiplierMax: 3.0,
};

function makeInput(overrides: Partial<ScoringInput> = {}): ScoringInput {
  return {
    requests: [makeRequest()],
    publications: [makePub()],
    piCache: [makePI()],
    journalCache: [],
    tracHours: [],
    weights: defaultWeights,
    adminConfig: defaultAdmin,
    ...overrides,
  };
}

// ─── Tests ───────────────────────────────────────────────

describe("Weight Configuration & Scoring Engine", () => {
  describe("weights must sum to 1.0", () => {
    it("equal weights (0.25 each) produce a valid score", () => {
      const results = scoreAllRequests(makeInput());
      expect(results).toHaveLength(1);
      expect(results[0].status).toBe("scored");
      expect(results[0].weightedReturnScore).toBeGreaterThan(0);
    });

    it("skewed sub-metric weights change the weighted return score", () => {
      const equalResult = scoreAllRequests(makeInput())[0];

      // Skew S1 sub-weights heavily toward citation count
      const skewedWeights: WeightConfig = {
        ...defaultWeights,
        s1_rcr: 0,
        s1_nihPercentile: 0,
        s1_citationCount: 1,
      };
      const skewedResult = scoreAllRequests(makeInput({ weights: skewedWeights }))[0];

      // Both should be scored
      expect(equalResult.status).toBe("scored");
      expect(skewedResult.status).toBe("scored");
      // Scores should differ (sub-metric weights now drive variation)
      expect(skewedResult.weightedReturnScore).not.toBe(equalResult.weightedReturnScore);
    });

    it("zero weight on a category eliminates its contribution", () => {
      const zeroS1Weights: WeightConfig = {
        ...defaultWeights,
        w1ScientificMerit: 0,
        w2ResearcherTrack: 0.34,
        w3InstitutionalAlignment: 0.33,
        w4OperationalEfficiency: 0.33,
      };

      // Request with pubs but no PI → only S1 contributes normally
      const input = makeInput({
        weights: zeroS1Weights,
        piCache: [],
        publications: [makePub()],
        requests: [makeRequest({ fundingSource: "NIH" })],
      });
      const result = scoreAllRequests(input)[0];

      // S1 should still be calculated but its contribution to weighted return is 0
      expect(result.publicationImpactScore).toBeGreaterThan(0);
      // The weighted return should not include S1
      // Recalculate: only S3 (funding) contributes since no PI data → S2=proxy 30, S4=null→0
      expect(result.weightedReturnScore).toBeDefined();
    });
  });

  describe("effort-adjusted ROI", () => {
    it("more hours → lower effort-adjusted ROI (same weighted return)", () => {
      const req1 = makeRequest({ recordId: "A" });
      const req2 = makeRequest({ recordId: "B" });
      const pub1 = makePub({ recordId: "A" });
      const pub2 = makePub({ recordId: "B" });
      const pi = makePI();

      const trac1: TracHours = { recordId: "A", totalHours: 2, source: "trac" };
      const trac2: TracHours = { recordId: "B", totalHours: 5, source: "trac" };

      const results = scoreAllRequests(
        makeInput({
          requests: [req1, req2],
          publications: [pub1, pub2],
          piCache: [pi],
          tracHours: [trac1, trac2],
        }),
      );

      const scoreA = results.find((r) => r.recordId === "A")!;
      const scoreB = results.find((r) => r.recordId === "B")!;

      // Same weighted return
      expect(scoreA.weightedReturnScore).toBe(scoreB.weightedReturnScore);
      // But A (2 hrs) should have higher effort-adjusted ROI than B (5 hrs)
      expect(scoreA.effortAdjustedROIScore!).toBeGreaterThan(scoreB.effortAdjustedROIScore!);
      // Verify multipliers
      expect(scoreA.effortMultiplier!).toBeGreaterThan(scoreB.effortMultiplier!);
    });

    it("no hours → effortMultiplier is 1.0 (anchored at 2h default)", () => {
      const results = scoreAllRequests(makeInput({ tracHours: [] }));
      // Default 2 hours → (2/2)^0.5 = 1.0
      expect(results[0].effortMultiplier).toBe(1.0);
      expect(results[0].effortAdjustedROIScore).toBeCloseTo(results[0].weightedReturnScore!, 1);
    });

    it("fewer hours → higher multiplier; ordering is preserved", () => {
      const reqs = [
        makeRequest({ recordId: "A" }),
        makeRequest({ recordId: "B" }),
        makeRequest({ recordId: "C" }),
      ];
      const pubs = [
        makePub({ recordId: "A" }),
        makePub({ recordId: "B" }),
        makePub({ recordId: "C" }),
      ];
      const tracs: TracHours[] = [
        { recordId: "A", totalHours: 1, source: "trac" },
        { recordId: "B", totalHours: 4, source: "trac" },
        { recordId: "C", totalHours: 16, source: "trac" },
      ];
      const results = scoreAllRequests(
        makeInput({ requests: reqs, publications: pubs, tracHours: tracs }),
      );
      const a = results.find((r) => r.recordId === "A")!.effortMultiplier!;
      const b = results.find((r) => r.recordId === "B")!.effortMultiplier!;
      const c = results.find((r) => r.recordId === "C")!.effortMultiplier!;
      expect(a).toBeGreaterThan(b);
      expect(b).toBeGreaterThan(c);
      // 1h: sqrt(2/1) ≈ 1.414
      expect(a).toBeCloseTo(Math.SQRT2, 2);
      // 4h: sqrt(2/4) ≈ 0.707
      expect(b).toBeCloseTo(Math.sqrt(0.5), 2);
    });

    it("clamps multiplier to configured min and max", () => {
      const tinyHours: TracHours = { recordId: "1001", totalHours: 0.01, source: "trac" };
      const hugeHours: TracHours = { recordId: "1001", totalHours: 10000, source: "trac" };

      const tinyResult = scoreAllRequests(makeInput({ tracHours: [tinyHours] }))[0];
      // (2/0.01)^0.5 ≈ 14.14 → clamped to max 3.0
      expect(tinyResult.effortMultiplier).toBe(3.0);

      const hugeResult = scoreAllRequests(makeInput({ tracHours: [hugeHours] }))[0];
      // (2/10000)^0.5 ≈ 0.014 → clamped to min 0.25
      expect(hugeResult.effortMultiplier).toBe(0.25);
    });
  });

  describe("tier classification", () => {
    it("T1 when both pubs and PI data exist", () => {
      const results = scoreAllRequests(makeInput());
      expect(results[0].scoringTier).toBe(1);
    });

    it("T2 when only PI data (no enriched pubs)", () => {
      const results = scoreAllRequests(
        makeInput({
          publications: [],
        }),
      );
      expect(results[0].scoringTier).toBe(2);
    });

    it("T2 when only pubs (no PI data)", () => {
      const results = scoreAllRequests(
        makeInput({
          piCache: [],
        }),
      );
      expect(results[0].scoringTier).toBe(2);
    });

    it("T3 when no pubs and no PI data", () => {
      const results = scoreAllRequests(
        makeInput({
          publications: [],
          piCache: [],
        }),
      );
      expect(results[0].scoringTier).toBe(3);
      expect(results[0].status).toBe("insufficient");
    });

    it("T2 applies proxy confidence discount", () => {
      const t1Result = scoreAllRequests(makeInput())[0];
      const t2Result = scoreAllRequests(makeInput({ piCache: [] }))[0];

      // T2 should be discounted relative to what it would be at T1
      // Both have pubs so S1 is the same; T2 lacks S4
      expect(t2Result.scoringTier).toBe(2);
      expect(t1Result.scoringTier).toBe(1);
    });
  });

  describe("ranking", () => {
    it("assigns ranks in descending order of effort-adjusted ROI", () => {
      const requests = [
        makeRequest({ recordId: "A", fundingSource: "NIH" }),
        makeRequest({ recordId: "B", fundingSource: "" }),
      ];
      const pubs = [
        makePub({ recordId: "A", relativeCitationRatio: 2.0, nihPercentile: 90 }),
        makePub({ recordId: "B", relativeCitationRatio: 0.5, nihPercentile: 30 }),
      ];

      const results = scoreAllRequests(
        makeInput({
          requests,
          publications: pubs,
        }),
      );

      const ranked = results.filter((r) => r.rank != null).sort((a, b) => a.rank! - b.rank!);
      expect(ranked.length).toBe(2);
      expect(ranked[0].effortAdjustedROIScore!).toBeGreaterThanOrEqual(ranked[1].effortAdjustedROIScore!);
    });

    it("insufficient requests get no rank", () => {
      const results = scoreAllRequests(
        makeInput({
          publications: [],
          piCache: [],
        }),
      );
      expect(results[0].rank).toBeNull();
    });
  });

  describe("subscores", () => {
    it("S1 is null when no enriched publications", () => {
      const results = scoreAllRequests(
        makeInput({
          publications: [makePub({ iciteEnrichedAt: null, relativeCitationRatio: null })],
        }),
      );
      expect(results[0].publicationImpactScore).toBeNull();
    });

    it("S1 scales with RCR — higher RCR → higher score", () => {
      const lowRCR = scoreAllRequests(
        makeInput({
          publications: [makePub({ relativeCitationRatio: 0.5 })],
        }),
      )[0].publicationImpactScore!;

      const highRCR = scoreAllRequests(
        makeInput({
          publications: [makePub({ relativeCitationRatio: 2.0 })],
        }),
      )[0].publicationImpactScore!;

      expect(highRCR).toBeGreaterThan(lowRCR);
    });

    it("S3 scores higher with NIH funding source", () => {
      const nihResult = scoreAllRequests(
        makeInput({
          requests: [makeRequest({ fundingSource: "NIH R01" })],
        }),
      )[0].fundingActivityScore!;

      const noFundResult = scoreAllRequests(
        makeInput({
          requests: [makeRequest({ fundingSource: "" })],
        }),
      )[0].fundingActivityScore!;

      expect(nihResult).toBeGreaterThan(noFundResult);
    });

    it("S4 is null when PI not enriched", () => {
      const results = scoreAllRequests(
        makeInput({
          piCache: [makePI({ status: "pending", hIndex: null })],
        }),
      );
      expect(results[0].researchOutputScore).toBeNull();
    });
  });
});
