import { describe, expect, it } from 'vitest';
import { mergeRequestsByRecordId, mergeTracHoursByRecordId } from '@/store/mergeState';
import type { RedcapRequest, TracHours } from '@/types';

const makeRequest = (recordId: string, projectTitle: string): RedcapRequest => ({
  recordId,
  dateOfRequest: '',
  dateCompleted: '',
  requestor: '',
  pi: '',
  department: '',
  projectTitle,
  requestorEmail: '',
  piDepartment: '',
  piPosition: '',
  piEmail: '',
  facultyRank: '',
  fundingSource: '',
  fundingMechanism: '',
  otherFunding: '',
  institutionalPilot: '',
  pilotSource: '',
  otherPilotSource: '',
  irbNumber: '',
  irbShortTitle: '',
  qiProject: '',
  dataDeadline: '',
  initiative: '',
  recruitmentRelated: '',
  inclusionCriteria: '',
  exclusionCriteria: '',
  dataElements: '',
  requestType: '',
  tracTime: null,
});

describe('mergeRequestsByRecordId', () => {
  it('overrides existing requests and removes duplicates from incoming uploads', () => {
    const existing = [makeRequest('101', 'Old title')];
    const incoming = [
      makeRequest('101', 'Updated title'),
      makeRequest('101', 'Latest title'),
      makeRequest('202', 'New title'),
    ];

    const merged = mergeRequestsByRecordId(existing, incoming);

    expect(merged).toHaveLength(2);
    expect(merged.find((r) => r.recordId === '101')?.projectTitle).toBe('Latest title');
    expect(merged.find((r) => r.recordId === '202')?.projectTitle).toBe('New title');
  });
});

describe('mergeTracHoursByRecordId', () => {
  it('overrides existing trac hours and removes duplicates from incoming uploads', () => {
    const existing: TracHours[] = [{ recordId: '101', totalHours: 4, source: 'trac' }];
    const incoming: TracHours[] = [
      { recordId: '101', totalHours: 7, source: 'trac' },
      { recordId: '101', totalHours: 9, source: 'trac' },
      { recordId: '202', totalHours: 3, source: 'old_trac' },
    ];

    const merged = mergeTracHoursByRecordId(existing, incoming);

    expect(merged).toHaveLength(2);
    expect(merged.find((r) => r.recordId === '101')?.totalHours).toBe(9);
    expect(merged.find((r) => r.recordId === '202')?.totalHours).toBe(3);
  });
});
