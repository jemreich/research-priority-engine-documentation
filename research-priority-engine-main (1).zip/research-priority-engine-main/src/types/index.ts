export interface RedcapRequest {
  recordId: string;
  dateOfRequest: string;
  dateCompleted: string;
  requestor: string;
  pi: string;
  department: string;
  projectTitle: string;
  requestorEmail: string;
  piDepartment: string;
  piPosition: string;
  piEmail: string;
  facultyRank: string;
  fundingSource: string;
  fundingMechanism: string;
  otherFunding: string;
  institutionalPilot: string;
  pilotSource: string;
  otherPilotSource: string;
  irbNumber: string;
  irbShortTitle: string;
  qiProject: string;
  dataDeadline: string;
  initiative: string;
  recruitmentRelated: string;
  inclusionCriteria: string;
  exclusionCriteria: string;
  dataElements: string;
  requestType: string;
  tracTime: number | null;
}

export interface TracHours {
  recordId: string;
  totalHours: number;
  source: "trac" | "old_trac";
}

export interface RequestPublication {
  recordId: string;
  pmid: string;
  title: string;
  doi: string;
  journal: string;
  yearPublished: number | null;
  grants: string;
  // iCite metrics
  relativeCitationRatio: number | null;
  citationCount: number | null;
  apt: number | null;
  nihPercentile: number | null;
  citationsPerYear: number | null;
  expectedCitationsPerYear: number | null;
  fieldCitationRate: number | null;
  isClinical: boolean | null;
  iciteEnrichedAt: string | null;
  // Number of authors on the publication (parsed from PubMed AuthorList)
  authorCount: number | null;
}

export interface ReporterProjectSummary {
  projectNum: string;
  title: string;
  fiscalYear: number;
  amount: number | null;
  isActive: boolean;
  activityCode: string | null;
  startDate: string | null;
  endDate: string | null;
}

export interface NIHReporterData {
  totalProjectsFound: number;
  uniqueGrants: number;
  projects: ReporterProjectSummary[];
}

export interface PIEnrichmentCache {
  piName: string;
  hIndex: number | null;
  totalCitations: number | null;
  totalPublications: number | null;
  grantCount: number | null;
  totalGrantFunding: number | null;
  activeGrants: number | null;
  nihReporterData: NIHReporterData | null;
  enrichedAt: string | null;
  status: "pending" | "enriched" | "error";
}

export type JournalResolutionTier =
  | 'CROSSREF_DOI'
  | 'NLM_CATALOG'
  | 'OPENALEX_ISSN'
  | 'OPENALEX_TEXT'
  | 'UNRESOLVED';

export interface JournalEnrichment {
  journalName: string;
  originalName?: string; // The publication's original journal name (ISO abbreviation, for lookup)
  openAlexId: string;
  concepts: string[];
  specialty: string | null;
  hrcsCategory: string | null;
  hrcsCategoryResolvedAt: string | null;
  marketCapBillions: number | null;
  marketCAGR: number | null;
  // Google Scholar metrics
  h5Index: number | null;
  h5Median: number | null;
  // SCImago metrics
  sjr: number | null;
  sjrQuartile: string | null; // e.g. "Q1", "Q2"
  sjrHIndex: number | null;
  totalDocs3yr: number | null;
  citPerDoc2yr: number | null;
  // Resolution pipeline metadata
  issns?: string[];
  resolutionTier?: JournalResolutionTier;
  enrichedAt: string;
}

export interface UnresolvedJournal {
  abbreviation: string;
  attempts: number;
  lastTriedAt: string;
}

export interface RequestScore {
  recordId: string;
  // Category subscores
  publicationImpactScore: number | null;
  journalPrestigeScore: number | null;
  fundingActivityScore: number | null;
  researchOutputScore: number | null;
  // Composite scores
  weightedReturnScore: number | null;
  effortAdjustedROIScore: number | null;
  effortMultiplier: number | null;
  // Scoring tier
  scoringTier: 1 | 2 | 3 | null;
  rank: number | null;
  scoredAt: string | null;
  status: "pending" | "scored" | "error" | "insufficient";
}

export interface WeightConfig {
  id: string;
  presetName: string;
  // Legacy category weights (kept for back-compat; no longer drive scoring — categories are equal-weighted)
  w1ScientificMerit: number;
  w2ResearcherTrack: number;
  w3InstitutionalAlignment: number;
  w4OperationalEfficiency: number;
  // S1 — Scientific Merit (Publication Impact) sub-metrics, must sum to 1.0
  s1_rcr: number;
  s1_nihPercentile: number;
  s1_citationCount: number;
  // S2 — Researcher Track Record sub-metrics, must sum to 1.0
  s2_hIndex: number;
  s2_totalPublications: number;
  s2_totalCitations: number;
  s2_facultyRank: number;
  // S3 — Institutional Alignment (Journal Prestige) sub-metrics, must sum to 1.0
  s3_sjrQuartile: number;
  s3_sjr: number;
  s3_h5Index: number;
  s3_citPerDoc2yr: number;
  // S4 — Operational Efficiency (Funding Activity) sub-metrics, must sum to 1.0
  s4_fundingSource: number;
  s4_activeGrants: number;
  s4_totalFunding: number;
  isActive: boolean;
  createdAt: string;
}

// Default weights — each section (S1/S2/S3/S4) sums to 0.25 so the four
// categories are balanced equally at 25% by default. Users can rebalance
// freely on the Weight Config page.
export const DEFAULT_SUB_WEIGHTS = {
  // S1 Scientific Merit — total 0.25
  s1_rcr: 0.1,
  s1_nihPercentile: 0.1,
  s1_citationCount: 0.05,
  // S2 Researcher Track Record — total 0.25
  s2_hIndex: 0.0875,
  s2_totalPublications: 0.0625,
  s2_totalCitations: 0.0625,
  s2_facultyRank: 0.0375,
  // S3 Institutional Alignment — total 0.25
  s3_sjrQuartile: 0.0625,
  s3_sjr: 0.0625,
  s3_h5Index: 0.0625,
  s3_citPerDoc2yr: 0.0625,
  // S4 Operational Efficiency — total 0.25
  s4_fundingSource: 0.075,
  s4_activeGrants: 0.0875,
  s4_totalFunding: 0.0875,
} as const;

export type NicheNumericMetric = "sjr" | "sjrHIndex" | "totalDocs3yr" | "citPerDoc2yr";
export type NicheOperator = "lte" | "gte";
export type SJRQuartile = "Q1" | "Q2" | "Q3" | "Q4";

export interface NicheNumericCriterion {
  metric: NicheNumericMetric;
  enabled: boolean;
  operator: NicheOperator;
  threshold: number;
}

export interface NicheQuartileCriterion {
  enabled: boolean;
  allowedQuartiles: SJRQuartile[];
}

export interface AdminConfig {
  nicheBonusEnabled: boolean;
  nicheBonusMultiplierMin: number;
  nicheBonusMultiplierMax: number;
  // Legacy market-based thresholds (no longer used for niche detection — kept for back-compat)
  nicheBonusMarketCapThreshold: number;
  nicheBonusCAGRThreshold: number;
  // SCImago-driven niche criteria (all enabled criteria must match — AND)
  nicheQuartileCriterion: NicheQuartileCriterion;
  nicheNumericCriteria: NicheNumericCriterion[];
  // Which numeric metric drives the Min↔Max multiplier interpolation.
  // Lower values of this metric = stronger niche → closer to Max multiplier.
  nicheInterpolationMetric: NicheNumericMetric;
  proxyEnabled: boolean;
  proxyConfidenceDiscount: number;
  insufficientDataDiscount: number;
  enrichmentCycleDays: number;
  lastEnrichmentRun: string | null;
  // Effort multiplier — anchored, dampened, clamped formula:
  //   effortMultiplier = clamp((effortAnchorHours / hours) ^ effortDampening, [min, max])
  // Defaults: anchor 2h, dampening 0.5, clamp [0.25, 3.0]
  effortAnchorHours: number;
  effortDampening: number;
  effortMultiplierMin: number;
  effortMultiplierMax: number;
}

export interface OverrideLog {
  id: string;
  recordId: string;
  piName: string;
  previousRank: number | null;
  newRank: number;
  reason: string;
  user: string;
  timestamp: string;
}

export interface UploadLog {
  id: string;
  type: "redcap" | "trac";
  filename: string;
  timestamp: string;
  recordCount: number;
  status: "success" | "error" | "partial";
  errors?: string[];
}

export type SortField =
  | "rank"
  | "weightedReturnScore"
  | "effortAdjustedROIScore"
  | "pi"
  | "department"
  | "dateOfRequest"
  | "requestType"
  | "fundingSource"
  | "facultyRank";
export type SortDirection = "asc" | "desc";

export interface AppState {
  requests: RedcapRequest[];
  tracHours: TracHours[];
  publications: RequestPublication[];
  piCache: PIEnrichmentCache[];
  journalCache: JournalEnrichment[];
  scores: RequestScore[];
  weights: WeightConfig[];
  adminConfig: AdminConfig;
  overrides: OverrideLog[];
  uploadLogs: UploadLog[];
  unresolvedJournals: UnresolvedJournal[];
  lastQueueUpdate: string | null;
}
